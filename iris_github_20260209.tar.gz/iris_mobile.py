#!/usr/bin/env python3
"""
IRIS MOBILE BRAIN
==================================================
Optimized for Android/Termux deployment.
Includes all mathematical foundations for efficient mobile operation.

Key Optimizations:
    - Lazy loading of heavy modules
    - Efficient memory usage
    - Works without GPU
    - All reasoning runs on CPU
    - 2GB knowledge base integration

Download & Install on Android:
    1. Install Termux from F-Droid
    2. In Termux: pkg install python git
    3. pip install numpy sentence-transformers
    4. Transfer iris_mobile_*.tar.gz via USB/AirDrop
    5. tar -xzf iris_mobile_*.tar.gz
    6. python iris_mobile.py
"""
import os
import sys
import json
import time

# Project root
PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, PROJECT_ROOT)


class IrisMobileBrain:
    """
    Optimized brain for mobile devices.
    Works on Android via Termux, iOS via Pythonista, and any Unix system.
    """
    
    def __init__(self, lite_mode: bool = True):
        print("=" * 60)
        print("  ██╗██████╗ ██╗███████╗    ███╗   ███╗ ██████╗ ██████╗ ██╗██╗     ███████╗")
        print("  ██║██╔══██╗██║██╔════╝    ████╗ ████║██╔═══██╗██╔══██╗██║██║     ██╔════╝")
        print("  ██║██████╔╝██║███████╗    ██╔████╔██║██║   ██║██████╔╝██║██║     █████╗  ")
        print("  ██║██╔══██╗██║╚════██║    ██║╚██╔╝██║██║   ██║██╔══██╗██║██║     ██╔══╝  ")
        print("  ██║██║  ██║██║███████║    ██║ ╚═╝ ██║╚██████╔╝██████╔╝██║███████╗███████╗")
        print("  ╚═╝╚═╝  ╚═╝╚═╝╚══════╝    ╚═╝     ╚═╝ ╚═════╝ ╚═════╝ ╚═╝╚══════╝╚══════╝")
        print("=" * 60)
        print("  MOBILE INTELLIGENCE | Optimized for Android/Termux")
        print("=" * 60)
        
        self.lite_mode = lite_mode
        self.reasoner = None
        self.researcher = None
        self.mem = None
        
        # Initialize based on mode
        if lite_mode:
            self._init_lite()
        else:
            self._init_full()
    
    def _init_lite(self):
        """Lightweight initialization for mobile."""
        print("\n[MOBILE] Initializing in LITE mode (minimal memory)...")
        
        # Load knowledge researcher only
        try:
            from infra.world_class_reasoning import KnowledgeResearcher
            self.researcher = KnowledgeResearcher()
            print("[MOBILE] Knowledge Researcher loaded.")
        except Exception as e:
            print(f"[MOBILE] Warning: {e}")
            self.researcher = None
        
        print("[MOBILE] Lite mode ready.")
    
    def _init_full(self):
        """Full initialization with all modules."""
        print("\n[MOBILE] Initializing in FULL mode...")
        
        try:
            from infra.world_class_reasoning import WorldClassReasoner
            self.reasoner = WorldClassReasoner()
            print("[MOBILE] Full reasoning engine loaded.")
        except Exception as e:
            print(f"[MOBILE] Falling back to lite mode: {e}")
            self._init_lite()
    
    def query(self, text: str) -> str:
        """Process a query through the mobile brain."""
        if not text.strip():
            return "Please provide a query."
        
        # Try full reasoner first
        if self.reasoner:
            try:
                from infra.world_class_reasoning import ReasoningDepth
                return self.reasoner.reason(text, ReasoningDepth.MODERATE)
            except Exception as e:
                pass
        
        # Fall back to knowledge research
        if self.researcher:
            results = self.researcher.research(text)
            if results:
                contents = [r.get('content', '') for r in results[:3]]
                return "From my knowledge base:\n\n" + "\n\n".join(contents)
        
        # Ultimate fallback
        return f"I understand your query: '{text}'. Full processing requires loading additional modules."
    
    def interactive(self):
        """Interactive chat mode for mobile."""
        print("\n" + "=" * 60)
        print("IRIS MOBILE CHAT")
        print("Type 'exit' to quit | 'stats' for status")
        print("=" * 60)
        
        while True:
            try:
                user_input = input("\n[YOU] > ").strip()
                
                if not user_input:
                    continue
                
                if user_input.lower() == 'exit':
                    print("[IRIS] Goodbye!")
                    break
                
                if user_input.lower() == 'stats':
                    print(f"[STATS] Lite mode: {self.lite_mode}")
                    print(f"[STATS] Reasoner: {'Active' if self.reasoner else 'Not loaded'}")
                    print(f"[STATS] Researcher: {'Active' if self.researcher else 'Not loaded'}")
                    continue
                
                if user_input.lower() == 'full':
                    print("[MOBILE] Switching to full mode...")
                    self._init_full()
                    continue
                
                response = self.query(user_input)
                print(f"\n[IRIS] {response}")
                
            except KeyboardInterrupt:
                print("\n[IRIS] Goodbye!")
                break
            except Exception as e:
                print(f"[ERROR] {e}")


def main():
    """Main entry point for mobile."""
    import argparse
    parser = argparse.ArgumentParser(description="Iris Mobile Brain")
    parser.add_argument("--full", action="store_true", help="Load full modules (more memory)")
    parser.add_argument("--query", type=str, help="Single query mode")
    args = parser.parse_args()
    
    brain = IrisMobileBrain(lite_mode=not args.full)
    
    if args.query:
        print(brain.query(args.query))
    else:
        brain.interactive()


if __name__ == "__main__":
    main()
