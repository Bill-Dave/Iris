import os
import time
from infra.memory_struct import MemoryCore
from infra.agentic_outreach import OutreachAgent

def execute_physical_campaign():
    print("--- SAPIENT INTELLIGENCE: PHYSICAL OUTREACH EXECUTION ---")
    
    mem = MemoryCore("./iris_data_genius")
    agent = OutreachAgent(mem)
    
    # Target 1: SEED Group (Dubai) - Real Portal
    target = {
        "name": "SEED Group", 
        "profile": "Strategic partner for UAE/MENA scaling and high-tech sovereignty.",
        "url": "https://www.seedgroup.com/strategic-partnership/"
    }
    
    print(f"\n[PHYSICAL] Initiating contact with {target['name']}...")
    print(f"[PHYSICAL] Source: {target['url']}")
    
    # 1. Generate the Sapient Proposal
    proposal = agent.generate_proposal(target['name'], target['profile'])
    
    # 2. Dispatch via Physical Bridge (Preparation phase)
    # This will log the readiness and display field mappings.
    agent.dispatch(target['name'], proposal, target_url=target['url'], physical=True)
    
    print("\n--- PHYSICAL PREPARATION COMPLETE ---")
    print("Handing over to Browser Subagent for real-world interaction.")

if __name__ == "__main__":
    execute_physical_campaign()
