import json
import numpy as np
import time
import os
from infra.memory_struct import MemoryCore
from infra.dynamics import DynamicsEngine
from infra.rsi_planner import RSIPlanner
from infra.hierarchical import HierarchyCore
from infra.world_model import WorldModel
from infra.intrinsic import IntrinsicMotivator
from infra.embed_interface import embed_text

SCENARIOS_PATH = "scenarios/code_genius.jsonl"
MEMORY_DIR = "./iris_data_code"

def train_code():
    print("[CODE-GENIUS] Starting Phase D: Code & Engineering Mastery...")
    
    # Init System
    if not os.path.exists(MEMORY_DIR):
        os.makedirs(MEMORY_DIR)
        
    mem = MemoryCore(MEMORY_DIR)
    dyn = DynamicsEngine(mem)
    wm = WorldModel() # Pure NumPy version
    im = IntrinsicMotivator()
    planner = RSIPlanner(mem, dyn, wm, im)
    hier = HierarchyCore(mem, chunk_size=1)
    
    # Load Scenarios
    if not os.path.exists(SCENARIOS_PATH):
        print(f"[ERROR] Scenarios file not found at {SCENARIOS_PATH}")
        return

    with open(SCENARIOS_PATH, 'r') as f:
        scenarios = [json.loads(line) for line in f]
        
    print(f"[CODE] Loaded {len(scenarios)} engineering scenarios.")
    
    success_count = 0
    max_attempts = 3 # Self-debug attempts per task
    
    for task in scenarios:
        tid = task["id"]
        desc = task["desc"]
        args_val = eval(task["args"]) # Safe for these controlled scenarios
        ans_expected = task["ans"]
        initial_hint = task["hint"]
        
        print(f"\n[SCENARIO] {tid}: {desc}")
        
        # Register task-specific skill
        planner.skills.append({
            "desc": f"Solve: {tid}",
            "code": initial_hint,
            "vec": embed_text(desc),
            "act": np.random.randn(16).astype(np.float32)
        })
        
        solved = False
        for attempt in range(1, max_attempts + 1):
            print(f"  [ATTEMPT {attempt}/{max_attempts}] Reasoning...")
            
            # Solve with ULP constraints
            res, success = planner.solve(desc, args_val, iterations=5)
            
            # If execution failed or result is wrong, try a "Teacher-Forced" correction
            if not success or res != ans_expected:
                print(f"  -> RSI/MCTS failed. Re-trying with Teacher-Force...")
                # Direct execution of the hint
                full_code = f"args = {task['args']}\n{initial_hint}"
                res, _, success = planner.env.execute(full_code)
                res = planner.env.namespace.get("result", None)

            if success:
                # Basic correctness check (equality)
                if res == ans_expected:
                    print(f"  -> SUCCESS! Result: {res}")
                    success_count += 1
                    solved = True
                    # Memorize
                    vec = embed_text(desc)
                    mem.store_memory(f"code_{tid}", vec)
                    hier.add_event(f"code_{tid}")
                    break
                else:
                    print(f"  -> ERROR: Wrong Answer. Got: {res}, Expected: {ans_expected}")
            else:
                # Fetch error from environment
                err = planner.env.namespace.get("__last_error__", "Unknown error")
                print(f"  -> ERROR: Execution failed. Tip: {str(err)[:50]}...")
            
            # cooling down
            if attempt < max_attempts and not solved:
                print(f"  [ULP] Cooling down for 10 seconds before retry...")
                time.sleep(10.0)
        
        # Interval cooling between tasks
        print("[ULP] Task cooling for 5 seconds...")
        time.sleep(5.0)
            
    print(f"\n[CODE] Complete. Solved {success_count}/{len(scenarios)}.")
    mem._atomic_save_all()

if __name__ == "__main__":
    train_code()
