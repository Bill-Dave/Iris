import os
import time
import pickle
import numpy as np
import json
from infra.memory_struct import MemoryCore
from infra.production_retriever import TieredRetriever
from infra.kit_engine_v3 import KITEngineV3
from infra.governor import ThermalGovernor
from infra.voice import VoiceEngine
from infra.embed_interface import embed_text

MEMORY_DIR = "./iris_data_genius"

def experiential_learning_chat():
    print("\n--- IRIS AGI: KNOWLEDGE ORGANISM (V3) ---")
    
    mem = MemoryCore(MEMORY_DIR)
    retriever = TieredRetriever(mem)
    kit = KITEngineV3(mem)
    gov = ThermalGovernor(cpu_threshold=0.8)
    voice = VoiceEngine(mem)
    
    # Load Tier A Index
    idx_path = os.path.join(MEMORY_DIR, "inverted_index.pkl")
    if os.path.exists(idx_path):
        with open(idx_path, 'rb') as f:
            retriever.inverted_index = pickle.load(f)
        retriever.doc_lengths = np.load(os.path.join(MEMORY_DIR, "doc_lengths.npy"))
        print("[SYSTEM] Tier A Index Loaded.")

    print(voice.greet())

    try:
        while True:
            user_input = input("\n[USER] > ")
            if user_input.lower() in ["exit", "quit", "bye"]:
                break

            # 1. Governance & Perception
            config = gov.check_system_state()
            candidates_a = retriever.query_tier_a(user_input, k=config["N_c"])
            candidate_ids = [c[0] for c in candidates_a]
            
            # 2. Reasoning (KIT v3 - Pathways)
            query_vec = embed_text(user_input)
            assembly = kit.solve_evolution(user_input, query_vec, candidate_ids)
            
            # 3. Synthesis
            shards_text = []
            active_ckas = [uid for uid, salience in assembly if salience > 0.1]
            
            for uid in active_ckas[:3]: # Use top 3 for response
                m = mem.get_memory(uid)
                if m and m.get('data'):
                    data = json.loads(m['data'])
                    shards_text.append(data['content'])
            
            raw_logic = " ".join(shards_text)
            gov.sleep_reflective(2.0)
            response = voice.synthesize(user_input, raw_logic)
            print(f"\n[IRIS] {response}")
            
            # 4. Experiential Learning (Outcome Pathway)
            # In a real system, this would be based on reward. 
            # For the demo, we assume success and reinforce the assembly.
            print(f"[SYSTEM] Reinforcing pathways for {len(active_ckas)} CKAs...")
            for uid in active_ckas:
                m = mem.get_memory(uid)
                # Increase salience (Type III Pathway)
                new_s = np.clip(m['s'] + 0.1, 0.0, 1.0)
                mem.update_activation(uid, new_s)
            
            mem.save_salience()
            
    except KeyboardInterrupt:
        pass

if __name__ == "__main__":
    experiential_learning_chat()
