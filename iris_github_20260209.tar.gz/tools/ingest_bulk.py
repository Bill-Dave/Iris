import os
import time
import numpy as np
from infra.memory_struct import MemoryCore
from infra.embed_interface import embed_text

MEMORY_DIR = "./iris_data_genius"
RAW_DATA_DIR = "./data/raw/experience"

def ingest_bulk():
    print("[INGEST-BULK] Starting large-scale experience ingestion...")
    
    if not os.path.exists(MEMORY_DIR):
        os.makedirs(MEMORY_DIR)
        
    mem = MemoryCore(MEMORY_DIR)
    
    files = [f for f in os.listdir(RAW_DATA_DIR) if f.endswith(".txt")]
    print(f"[INGEST] Found {len(files)} source files.")
    
    total_ingested = 0
    
    for filename in files:
        filepath = os.path.join(RAW_DATA_DIR, filename)
        print(f"[INGEST] Processing {filename}...")
        
        with open(filepath, 'r') as f:
            content = f.read()
            # CANONICAL SHARDING: Paragraph/Claim sized
            # Split by double newline or large punctuation gaps
            import re
            chunks = [c.strip() for c in re.split(r'\n\n|\.\s', content) if len(c.strip()) > 40]
            
            print(f"[INGEST] Ingesting {len(chunks)} linguistic fragments from {filename}...")
            
            # --- PHASE G: Fit Semantic Model ---
            from infra.embed_interface import get_pse, PSE_PATH
            pse = get_pse()
            pse.dim = 384
            pse.fit(chunks)
            pse.save(PSE_PATH)
            # ------------------------------------
            
            for i, chunk in enumerate(chunks):
                # ULP Embedding: Throttled to prevent CPU spikes
                vec = embed_text(chunk)
                mem.store_memory(f"exp_{filename}_{i}", vec, data=chunk)
                total_ingested += 1
                
                if i % 50 == 0 and i > 0:
                    print(f"  -> Progress: {i}/{len(chunks)} fragments...")
                    # Allow CPU to cool down every batch
                    time.sleep(2.0)
                    
    # Load/Build Tier A Index
    from infra.production_retriever import TieredRetriever
    retriever = TieredRetriever(mem)
    print("[INGEST] Building Tier A (Inverted Index)...")
    retriever.build_tier_a(mem.ids)
    
    # Save Inverted Index (Simplified for demo - in prod, use binary)
    import pickle
    idx_path = os.path.join(MEMORY_DIR, "inverted_index.pkl")
    with open(idx_path, 'wb') as f:
        pickle.dump(retriever.inverted_index, f)
    with open(os.path.join(MEMORY_DIR, "doc_lengths.npy"), 'wb') as f:
        np.save(f, retriever.doc_lengths)
    
    print(f"[INGEST] Complete. Total Experience Fragments: {total_ingested}")
    mem._atomic_save_all()
    
    # Save a journal entry
    import json
    journal_path = os.path.join(mem.data_dir, "journal.jsonl")
    with open(journal_path, 'a') as f:
        f.write(json.dumps({"t": time.time(), "op": "INGEST_BULK", "count": total_ingested}) + "\n")

if __name__ == "__main__":
    ingest_bulk()
