from infra.memory_struct import MemoryCore
from infra.dynamics import DynamicsEngine
from infra.rsi_planner import RSIPlanner
from infra.hierarchical import HierarchyCore
import time

def run_rsi():
    print("[RSI] Starting Recursive Self-Improvement Loop...")
    
    # Init
    mem = MemoryCore("./iris_data_rsi")
    dyn = DynamicsEngine(mem)
    planner = RSIPlanner(mem, dyn)
    hier = HierarchyCore(mem, chunk_size=2)
    
    # Curriculum
    tasks = [
        ("Calculate sum", [1, 2, 3, 4]),
        ("Find max", [10, 5, 99, 2]),
        ("Loop print double", 5),
        ("Unknown Task", 0)
    ]
    
    for desc, args in tasks:
        print(f"--- Task: {desc} ---")
        
        # Plan & Act
        res, success = planner.solve(desc, args)
        
        if success:
            print(f"[RSI] SUCCESS. Result: {res}")
            # Memorize Success (Hierarchy)
            # Store atomic event -> Chunk
            hier.add_event(f"success_{int(time.time())}")
        else:
            print(f"[RSI] FAILED.")
            
    print("[RSI] Loop Complete.")

if __name__ == "__main__":
    run_rsi()
