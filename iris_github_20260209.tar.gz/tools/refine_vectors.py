import os
import json
import numpy as np
import pandas as pd
import sys
from datetime import datetime

# Add project root to path
sys.path.append(os.getcwd())

from kit_core import MemoryCore, utils

def refine_vectors():
    print(f"=== [KIT] STARTING VECTOR REFINEMENT ({datetime.now().strftime('%H:%M:%S')}) ===")
    
    # 1. Load data
    if not os.path.exists("analysis/stability.tsv") or not os.path.exists("kit_memory.npz"):
        print("Error: Required data files missing.")
        return
        
    stability_df = pd.read_csv("analysis/stability.tsv", sep='\t')
    data = np.load("kit_memory.npz")
    
    ids = list(data['ids'])
    vectors = data['vectors'].astype(np.float32)
    salience = data['salience']
    
    # 2. Identify stable targets (stab_i >= 0.4)
    stable_ids = stability_df[stability_df['stability'] >= 0.4]['id'].values
    print(f"[KIT] Found {len(stable_ids)} stable items for refinement.")
    
    if len(stable_ids) == 0:
        print("[KIT] No stable items found. Refinement skipped.")
        return

    # 3. Refinement loop
    GAMMA = 1e-3
    history = []
    
    # Compute similarity matrix once
    C = utils.cosine_similarity_matrix(vectors)
    
    # Identify indices
    stable_indices = [ids.index(sid) for sid in stable_ids if sid in ids]
    
    refined_vectors = np.copy(vectors)
    
    for idx in stable_indices:
        # Assembly A: neighbors with C_ij > 0.8
        neighbors = np.where(C[idx] > 0.8)[0]
        # Remove self
        neighbors = neighbors[neighbors != idx]
        
        if len(neighbors) > 0:
            v_i = refined_vectors[idx]
            sum_diff = np.zeros_like(v_i)
            
            for n_idx in neighbors:
                sum_diff += (refined_vectors[n_idx] - v_i)
            
            delta = GAMMA * sum_diff
            v_refined = v_i + delta
            
            # Re-normalize
            v_refined /= (np.linalg.norm(v_refined) + 1e-9)
            
            refined_vectors[idx] = v_refined
            
            # Log adjustment
            history.append({
                "id": ids[idx],
                "delta_norm": float(np.linalg.norm(delta)),
                "num_neighbors": int(len(neighbors))
            })

    # 4. Save results
    os.makedirs('analysis', exist_ok=True)
    with open('analysis/vectors_history.jsonl', 'a') as f:
        for entry in history:
            entry['timestamp'] = datetime.now().isoformat()
            f.write(json.dumps(entry) + '\n')
            
    np.savez("kit_memory.npz", 
             vectors=refined_vectors, 
             ids=np.array(ids), 
             salience=salience)
             
    print(f"=== [KIT] REFINEMENT COMPLETE. Refined {len(history)} vectors. ===")

if __name__ == "__main__":
    refine_vectors()
