#!/bin/bash
# ===============================================================================
# IRIS MOBILE PACKAGE BUILDER
# ===============================================================================
# Creates an optimized package for Android/Termux deployment.
# Includes the 2GB knowledge base and all reasoning modules.
#
# OUTPUT: iris_mobile_YYYYMMDD.tar.gz (~2.1GB)
# ===============================================================================

echo "==============================================================================="
echo "  IRIS MOBILE PACKAGE BUILDER"
echo "  Target: Android/Termux"
echo "==============================================================================="

TIMESTAMP=$(date +%Y%m%d_%H%M%S)
OUTPUT_DIR="./mobile_package"
ARCHIVE_NAME="iris_mobile_$TIMESTAMP.tar.gz"

# Create output directory
mkdir -p "$OUTPUT_DIR"

echo ""
echo "[1/5] Creating lightweight core package..."

# Create the package structure
mkdir -p "$OUTPUT_DIR/iris_mobile/infra"
mkdir -p "$OUTPUT_DIR/iris_mobile/iris_data_2gb"

# Copy essential Python files
cp iris_mobile.py "$OUTPUT_DIR/iris_mobile/"
cp iris_brain.py "$OUTPUT_DIR/iris_mobile/"
cp -r infra/*.py "$OUTPUT_DIR/iris_mobile/infra/" 2>/dev/null

echo "[2/5] Including 2GB knowledge base..."

# Copy knowledge base (this is the 2GB file)
if [ -f "iris_data_2gb/mega_knowledge.jsonl" ]; then
    cp iris_data_2gb/mega_knowledge.jsonl "$OUTPUT_DIR/iris_mobile/iris_data_2gb/"
    echo "       ✓ Knowledge base included (2GB)"
else
    echo "       ⚠ Knowledge base not found, skipping..."
fi

# Copy other data directories
cp -r iris_data_genius "$OUTPUT_DIR/iris_mobile/" 2>/dev/null

echo "[3/5] Creating mobile requirements..."

cat > "$OUTPUT_DIR/iris_mobile/requirements.txt" << 'EOF'
# IRIS Mobile Requirements
# Install: pip install -r requirements.txt
numpy>=1.21.0
sentence-transformers>=2.2.0
EOF

echo "[4/5] Creating README..."

cat > "$OUTPUT_DIR/iris_mobile/README_MOBILE.md" << 'EOF'
# IRIS Mobile - Android/Termux Installation

## Quick Install (5 minutes)

### Step 1: Install Termux
Download from F-Droid (NOT Play Store):
https://f-droid.org/packages/com.termux/

### Step 2: Setup Termux
```bash
# Update packages
pkg update && pkg upgrade

# Install Python
pkg install python

# Install dependencies
pip install numpy sentence-transformers
```

### Step 3: Transfer & Extract
Transfer `iris_mobile_*.tar.gz` to your phone via:
- USB cable
- AirDrop (Mac to iPhone/iPad)
- Cloud storage (Google Drive, etc.)

Then in Termux:
```bash
# Navigate to download location (usually)
cd /storage/emulated/0/Download

# Extract
tar -xzf iris_mobile_*.tar.gz

# Enter directory
cd iris_mobile
```

### Step 4: Run Iris
```bash
# Interactive mode (recommended)
python iris_mobile.py

# Or with full modules (uses more RAM)
python iris_mobile.py --full

# Single query
python iris_mobile.py --query "What is machine learning?"
```

## Memory Usage
- Lite mode: ~200MB RAM
- Full mode: ~500MB RAM
- With knowledge base: ~2.5GB storage

## Troubleshooting

**"numpy not found"**
```bash
pip install numpy
```

**"sentence-transformers not found"**
```bash
pip install sentence-transformers
```

**"Permission denied"**
```bash
termux-setup-storage
```

## Commands in Chat
- `exit` - Quit
- `stats` - Show status
- `full` - Switch to full mode (more features)

---
Architect: Davies Bilayi Kalori
Framework: Sapient Intelligence / KIT / APRA
EOF

echo "[5/5] Creating archive..."

cd "$OUTPUT_DIR"
tar -czf "../$ARCHIVE_NAME" iris_mobile
cd ..

# Get size
if [ -f "$ARCHIVE_NAME" ]; then
    SIZE=$(du -h "$ARCHIVE_NAME" | cut -f1)
    echo ""
    echo "==============================================================================="
    echo "  MOBILE PACKAGE COMPLETE"
    echo "==============================================================================="
    echo "  Archive: $ARCHIVE_NAME"
    echo "  Size: $SIZE"
    echo ""
    echo "  TO DOWNLOAD ON ANDROID:"
    echo "  ────────────────────────────────────────────────────────────"
    echo "  1. Connect phone via USB to Mac"
    echo "  2. Open Android File Transfer / Finder"
    echo "  3. Copy $ARCHIVE_NAME to phone Downloads folder"
    echo "  4. In Termux: cd /storage/emulated/0/Download"
    echo "  5. tar -xzf iris_mobile_*.tar.gz"
    echo "  6. cd iris_mobile && python iris_mobile.py"
    echo "  ────────────────────────────────────────────────────────────"
    echo ""
    
    # Move to package_output
    mv "$ARCHIVE_NAME" package_output/ 2>/dev/null || true
    echo "  Package saved to: package_output/$ARCHIVE_NAME"
    echo "==============================================================================="
else
    echo "  ✗ Failed to create archive"
fi

# Cleanup
rm -rf "$OUTPUT_DIR"
