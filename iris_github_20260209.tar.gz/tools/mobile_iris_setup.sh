#!/bin/bash
# Iris Sovereign Handover: Mobile/Termux Setup Utility
# Author: Davies Bilayi Kalori

echo "--- IRIS SOVEREIGN HANDOVER: MOBILE/TERMUX SETUP ---"

PRESERVE_DIR="./preservation"
mkdir -p "$PRESERVE_DIR"

TIMESTAMP=$(date +%Y%m%d_%H%M%S)
ARCHIVE_NAME="iris_sovereign_$TIMESTAMP.tar.gz"

echo "[SHUTTLE] Collecting high-fidelity core modules..."
FILES_TO_PACK=(
    "iris.py"
    "iris_core"
    "infra/memory_struct.py"
    "infra/kit_engine_v3.py"
    "infra/voice.py"
    "infra/embed_interface.py"
    "infra/lookback.py"
    "data/raw/baseline/founder_narrative_axioms.txt"
    "iris_data_genius"  # The Library of Knowledge
    "tools/iris_console.py"
)

# Create the archive
tar -czf "$PRESERVE_DIR/$ARCHIVE_NAME" "${FILES_TO_PACK[@]}"

echo "[SHUTTLE] Sovereign Archive Created: $PRESERVE_DIR/$ARCHIVE_NAME"
echo ""
echo "INSTRUCTIONS FOR ANDROID (TERMUX):"
echo "1. Install Termux from F-Droid."
echo "2. Run: pkg install python numpy"
echo "3. Move this archive to your phone and extract: tar -xzf $ARCHIVE_NAME"
echo "4. Launch Iris: python3 tools/iris_console.py"
echo "--- HANDOVER COMPLETE ---"
