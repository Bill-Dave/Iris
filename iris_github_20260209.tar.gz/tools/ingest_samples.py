import os
import numpy as np
import sys

# Add current dir to path
sys.path.append(os.getcwd())

from kit_core import MemoryCore
from infra.embed import init_embedder, embed_and_store

def generate_samples():
    domains = {
        "Physics": [
            "Quantization of energy levels in hydrogen atoms.",
            "General relativity describes the curvature of spacetime.",
            "Entropy increases in isolated systems over time.",
            "The wave-particle duality of light reveals quantum nature.",
            "Thermodynamics governs the flow of heat and work."
        ],
        "Ethics": [
            "Utilitarianism seeks the greatest good for the greatest number.",
            "Deontological ethics focuses on duties and rules.",
            "Virtue ethics emphasizes character and moral excellence.",
            "The categorical imperative is a central concept in Kantianism.",
            "Moral relativism suggests that ethics are culturally dependent."
        ],
        "Business": [
            "Market equilibrium is reached when supply meets demand.",
            "Scalability is key for high-growth tech startups.",
            "Diversification reduces portfolio risk in volatile markets.",
            "Customer lifetime value is a critical metric for SaaS companies.",
            "Strategic management involves long-term goal alignment."
        ]
    }
    
    samples = []
    # Expand to 2000 samples by varying phrasing or adding noise? 
    # For a deterministic test, we can just repeat with slight variations if needed, 
    # but 2000 unique-ish sentences is better.
    
    # Simple expansion for the 2k requirement
    for i in range(2000):
        domain = list(domains.keys())[i % 3]
        base = domains[domain][(i // 3) % 5]
        samples.append((f"doc_{i:04d}", f"[{domain}] {base} (Variant {i//15})"))
        
    return samples

def run_ingest():
    print("[KIT] Starting Phase 4 Ingestion (2000 samples)...")
    
    # Initialize Core
    core = MemoryCore(dim=384, capacity_max=50.0) 
    
    # Initialize Embedder
    try:
        init_embedder(seed=0)
    except Exception as e:
        print("[KIT] ERROR: Could not init real embedder. Ingest aborted.")
        return
        
    samples = generate_samples()
    
    for i, (item_id, text) in enumerate(samples):
        embed_and_store(core, item_id, text)
        if (i + 1) % 250 == 0:
            print(f"[KIT] Ingested {i+1}/2000...")
            
    # Save memory state
    np.savez("kit_memory.npz", 
             vectors=core.vectors, 
             ids=np.array(core.ids), 
             salience=core.salience)
    
    print(f"[KIT] Ingest complete. Memory count: {core.get_count()}")

if __name__ == "__main__":
    run_ingest()
