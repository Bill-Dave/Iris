import os
import time
import numpy as np
from infra.memory_struct import MemoryCore
from infra.kit_engine_v3 import KITEngineV3
from infra.dynamics import DynamicsEngine
from infra.rsi_planner import RSIPlanner
from infra.world_model import WorldModel
from infra.intrinsic import IntrinsicMotivator
from infra.voice import VoiceEngine
from infra.explain import ExplanationEngine
from infra.embed_interface import embed_text

def iris_chat():
    print("--- IRIS AGI: GENIUS INTERACTIVE VOICE (ULP MODE) ---")
    
    # Load all Genius cognitive libraries
    libraries = ["./iris_data_stem", "./iris_data_code", "./iris_data_socio", "./iris_data_genius"]
    
    # Unified Memory (Simplified for demo: using the latest 'genius' data)
    mem_dir = "./iris_data_genius"
    mem = MemoryCore(mem_dir)
    kit = KITEngineV3(mem)
    dyn = DynamicsEngine(mem)
    wm = WorldModel()
    im = IntrinsicMotivator()
    planner = RSIPlanner(mem, dyn, wm, im)
    explainer = ExplanationEngine(mem, planner.lookback)
    voice = VoiceEngine(mem)
    
    print("\n[IRIS] " + voice.greet())
    
    while True:
        try:
            user_input = input("\n[USER] > ")
            if user_input.lower() in ["exit", "quit", "bye"]:
                print("[IRIS] Terminating engagement. Snapshotting cognitive state...")
                break
            
            if not user_input.strip():
                continue
                
            print(f"[IRIS] (Thinking: ULP Reasoning)...")
            # ULP Thermal Safety: Mandatory 5s delay
            time.sleep(5.0)
            
            # 1. Reason: What is the user talking about?
            query_vec = embed_text(user_input)
            candidates = [c[0] for c in mem.find_nearest(query_vec, n=10)]
            
            # Use KIT Engine for assembly
            assembly = kit.solve_evolution(user_input, query_vec, candidates)
            
            # 2. Synthesize Voice with Assembly
            response = voice.synthesize_assembly(user_input, assembly)
            
            # 3. Add Mechanistic explanation if requested
            if "?" in user_input:
                trace = explainer.generate_trace_explanation(user_input)
                print(f"\n[INTERNAL TRACE]\n{trace}")
            
            print(f"\n[IRIS] {response}")
            
        except KeyboardInterrupt:
            print("\n[IRIS] Engagement interrupted.")
            break
            
    print("[SYSTEM] Engagement closed.")

if __name__ == "__main__":
    iris_chat()
