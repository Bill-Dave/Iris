import os
import json
from infra.memory_struct import MemoryCore
from infra.agentic_outreach import OutreachAgent

def generate_all_apps():
    print("--- SAPIENT INTELLIGENCE: FUNDING APPLICATION PIPELINE ---")
    
    mem = MemoryCore("./iris_data_genius")
    agent = OutreachAgent(mem)
    
    targets = [
        {
            "name": "DOB Equity",
            "profile": "VC focusing on early growth in East Africa. Interested in scalable impact and sustainable tech models in Kenya.",
            "ask": "$750,000"
        },
        {
            "name": "Fanisi Capital",
            "profile": "Kenyan VC fund interested in high-growth companies with strong local management and disruptive potential.",
            "ask": "$750,000"
        },
        {
            "name": "Novastar Ventures",
            "profile": "Venture capital firm that explores and supports entrepreneurs building the next generation of African businesses.",
            "ask": "$750,000"
        },
        {
            "name": "Chandaria Capital",
            "profile": "Kenyan Family Office with deep roots in industrial and technology sectors. Values innovation and long-term legacy.",
            "ask": "$750,000"
        },
        {
            "name": "Wa’ed Ventures (Aramco)",
            "profile": "Corporate VC and family-backed. Focused on strategic deep-tech, energy efficiency, and sovereign technical capabilities.",
            "ask": "$750,000"
        }
    ]
    
    base_dir = "artifacts/applications"
    os.makedirs(base_dir, exist_ok=True)
    
    for t in targets:
        print(f"\n[PIPELINE] Processing application for: {t['name']}...")
        
        # 1. Custom profile for the agent logic
        context = f"{t['profile']} Requested Seed A: {t['ask']} for Sapient Intelligence."
        
        # 2. Generate Proposal
        proposal = agent.generate_proposal(t['name'], context)
        
        # 3. Save to Artifacts
        fund_dir = os.path.join(base_dir, t['name'].replace(" ", "_").replace("(", "").replace(")", ""))
        os.makedirs(fund_dir, exist_ok=True)
        
        with open(os.path.join(fund_dir, "tailored_summary.md"), "w") as f:
            f.write(f"# Sapient Intelligence: Tailored Summary for {t['name']}\n\n")
            f.write(proposal)
            
        with open(os.path.join(fund_dir, "cover_email.txt"), "w") as f:
            subject = f"Sapient Intelligence: Strategic Investment Inquiry - {t['name']}"
            f.write(f"Subject: {subject}\n\n")
            f.write(proposal)
        
        print(f"[PIPELINE] Artifacts generated in {fund_dir}")

    print("\n--- PIPELINE EXECUTION COMPLETE ---")
    print(f"Total Applications Prepared: {len(targets)}")

if __name__ == "__main__":
    generate_all_apps()
