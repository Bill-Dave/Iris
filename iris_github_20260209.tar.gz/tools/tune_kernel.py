import os
import numpy as np
import sys
import csv

# Add project root to path
sys.path.append(os.getcwd())

from kit_core import MemoryCore
from infra.embed import embed_text
from infra.kernel import compatibility, run_probes, save_metrics

def main():
    print("=== KIT PHASE 5: KERNEL TUNING ===")
    
    # 1. Load Memory
    if not os.path.exists("kit_memory.npz"):
        print("Error: kit_memory.npz not found.")
        return
        
    data = np.load("kit_memory.npz")
    core = MemoryCore(dim=384, capacity_max=50.0)
    core.vectors = data['vectors']
    core.ids = list(data['ids'])
    
    # 2. Probes
    probes = [
        "Apple (fruit) nutrition",
        "Apple (company) earnings",
        "Pear nutrition"
    ]
    
    print(f"Running {len(probes)} probes...")
    results = run_probes(core, embed_text, probes)
    
    # 3. Acceptance Checks
    all_passed = True
    for res in results:
        print(f"\nProbe: {res['probe']}")
        print(f"  Intra-coherence (Top 16): {res['intra_coherence']:.4f}")
        if res['intra_coherence'] >= 0.6:
            print("  PASS: Coherence >= 0.6")
        else:
            print("  FAIL: Coherence too low.")
            all_passed = False
            
    # 4. Save Metrics
    save_metrics(results, "metrics/kernel_tuning.csv")
    
    # 5. Domain Sensitivity Check (Polarity Margin)
    # Compare "Apple (fruit)" similarity to Fruit vs Tech
    v_apple_fruit = embed_text("Apple (fruit) nutrition")
    v_fruit_axis = embed_text("[fruit]")
    v_tech_axis = embed_text("[tech]")
    
    sim_fruit = np.dot(v_apple_fruit, v_fruit_axis)
    sim_tech = np.dot(v_apple_fruit, v_tech_axis)
    margin = sim_fruit - sim_tech
    
    print(f"\nPolarity Check (Apple Fruit):")
    print(f"  Sim to Fruit: {sim_fruit:.4f}")
    print(f"  Sim to Tech: {sim_tech:.4f}")
    print(f"  Margin: {margin:.4f}")
    
    if margin >= 0.15:
        print("  PASS: Polarity margin >= 0.15")
    else:
        print("  FAIL: Polarity margin too small.")
        all_passed = False

    if all_passed:
        print("\n=== PHASE 5 SUCCESS ===")
    else:
        print("\n=== PHASE 5 PARTIAL COMPLETION (Tuning needed) ===")

if __name__ == "__main__":
    main()
