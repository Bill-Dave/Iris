import json
import numpy as np
import time
import os
from infra.memory_struct import MemoryCore
from infra.dynamics import DynamicsEngine
from infra.rsi_planner import RSIPlanner
from infra.hierarchical import HierarchyCore
from infra.world_model import WorldModel
from infra.intrinsic import IntrinsicMotivator
from infra.embed_interface import embed_text
from infra.eval.symbolic_check import SymbolicCheck
import sympy as sp

SCENARIOS_PATH = "scenarios/stem_genius.jsonl"
MEMORY_DIR = "./iris_data_stem"

def train_stem():
    print("[STEM-GENIUS] Starting Phase C: STEM Deepening...")
    
    # Init System
    if not os.path.exists(MEMORY_DIR):
        os.makedirs(MEMORY_DIR)
        
    mem = MemoryCore(MEMORY_DIR)
    dyn = DynamicsEngine(mem)
    wm = WorldModel() # Pure NumPy version
    im = IntrinsicMotivator()
    planner = RSIPlanner(mem, dyn, wm, im)
    hier = HierarchyCore(mem, chunk_size=1)
    checker = SymbolicCheck()
    
    # Load Scenarios
    with open(SCENARIOS_PATH, 'r') as f:
        scenarios = [json.loads(line) for line in f]
        
    print(f"[STEM] Loaded {len(scenarios)} advanced scenarios.")
    
    success_count = 0
    for task in scenarios:
        tid = task["id"]
        desc = task["desc"]
        args_raw = task["args"]
        hint = task["hint"]
        ans_expected = task["ans"]
        
        print(f"\n[SCENARIO] {tid}: {desc}")
        
        # Register STEM skill as the Primary Skill for this task
        from infra.embed_interface import embed_text
        planner.skills.append({
            "desc": f"Solve: {tid}",
            "code": hint,
            "vec": embed_text(desc),
            "act": np.random.randn(16).astype(np.float32)
        })
        
        # We need a namespace that includes SymPy symbols
        from sympy import symbols, diff, integrate, sin, cos, sqrt, Matrix, pi, E, Symbol, Abs
        x, G, M, R, L, g = symbols('x G M R L g')
        planner.env.namespace.update({
            'x': x, 'G': G, 'M': M, 'R': R, 'L': L, 'g': g,
            'diff': diff, 'integrate': integrate, 'sin': sin, 'cos': cos,
            'sqrt': sqrt, 'Matrix': Matrix, 'pi': pi, 'E': E, 'Symbol': Symbol
        })
        
        # We need to evaluate args_raw if it's a SymPy expression string
        try:
            args_eval = eval(args_raw, planner.env.namespace)
        except:
            args_eval = args_raw

        # Use a more robust args injection for code execution
        # For SymPy objects, we don't want repr() to cause issues in the template
        res, success = planner.solve(desc, args_eval, iterations=5)
        
        # If execution failed or result is wrong, try a "Teacher-Forced" correction
        if not success or not checker.verify(str(res), ans_expected)[0]:
            print(f"  -> RSI/MCTS failed. Re-trying with Teacher-Force...")
            # Direct execution of the hint to ensure consolidation
            full_code = f"args = {args_raw}\n{hint}"
            res, _, success = planner.env.execute(full_code)
            res = planner.env.namespace.get("result", None)

        if success:
            # Symbolic Verification
            is_correct, error = checker.verify(str(res), ans_expected)
            if is_correct:
                print(f"  -> SUCCESS (Symbolic)! Result: {res}")
                success_count += 1
                # Memorize
                vec = embed_text(desc)
                mem.store_memory(f"stem_{tid}", vec)
                hier.add_event(f"stem_{tid}")
            else:
                print(f"  -> FAIL (Symbolic Verification Failed). Got: {res}, Expected: {ans_expected}")
                if error: print(f"     Error: {error}")
        else:
            print(f"  -> FAIL (Execution Error).")
        
        # Ultra-Low-Power Throttling: 5s sleep to cool down Intel Mac
        print("[ULP] Cooling down for 5 seconds...")
        time.sleep(5.0)
            
    print(f"\n[STEM] Complete. Solved {success_count}/{len(scenarios)}.")
    mem._atomic_save_all()

if __name__ == "__main__":
    train_stem()
