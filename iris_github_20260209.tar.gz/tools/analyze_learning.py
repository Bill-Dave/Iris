import os
import json
import numpy as np
from infra.memory_struct import MemoryCore
from infra.kit_engine_v3 import KITEngineV3
from infra.embed_interface import embed_text

def analyze_query(query_text):
    mem_dir = "./iris_data_genius"
    mem = MemoryCore(mem_dir)
    kit = KITEngineV3(mem)
    
    query_vec = embed_text(query_text)
    candidates = [c[0] for c in mem.find_nearest(query_vec, n=10)]
    
    # Run with history
    assembly, history = kit.solve_evolution(query_text, query_vec, candidates, return_history=True)
    
    # Save CSV
    out_file = f"analysis/trajectory_{query_text.replace(' ', '_')[:30]}.csv"
    os.makedirs("analysis", exist_ok=True)
    
    with open(out_file, "w") as f:
        # Header: step, s_shard1, s_shard2, ...
        header = ["step"] + candidates
        f.write(",".join(header) + "\n")
        
        for step, s in enumerate(history):
            row = [str(step)] + [f"{val:.4f}" for val in s]
            f.write(",".join(row) + "\n")
            
    print(f"[ANALYSIS] Cognitive trajectory saved to: {out_file}")
    
    # Generate simple ASCII plot of the top shard
    top_shard_idx = candidates.index(assembly[0][0]) if assembly else 0
    top_history = history[:, top_shard_idx]
    
    print(f"\n[ANALYSIS] Salience Trajectory for Top Shard ({candidates[top_shard_idx]}):")
    for i, val in enumerate(top_history):
        bar = "#" * int(val * 40)
        print(f"  Step {i:02}: {val:.4f} | {bar}")

if __name__ == "__main__":
    import sys
    q = " ".join(sys.argv[1:]) if len(sys.argv) > 1 else "Who are you?"
    analyze_query(q)
