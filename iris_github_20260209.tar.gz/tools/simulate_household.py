import numpy as np
from infra.embed_interface import embed_text

class HouseholdSim:
    def __init__(self):
        self.state = {
            "temp": 20.0,
            "energy": 100.0,
            "cleanliness": 10.0,
            "time": 0
        }
        self.action_dim = 16
        
    def reset(self):
        self.state = {"temp": 20.0, "energy": 100.0, "cleanliness": 10.0, "time": 0}
        return self._observe()
        
    def step(self, action_vec):
        # Action vec (16,) -> specific command
        # Simple discretization
        cmd = np.argmax(action_vec[:4]) # First 4 dims
        
        # Dynamics
        if cmd == 0: # Heater
            self.state["temp"] += 1.0
            self.state["energy"] -= 2.0
        elif cmd == 1: # AC
            self.state["temp"] -= 1.0
            self.state["energy"] -= 2.0
        elif cmd == 2: # Clean
            self.state["cleanliness"] += 2.0
            self.state["energy"] -= 5.0
        else: # Idle
            self.state["temp"] += 0.1 * (np.random.rand() - 0.5) # Drift
            
        # Natural decay
        self.state["cleanliness"] -= 0.1
        self.state["time"] += 1
        
        return self._observe()
        
    def _observe(self):
        # Textual description -> Embedded
        desc = f"Time {self.state['time']}. Temp {self.state['temp']:.1f}. Energy {self.state['energy']:.1f}. Clean {self.state['cleanliness']:.1f}."
        vec = embed_text(desc)
        return vec

if __name__ == "__main__":
    sim = HouseholdSim()
    obs = sim.reset()
    print("Obs shape:", obs.shape)
