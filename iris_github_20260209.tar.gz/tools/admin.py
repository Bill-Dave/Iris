import argparse
import sys
import os
import requests
import json

# Add project root
sys.path.append(os.getcwd())

from infra.approval import ApprovalGate
from infra.journal import journal

API_URL = "http://localhost:8000"
GATE = ApprovalGate()

def active_admin_token():
    # Helper to get the single-user token for API calls
    # This is different from the multi-party approval keys
    path = os.path.expanduser("~/.iris_admin_key")
    if os.path.exists(path):
        with open(path, 'r') as f:
            return f.read().strip()
    return ""

def cmd_reset(args):
    # Destructive -> Requires 2 keys
    if not GATE.verify_approval(args.keys, "RESET"):
        print("[ADMIN] Approval Failed. Destructive operation reset requires 2 admin keys.")
        return
        
    print("[ADMIN] Approval Granted. Resetting System...")
    # Log to journal
    journal.log_action("ADMIN_CLI", "RESET", {"approved_by": len(args.keys)})
    
    # Call API (Headless Engine)
    try:
        res = requests.post(f"{API_URL}/reset", headers={"X-Iris-Token": active_admin_token()})
        print(f"[API] {res.status_code}: {res.text}")
    except Exception as e:
        print(f"[API] Error: {e}")

def cmd_restore(args):
    if not GATE.verify_approval(args.keys, f"RESTORE:{args.tag}"):
        print("[ADMIN] Approval Failed. Restore requires 2 admin keys.")
        return
    
    print(f"[ADMIN] Approval Granted. Restoring snapshot {args.tag}...")
    journal.log_action("ADMIN_CLI", "RESTORE", {"tag": args.tag})
    
    try:
        res = requests.post(f"{API_URL}/restore/{args.tag}", headers={"X-Iris-Token": active_admin_token()})
        print(f"[API] {res.status_code}: {res.text}")
    except Exception as e:
        print(f"[API] Error: {e}")

def cmd_status(args):
    # Public
    try:
        res = requests.get(f"{API_URL}/status", headers={"X-Iris-Token": active_admin_token()})
        data = res.json()
        print(json.dumps(data, indent=2))
    except Exception as e:
        print(f"[API] connection error. Is 'infra/api.py' running? ({e})")

def cmd_freeze(args):
    # Operational -> Requires 1 key (Standard)
    # Actually, let's say 1 key is enough for day-to-day
    # But approval gate checks against store efficiently.
    if len(args.keys) < 1:
        print("[ADMIN] Freeze requires at least 1 admin key.")
        return
    
    if not GATE.verify_approval(args.keys, f"FREEZE:{args.id}"):
         print("[ADMIN] Key invalid.")
         return

    journal.log_action("ADMIN_CLI", "FREEZE", {"id": args.id})
    try:
        res = requests.post(f"{API_URL}/freeze/{args.id}", headers={"X-Iris-Token": active_admin_token()})
        print(f"[API] {res.status_code}: {res.text}")
    except Exception as e:
        print(f"[API] Error: {e}")

def main():
    parser = argparse.ArgumentParser(description="Iris Admin CLI")
    subparsers = parser.add_subparsers(dest="command")
    
    # Reset
    p_reset = subparsers.add_parser("reset")
    p_reset.add_argument("--keys", nargs="+", default=[], help="Admin keys")
    
    # Restore
    p_restore = subparsers.add_parser("restore")
    p_restore.add_argument("tag", help="Snapshot tag")
    p_restore.add_argument("--keys", nargs="+", default=[], help="Admin keys")
    
    # Status
    p_status = subparsers.add_parser("status")
    
    # Freeze
    p_freeze = subparsers.add_parser("freeze")
    p_freeze.add_argument("id", help="Item ID")
    p_freeze.add_argument("--keys", nargs="+", default=[], help="Admin keys")

    args = parser.parse_args()
    
    if args.command == "reset": cmd_reset(args)
    elif args.command == "restore": cmd_restore(args)
    elif args.command == "status": cmd_status(args)
    elif args.command == "freeze": cmd_freeze(args)
    else: parser.print_help()

if __name__ == "__main__":
    main()
