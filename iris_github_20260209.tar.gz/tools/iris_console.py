import os
import sys
import json
import time
import numpy as np
from typing import List, Tuple

# Ensure Iris package is in path
sys.path.append(os.getcwd())

from infra.memory_struct import MemoryCore
from infra.kit_engine_v3 import KITEngineV3
from infra.voice import VoiceEngine
from infra.embed_interface import embed_text

class IrisConsole:
    def __init__(self, memory_dir="./iris_data_genius"):
        print("[BOOT] Launching Iris Cognitive Architecture...")
        self.mem = MemoryCore(memory_dir)
        self.kit = KITEngineV3(self.mem)
        self.voice = VoiceEngine(self.mem)
        
        # Load identity axioms
        self.axiom_path = "data/raw/baseline/founder_narrative_axioms.txt"
        self.identity_context = ""
        if os.path.exists(self.axiom_path):
            with open(self.axiom_path, 'r') as f:
                self.identity_context = f.read()

    def live_ingest(self, user_input: str):
        """
        NLL Utility: Shards important founder instructions into permanent memory.
        """
        if len(user_input.split()) > 10:
            cka_id = f"cka_live_{int(time.time())}"
            vec = embed_text(user_input)
            self.mem.store_cka(
                cka_id=cka_id,
                content=user_input,
                x_vec=vec,
                domain=["founder_interaction"],
                activation_profile={"triggers": ["iris", "founder", "instruction"]}
            )
            return True
        return False

    def chat_cycle(self, user_query: str):
        # 1. Perception
        query_vec = embed_text(user_query)
        candidates = [c[0] for c in self.mem.find_nearest(query_vec, n=15)]
        
        # 2. Reasoning (KIT Assembly)
        assembly = self.kit.solve_evolution(user_query, query_vec, candidates)
        
        # 3. Voice Synthesis (Direct Narrative Mode)
        response = self.voice.synthesize_assembly(user_query, assembly)
        
        # 4. Live Learning
        if self.live_ingest(user_query):
            response += "\n\n[IRIS] I have integrated this instruction into my axial foundations."
            
        return response

    def run(self):
        print("\n" + "="*50)
        print("IRIS SOVEREIGN CONSOLE v1.0")
        print("Architect: Davies Bilayi Kalori")
        print("="*50)
        print("\n[IRIS] Greetings. I am active and connected to my axial foundations. How shall we evolve today?")
        
        while True:
            try:
                user_in = input("\n[FOUNDER] > ")
                if user_in.lower() in ["exit", "quit", "sleep"]:
                    print("[IRIS] Transitioning to background stability mode. Goodbye.")
                    break
                
                if not user_in.strip(): continue
                
                response = self.chat_cycle(user_in)
                print(f"\n[IRIS] {response}")
                
            except KeyboardInterrupt:
                break
            except Exception as e:
                print(f"\n[ERROR] Resonance failure: {e}")

if __name__ == "__main__":
    console = IrisConsole()
    console.run()
