import numpy as np

class PendulumSim:
    def __init__(self):
        self.theta = np.pi / 4
        self.omega = 0.0
        self.g = 9.8
        self.L = 1.0
        self.dt = 0.05

    def step(self, action):
        torque = action[0] # first dim of act
        alpha = - (self.g / self.L) * np.sin(self.theta) + torque
        self.omega += alpha * self.dt
        self.theta += self.omega * self.dt
        state = np.zeros(384)
        state[0] = self.theta
        state[1] = self.omega
        return state

def run_sim_demo():
    sim = PendulumSim()
    for _ in range(10):
        s = sim.step(np.random.randn(16))
        print(f"Sim State: {s[:2]}")

if __name__ == "__main__":
    run_sim_demo()
