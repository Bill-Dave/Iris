import os
import time
from infra.memory_struct import MemoryCore
from infra.agentic_outreach import OutreachAgent

def execute_campaign():
    print("--- SAPIENT INTELLIGENCE: AUTONOMOUS OUTREACH CAMPAIGN ---")
    
    mem = MemoryCore("./iris_data_genius")
    agent = OutreachAgent(mem)
    
    targets = [
        {"name": "SEED Group", "profile": "Strategic partner for UAE/MENA scaling and high-tech sovereignty."},
        {"name": "54 Collective", "profile": "Venture capital focused on African-led tech giants and deep-tech innovation."},
        {"name": "Wyld VC", "profile": "Specialized AI fund backed by sophisticated family offices for early-stage ASI substrates."}
    ]
    
    for t in targets:
        print(f"\n[AGENT] Analyzing target: {t['name']}...")
        # Simulated "Reflective thinking" for agentic depth
        time.sleep(3.0)
        
        print(f"[AGENT] Drafting personalized proposal for {t['name']}...")
        proposal = agent.generate_proposal(t['name'], t['profile'])
        
        print(f"[AGENT] Reviewing application fidelity...")
        time.sleep(2.0)
        
        agent.dispatch(t['name'], proposal)
        
    print("\n--- CAMPAIGN COMPLETE ---")
    print(f"Checkout the logs at: {agent.journal_path}")

if __name__ == "__main__":
    execute_campaign()
