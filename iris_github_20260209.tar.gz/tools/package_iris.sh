#!/bin/bash
# ===============================================================================
# IRIS UNIFIED BRAIN - COMPLETE PACKAGE BUILDER
# ===============================================================================
# Creates the most comprehensive AI brain package ever built.
# Includes ALL 70+ modules, knowledge base, training data, and UI.
# 
# Architect: Davies Bilayi Kalori
# Framework: Sapient Intelligence / KIT / APRA / GORE
# ===============================================================================

echo "==============================================================================="
echo "  ██╗██████╗ ██╗███████╗    ██████╗  █████╗  ██████╗██╗  ██╗ █████╗  ██████╗ ███████╗"
echo "  ██║██╔══██╗██║██╔════╝    ██╔══██╗██╔══██╗██╔════╝██║ ██╔╝██╔══██╗██╔════╝ ██╔════╝"
echo "  ██║██████╔╝██║███████╗    ██████╔╝███████║██║     █████╔╝ ███████║██║  ███╗█████╗  "
echo "  ██║██╔══██╗██║╚════██║    ██╔═══╝ ██╔══██║██║     ██╔═██╗ ██╔══██║██║   ██║██╔══╝  "
echo "  ██║██║  ██║██║███████║    ██║     ██║  ██║╚██████╗██║  ██╗██║  ██║╚██████╔╝███████╗"
echo "  ╚═╝╚═╝  ╚═╝╚═╝╚══════╝    ╚═╝     ╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝ ╚══════╝"
echo "==============================================================================="
echo "    THE MOST COMPLETE AI BRAIN ARCHITECTURE EVER BUILT"
echo "    Architect: Davies Bilayi Kalori"
echo "==============================================================================="

PACKAGE_DIR="./package_output"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)

# Create output directory
rm -rf "$PACKAGE_DIR/build_temp"
mkdir -p "$PACKAGE_DIR/build_temp"

echo ""
echo "[PHASE 1/6] Collecting ALL Python modules..."

# Create a list of all files to include
FILES_TO_INCLUDE=(
    # Main entry points
    "iris.py"
    "iris_minimal.py"
    "iris_unified.py"
    "iris_brain.py"
    "iris_server.py"
    
    # Complete infrastructure (ALL files)
    "infra/*.py"
    "infra/eval/*.py"
    "infra/training/*.py"
    
    # Core components
    "iris_core/dynamics/*.py"
    "iris_core/memory/*.py"
    
    # All tools (training, chat, debugging)
    "tools/*.py"
    "tools/*.sh"
    
    # UI components
    "ui/*.py"
    "ui/*.html"
    "ui/*.css"
    
    # Training scenarios and curricula
    "scenarios/*.jsonl"
    
    # Data and knowledge
    "data/raw/baseline/*.txt"
    "data/raw/outreach/*.txt"
    
    # Knowledge databases (ALL)
    "iris_data_genius/*"
    "iris_data_stem/*"
    "iris_data_socio/*"
    "iris_data_code/*"
    "iris_data_trained/*"
    
    # Configuration
    "admin_keys.json"
)

# Count files
echo "[PHASE 2/6] Counting files..."
TOTAL_PY=$(find . -name "*.py" -type f 2>/dev/null | wc -l | tr -d ' ')
TOTAL_DATA=$(find . -name "iris_data_*" -type d 2>/dev/null | wc -l | tr -d ' ')
echo "           Python modules: $TOTAL_PY"
echo "           Data directories: $TOTAL_DATA"

echo "[PHASE 3/6] Creating COMPLETE Mac package..."

MAC_ARCHIVE="$PACKAGE_DIR/iris_unified_brain_mac_$TIMESTAMP.tar.gz"

# Use tar to include everything, excluding cache and temp files
tar -czf "$MAC_ARCHIVE" \
    --exclude='__pycache__' \
    --exclude='*.pyc' \
    --exclude='.pytest_cache' \
    --exclude='*.tar.gz' \
    --exclude='package_output' \
    --exclude='snapshots' \
    --exclude='preservation' \
    --exclude='server_logs' \
    --exclude='phase6_lesson_*' \
    iris.py iris_minimal.py iris_unified.py iris_brain.py \
    iris_server.py iris_ui.html \
    infra tools ui iris_core scenarios data \
    iris_data_genius iris_data_stem iris_data_socio \
    iris_data_code iris_data_trained iris_data_cons \
    iris_data_hebb iris_data_lock iris_data_rsi \
    admin_keys.json library 2>/dev/null

if [ -f "$MAC_ARCHIVE" ]; then
    MAC_SIZE=$(du -h "$MAC_ARCHIVE" | cut -f1)
    echo "           ✓ Mac archive created: $MAC_ARCHIVE"
    echo "           Size: $MAC_SIZE"
else
    echo "           ✗ Failed to create Mac archive"
fi

echo "[PHASE 4/6] Creating COMPLETE Android (Termux) package..."

ANDROID_ARCHIVE="$PACKAGE_DIR/iris_unified_brain_android_$TIMESTAMP.tar.gz"
cp "$MAC_ARCHIVE" "$ANDROID_ARCHIVE" 2>/dev/null

if [ -f "$ANDROID_ARCHIVE" ]; then
    echo "           ✓ Android archive created: $ANDROID_ARCHIVE"
else
    echo "           ✗ Failed to create Android archive"
fi

echo "[PHASE 5/6] Creating requirements and documentation..."

# Requirements file
cat > "$PACKAGE_DIR/requirements.txt" << 'EOF'
# ===============================================
# IRIS UNIFIED BRAIN - Dependencies
# ===============================================
# Core
numpy>=1.21.0

# Embeddings
sentence-transformers>=2.2.0
faiss-cpu>=1.7.0

# UI
pywebview>=4.0.0

# API (Optional)
fastapi>=0.68.0
uvicorn>=0.15.0

# Math (Optional)
sympy>=1.9
EOF

# README
cat > "$PACKAGE_DIR/README.md" << 'EOF'
# IRIS UNIFIED BRAIN
## The Most Complete AI Cognitive Architecture

### Quick Start

#### Mac (Desktop UI)
```bash
# Extract
tar -xzf iris_unified_brain_mac_*.tar.gz

# Install dependencies
pip3 install numpy sentence-transformers faiss-cpu pywebview

# Launch with UI
python3 ui/iris_app.py

# Or interactive console
python3 iris_brain.py
```

#### Android (Termux)
```bash
# In Termux
pkg install python numpy
pip3 install sentence-transformers

# Extract and launch
tar -xzf iris_unified_brain_android_*.tar.gz
python3 iris_brain.py
```

#### Verify Installation
```bash
python3 iris_brain.py --verify
```

### Components Included
- **70+ Python modules** - Complete cognitive infrastructure
- **Brain Synchronization** - Neural bus, thalamic routing
- **KIT Engine v3** - Knowledge Interference Theory
- **GORE/APRA Planner** - Goal-oriented strategic planning
- **Sparse Attention** - Energy-efficient reasoning
- **Self-Improvement** - Mutation Engine, Cognitive Crucible
- **Knowledge Stream** - Wikipedia, Web, Local ingestion
- **Premium UI** - Orange/Black Apple-like theme

### Architecture
```
┌─────────────────────────────────────────────────────────────┐
│                    IRIS UNIFIED BRAIN                       │
│  ┌─────────────┐    ┌──────────────┐    ┌─────────────┐    │
│  │   LEFT      │    │   THALAMIC   │    │   RIGHT     │    │
│  │ HEMISPHERE  │◄──►│    ROUTER    │◄──►│ HEMISPHERE  │    │
│  │ STEM/Logic  │    │              │    │ Socio/Voice │    │
│  └─────────────┘    └──────────────┘    └─────────────┘    │
│         │                  │                  │             │
│         └────────────┬─────┴─────┬───────────┘             │
│                      │   NEURAL  │                          │
│                      │    BUS    │                          │
│                      └─────┬─────┘                          │
│  ┌─────────────┐    ┌──────▼─────┐    ┌─────────────┐      │
│  │ KNOWLEDGE   │◄──►│  MEMORY    │◄──►│   CORPUS    │      │
│  │   STREAM    │    │   CORE     │    │  CALLOSUM   │      │
│  └─────────────┘    └────────────┘    └─────────────┘      │
└─────────────────────────────────────────────────────────────┘
```

### Architect
Davies Bilayi Kalori | Sapient Intelligence
EOF

echo "           ✓ Requirements and README created"

echo "[PHASE 6/6] Final summary..."

echo ""
echo "==============================================================================="
echo "  PACKAGING COMPLETE"
echo "==============================================================================="
echo ""
echo "  Output Directory: $PACKAGE_DIR"
echo ""
echo "  Files Created:"
ls -la "$PACKAGE_DIR"/*.tar.gz 2>/dev/null | awk '{print "    " $NF " (" $5 " bytes)"}'
echo ""
echo "  LAUNCH COMMANDS:"
echo "  ─────────────────────────────────────────────────────────────"
echo "  Mac UI:          python3 ui/iris_app.py"
echo "  Console:         python3 iris_brain.py"
echo "  Verify:          python3 iris_brain.py --verify"
echo "  Bootstrap:       python3 iris_brain.py --bootstrap"
echo "  ─────────────────────────────────────────────────────────────"
echo ""
echo "  THE WORLD'S MOST COMPLETE AI BRAIN PACKAGE IS READY."
echo "==============================================================================="
