import os
import time
import pickle
import numpy as np
from infra.memory_struct import MemoryCore
from infra.production_retriever import TieredRetriever
from infra.kit_engine_v2 import KITEngineV2
from infra.governor import ThermalGovernor
from infra.voice import VoiceEngine
from infra.embed_interface import embed_text

MEMORY_DIR = "./iris_data_genius"

def production_chat():
    print("\n--- IRIS AGI: APRA PRODUCTION INTERFACE (ULP MODE) ---")
    
    # 1. Initialize Core
    mem = MemoryCore(MEMORY_DIR)
    retriever = TieredRetriever(mem)
    kit = KITEngineV2(mem)
    gov = ThermalGovernor(cpu_threshold=0.8)
    voice = VoiceEngine(mem)
    
    # Load Tier A Index
    idx_path = os.path.join(MEMORY_DIR, "inverted_index.pkl")
    if os.path.exists(idx_path):
        with open(idx_path, 'rb') as f:
            retriever.inverted_index = pickle.load(f)
        retriever.doc_lengths = np.load(os.path.join(MEMORY_DIR, "doc_lengths.npy"))
        print("[SYSTEM] Tier A Index Loaded.")
    else:
        print("[WARNING] Tier A Index missing. Results will be degraded.")

    print(voice.greet())

    try:
        while True:
            user_input = input("\n[USER] > ")
            if user_input.lower() in ["exit", "quit", "bye"]:
                print("[IRIS] Terminating engagement. Snapshotting cognitive state...")
                break

            # --- APRA STEP 1: Governance ---
            config = gov.check_system_state()
            
            # --- APRA STEP 2: Tiered Retrieval ---
            t0 = time.time()
            # Tier A (Sparse)
            candidates_a = retriever.query_tier_a(user_input, k=config["N_c"])
            
            # Tier B (Semantic Rerank)
            if config["use_tier_b"]:
                candidates = retriever.query_tier_b(user_input, candidates_a, k=64)
            else:
                candidates = candidates_a[:64]
            
            retrieval_time = time.time() - t0
            
            # --- APRA STEP 3: KIT Reasoning ---
            t1 = time.time()
            query_vec = embed_text(user_input)
            candidate_ids = [c[0] for c in candidates]
            assembly = kit.solve_assembly(query_vec, candidate_ids)
            reasoning_time = time.time() - t1
            
            # --- APRA STEP 4: Synthesis ---
            # Extract text from top assembly shards
            shards_text = []
            for uid, salience in assembly[:3]: # Top 3 shards for brevity
                shard = mem.data_store.get(uid, "")
                shards_text.append(shard)
            
            raw_logic = " ".join(shards_text)
            
            # Use Voice Engine to polish
            print(f"[IRIS] (Thinking: {reasoning_time:.2f}s | Load: {config['load']:.2f})...")
            
            # Thermal mandatory delay
            gov.sleep_reflective(2.0)
            
            response = voice.synthesize(user_input, raw_logic)
            print(f"\n[IRIS] {response}")
            
            # Log Trace
            with open(os.path.join(MEMORY_DIR, "perf.jsonl"), 'a') as f:
                import json
                f.write(json.dumps({
                    "t": time.time(),
                    "retr_s": retrieval_time,
                    "reas_s": reasoning_time,
                    "load": config["load"],
                    "asm_size": len(assembly)
                }) + "\n")

    except KeyboardInterrupt:
        print("\n[SYSTEM] Engagement interrupted.")

if __name__ == "__main__":
    production_chat()
