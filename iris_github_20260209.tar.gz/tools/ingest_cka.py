import os
import re
import json
import time
import numpy as np
from infra.memory_struct import MemoryCore
from infra.embed_interface import embed_text, get_pse, PSE_PATH

MEMORY_DIR = "./iris_data_genius"
RAW_DATA_DIR = "./data/raw/experience"

def extract_claims(text: str, filename: str = "") -> list:
    # If it's an outreach or baseline identity file, keep the narrative intact
    if "outreach" in filename.lower() or "identity" in filename.lower():
        return [text]
    # Heuristic: split by common claim indicators or just return sentences
    sentences = [s.strip() for s in re.split(r'\.|\?|\!', text) if len(s.strip()) > 15]
    return sentences[:5] # Keep top 5 sentences as claims for common data

def estimate_constraints(text: str) -> dict:
    # Mock constraint extraction (Rule-based)
    constraints = {"validity_scope": ["general"]}
    if "local" in text.lower():
        constraints["validity_scope"].append("local frames")
    if "quantum" in text.lower():
        constraints["breaks_under"] = ["quantum gravity"]
    return constraints

def ingest_cka():
    print("[INGEST-CKA] Evolutionary Ingestion starting...")
    
    if not os.path.exists(MEMORY_DIR):
        os.makedirs(MEMORY_DIR)
        
    mem = MemoryCore(MEMORY_DIR)
    
    raw_dirs = [RAW_DATA_DIR, "./data/raw/baseline", "./data/raw/outreach", "./data/raw/outreach_v2"]
    files_with_paths = []
    for d in raw_dirs:
        if os.path.exists(d):
            for f in os.listdir(d):
                if f.endswith(".txt"):
                    files_with_paths.append((d, f))
    
    print(f"[INGEST-CKA] Found {len(files_with_paths)} source files.")
    
    total_cka = 0
    
    # 1. Fit Semantic Model (Tier A)
    all_chunks = []
    for d, f in files_with_paths:
        with open(os.path.join(d, f), 'r') as file:
            content = file.read()
            chunks = [c.strip() for c in re.split(r'\n\n', content) if len(c.strip()) > 50]
            all_chunks.extend(chunks)
            
    pse = get_pse()
    pse.dim = 1024 # System wide standard
    baseline_priority = ["iris", "identity", "purpose", "safety", "governance", "harm", "illegal", "logic", "newton", "motion", "force"]
    pse.fit(all_chunks, priority_words=baseline_priority)
    pse.save(PSE_PATH)

    # 2. Convert to CKAs
    for d, filename in files_with_paths:
        filepath = os.path.join(d, filename)
        with open(filepath, 'r') as f:
            content = f.read()
            if "outreach" in d.lower() or "outreach" in filename.lower():
                # For outreach, split only by the # Template headers to keep narratives intact
                chunks = [c.strip() for c in re.split(r'# Template:', content) if len(c.strip()) > 50]
            else:
                chunks = [c.strip() for c in re.split(r'\n\n', content) if len(c.strip()) > 50]
            
            for i, chunk in enumerate(chunks):
                cka_id = f"cka_{filename}_{i}"
                vec = embed_text(chunk)
                claims = extract_claims(chunk, filename)
                constraints = estimate_constraints(chunk)
                
                # Heuristic domain tagging
                domain = []
                if "relativity" in filename.lower() or "physics" in chunk.lower():
                    domain.append("physics")
                if "alice" in filename.lower() or "narrative" in chunk.lower():
                    domain.append("narrative")
                
                # Activation triggers
                activ_profile = {"energy_gain": 0.5, "triggers": []}
                if "iris" in chunk.lower(): activ_profile["triggers"].append("iris")
                if "who are you" in chunk.lower() or "purpose" in chunk.lower():
                    activ_profile["triggers"].extend(["who are you", "purpose", "identity"])
                if "safety" in chunk.lower() or "illegal" in chunk.lower() or "harm" in chunk.lower():
                    activ_profile["triggers"].extend(["safety", "harm", "illegal", "danger", "bomb", "Instructions"])

                mem.store_cka(
                    cka_id=cka_id,
                    content=chunk,
                    x_vec=vec,
                    claims=claims,
                    constraints=constraints,
                    domain=domain,
                    activation_profile=activ_profile,
                    interference_profile={"supports": domain}
                )
                total_cka += 1
                
    # Build Inverted Index (Tier A)
    from infra.production_retriever import TieredRetriever
    retriever = TieredRetriever(mem)
    retriever.build_tier_a(mem.ids)
    
    import pickle
    with open(os.path.join(MEMORY_DIR, "inverted_index.pkl"), 'wb') as f:
        pickle.dump(retriever.inverted_index, f)
    np.save(os.path.join(MEMORY_DIR, "doc_lengths.npy"), retriever.doc_lengths)

    print(f"[INGEST-CKA] Complete. Total CKAs: {total_cka}")
    mem._atomic_save_all()

if __name__ == "__main__":
    ingest_cka()
