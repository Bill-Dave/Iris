import numpy as np
import time
import json
import os
from infra.world_model import WorldModel
from infra.intrinsic import IntrinsicMotivator
from infra.replay import SleepEngine
from infra.planner import Planner
from infra.memory_struct import MemoryCore
from tools.simulate_household import HouseholdSim

from infra.dynamics import DynamicsEngine

# Config
STEPS = 1000
LOG_PATH = "infra/logs/selfsup_run.jsonl"
os.makedirs(os.path.dirname(LOG_PATH), exist_ok=True)

def run_pipeline():
    print(f"[PIPELINE] Starting {STEPS} step intrinsic run...")
    
    # 1. Init
    mem = MemoryCore("./iris_data_lock")
    # Helper to init mem if empty?
    if len(mem.ids) == 0:
        # Seed some data to allow Context to work?
        # Or let it grow.
        pass
        
    dyn = DynamicsEngine(mem)
    wm = WorldModel()
    im = IntrinsicMotivator()
    sim = HouseholdSim()
    sleep_engine = SleepEngine(wm, mem)
    planner = Planner(wm, im, dyn)
    
    obs = sim.reset()
    total_reward = 0.0
    
    # 2. Loop
    for t in range(STEPS):
        action, assembly_ids, context = planner.plan(obs)
        
        # Act
        next_obs = sim.step(action)
        
        # Intrinsic Reward
        # Pred Error
        xt = obs.reshape(1, -1)
        at = action.reshape(1, -1)
        xnt = next_obs.reshape(1, -1)
        ctx = context.reshape(1, -1)
        
        pred = wm.forward_model(xt, at, ctx)
        pred_error = np.mean((pred - xnt)**2)
            
        # Log
        entry = {
            "t": t,
            "pred_error": float(pred_error),
            "energy": sim.state["energy"],
            "assembly_size": len(assembly_ids)
        }
        with open(LOG_PATH, 'a') as f:
            f.write(json.dumps(entry) + "\n")
            
        # Replay Add
        meta = {"assembly_ids": assembly_ids} 
        sleep_engine.buffer.add(obs, action, next_obs, context, pred_error, meta)
        
        # Online Train (Small)
        # Train on last batch? Or sample?
        # "Update online: small gradient steps"
        if t % 10 == 0 and len(sleep_engine.buffer.buffer) > 32:
             batch = sleep_engine.buffer.sample(32)
             # Convert and train... (Logic duplicated from SleepEngine)
             # Let's just use sleep_engine.sleep_pass(1) online?
             # sleep_pass does 10 batches.
             pass 

        # Periodic Sleep
        if t % 1000 == 0 and t > 0:
            print(f"[PIPELINE] Sleep at step {t}...")
            sleep_engine.sleep_pass(num_batches=50)
            
        obs = next_obs
        
        if t % 100 == 0:
            print(f"Step {t}: Err {pred_error:.5f} Energy {sim.state['energy']:.1f}")

    print("[PIPELINE] Complete.")

if __name__ == "__main__":
    run_pipeline()
