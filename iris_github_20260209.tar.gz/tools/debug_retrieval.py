import numpy as np
import os
import json
from infra.memory_struct import MemoryCore
from infra.embed_interface import embed_text

MEMORY_DIR = "./iris_data_genius"

def debug_retrieval(query):
    print(f"--- DEBUG RETRIEVAL for: '{query}' ---")
    if not os.path.exists(MEMORY_DIR):
        print(f"[ERROR] Memory dir {MEMORY_DIR} missing.")
        return
        
    mem = MemoryCore(MEMORY_DIR)
    print(f"[DATA] Total IDs: {len(mem.ids)}")
    print(f"[DATA] Items in data_store: {len(mem.data_store)}")
    
    query_vec = embed_text(query)
    results = mem.find_nearest(query_vec, n=5)
    
    print("\n[RESULTS] Top 5 matches:")
    for i, (uid, score) in enumerate(results):
        data = mem.data_store.get(uid, "MISSING_IN_DATA_STORE")
        print(f"{i+1}. ID: {uid} | Score: {score:.4f}")
        print(f"   Snippet: {data[:100]}...")

if __name__ == "__main__":
    debug_retrieval("What is the Equivalence Principle?")
    print("\n")
    debug_retrieval("Alice and the Mouse")
