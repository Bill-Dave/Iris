import yaml
import os
import random

def generate_curriculum():
    # Deterministic seed for reproducibility
    random.seed(42)
    
    curriculum = []
    
    # Domain slices
    domains = {
        "physics": list(range(0, 666)),
        "ethics": list(range(667, 1333)),
        "business": list(range(1334, 2000))
    }
    
    domain_names = list(domains.keys())
    
    # We want 200 unique solutions
    # We'll pick 200 unique indices for solutions across all domains
    all_indices = list(range(2000))
    random.shuffle(all_indices)
    solution_pool = all_indices[:200]
    
    for i in range(200):
        domain_name = domain_names[i % 3]
        domain_indices = domains[domain_name]
        
        # Pick 2 random items from domain for the conflict
        items = random.sample(domain_indices, 2)
        
        # Pick 1 solution from our pre-shuffled pool
        sol_idx = solution_pool[i]
        
        lesson = {
            "id": f"CURR_{i+1:03d}",
            "context": f"{domain_name.capitalize()} Lesson {i+1}",
            "items": [f"doc_{idx:04d}" for idx in items],
            "positive_solution_ids": [f"doc_{sol_idx:04d}"],
            "schedule_day": (i // 10) + 1
        }
        curriculum.append(lesson)
        
    os.makedirs('teacher', exist_ok=True)
    with open('teacher/curriculum.yml', 'w') as f:
        yaml.dump(curriculum, f, sort_keys=False)
    
    print(f"[KIT] Generated 200 high-variety lessons in teacher/curriculum.yml")

if __name__ == "__main__":
    generate_curriculum()
