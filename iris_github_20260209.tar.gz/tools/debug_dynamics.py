import numpy as np
import sys
import os

sys.path.append(os.getcwd())
from kit_core import MemoryCore, InterferenceEngine

def debug():
    print("=== KIT DYNAMICS DEBUG ===")
    core = MemoryCore(dim=4, capacity_max=10.0, learning_rate=0.1)
    
    # Add one item
    core.add_item(np.array([1, 0, 0, 0], dtype=np.float32), "test_item")
    
    engine = InterferenceEngine(regularization_lambda=0.01, gamma=2.5)
    
    P = np.array([0.8])
    dt = 0.1
    
    print(f"Initial Salience: {core.salience}")
    print(f"Initial Energy: {engine.compute_energy(core, P):.4f}")
    
    for i in range(5):
        grads = engine.compute_gradients(core, P)
        print(f"Tick {i}: Grads={grads}, Salience={core.salience}")
        core.update_dynamics(grads, dt=dt)
        print(f"        Energy: {engine.compute_energy(core, P):.4f}")

if __name__ == "__main__":
    debug()
