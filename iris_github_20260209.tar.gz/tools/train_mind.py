import numpy as np
import json
import time
import os
from infra.memory_struct import MemoryCore
from infra.dynamics import DynamicsEngine
from infra.rsi_planner import RSIPlanner
from infra.hierarchical import HierarchyCore
from infra.world_model import WorldModel
from infra.intrinsic import IntrinsicMotivator
from infra.embed_interface import embed_text

SCENARIOS_PATH = "scenarios/core_skills.jsonl"
MEMORY_DIR = "./iris_data_trained"

def train_mind():
    print("[TRAIN] Starting Cognitive Training...")
    
    # 1. Init System
    mem = MemoryCore(MEMORY_DIR)
    dyn = DynamicsEngine(mem)
    wm = WorldModel()
    im = IntrinsicMotivator()
    planner = RSIPlanner(mem, dyn, wm, im)
    hier = HierarchyCore(mem, chunk_size=1) # Chunk every success immediately
    
    # 2. Load Scenarios
    with open(SCENARIOS_PATH, 'r') as f:
        scenarios = [json.loads(line) for line in f]
        
    print(f"[TRAIN] Loaded {len(scenarios)} scenarios.")
    
    # 3. Training Loop
    success_count = 0
    
    for task in scenarios:
        tid = task["id"]
        desc = task["desc"]
        args = task["args"]
        hint = task.get("hint", "")
        
        print(f"\n[SCENARIO] {tid}: {desc}")
        
        # 3a. Solve
        # We manually register the hint as a "Short Term Memory" skill
        # We pass the hint as "teacher_forcing" if we supported it.
        # For now, we updated the planner's internal list (rudimentary).
        # But wait, RSIPlanner uses `embed_text`.
        # We need to add the hint properly.
        
        # Let's manually register the hint as a "Short Term Memory" skill
        from infra.embed_interface import embed_text
        planner.skills.append({
            "desc": desc,
            "code": hint,
            "vec": embed_text(desc),
            "act": np.random.randn(16).astype(np.float32)
        })
        
        res, success = planner.solve(desc, args)
        
        if success:
            print(f"  -> SUCCESS! Result: {res}")
            success_count += 1
            # Memorize
            # 1. Store Atomic Skill Memory
            # We explicitly store the successful code as an atomic item
            atomic_id = f"skill_{tid}"
            # Embed the code or description? Description is better for retrieval.
            # But the 'vector' we store should be the Embedding of the Description.
            # Planner.skills has it?
            # We'll re-embed or grab from planner.
            vec = embed_text(desc)
            mem.store_memory(atomic_id, vec)
            
            # 2. Add to Hierarchy (Chunking)
            hier.add_event(atomic_id)
        else:
            print(f"  -> FAIL.")
            
    print(f"\n[TRAIN] Complete. Solved {success_count}/{len(scenarios)}.")
    
    # 4. Verify Memory Growth
    print(f"[METRICS] Total Memories: {len(mem.ids)}")
    mem._atomic_save_all()
    
if __name__ == "__main__":
    train_mind()
