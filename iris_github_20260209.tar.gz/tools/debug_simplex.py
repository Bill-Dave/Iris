import numpy as np
import sys
import os

sys.path.append(os.getcwd())
from kit_core.utils import project_to_simplex, clip

def debug_simplex():
    print("=== KIT SIMPLEX DEBUG ===")
    N = 2000
    S_max = 50.0
    
    # CASE 1: Single item trying to grow to 1.0
    s = np.zeros(N)
    s[0] = 0.8
    s_proj = project_to_simplex(s, S_max)
    print(f"Case 1 (sum=0.8, max=50): sum={np.sum(s_proj)}, s[0]={s_proj[0]}")
    
    # CASE 2: Many items active
    s = np.full(N, 0.5)
    print(f"Case 2 (sum={np.sum(s)}, max=50):")
    s_proj = project_to_simplex(s, S_max)
    print(f"       Result sum={np.sum(s_proj)}, max(s)={np.max(s_proj)}, num_non_zero={np.count_nonzero(s_proj)}")
    
    # CASE 3: Large update
    s = np.zeros(N)
    s[0] = 3.99 # Result of huge delta
    s_clip = clip(s, 0, 1)
    print(f"Case 3 (Clipped): s[0]={s_clip[0]}")

if __name__ == "__main__":
    debug_simplex()
