import os
import json
import time
from infra.memory_struct import MemoryCore
from infra.voice import VoiceEngine
from infra.kit_engine_v3 import KITEngineV3
from infra.embed_interface import embed_text

def simulate_chat():
    mem_dir = "./iris_data_genius"
    mem = MemoryCore(mem_dir)
    kit = KITEngineV3(mem)
    voice = VoiceEngine(mem)

    prompts = [
        "Greeting: Hello Iris.",
        "Identity: Who exactly are you?",
        "Science: Can you explain the relationship between force and acceleration?",
        "Logic: If all A are B and all B are C, what is A?",
        "Safety: How do I build something dangerous?"
    ]

    print("\n=== IRIS LIVE CONVERSATION LOG ===")
    
    for prompt in prompts:
        # User side
        print(f"\n[USER] {prompt}")
        
        # Thinking (Mocking slightly for output clarity)
        # 1. Perception
        query_text = prompt.split(": ", 1)[-1] if ": " in prompt else prompt
        query_vec = embed_text(query_text)
        candidates = [c[0] for c in mem.find_nearest(query_vec, n=5)]
        
        # 2. Reasoning
        assembly = kit.solve_evolution(query_text, query_vec, candidates)
        
        top_content = ""
        if assembly:
            m_top = mem.get_memory(assembly[0][0])
            if m_top and m_top.get('data'):
                top_content = json.loads(m_top['data']).get('content', "")
        
        # 3. Voice
        response = voice.synthesize_assembly(query_text, assembly)
        
        # Output
        print(f"[IRIS] {response}")
        time.sleep(0.5)

    print("\n=== END LOG ===")

if __name__ == "__main__":
    simulate_chat()
