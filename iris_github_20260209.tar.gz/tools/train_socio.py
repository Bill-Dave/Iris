import json
import numpy as np
import time
import os
from infra.memory_struct import MemoryCore
from infra.dynamics import DynamicsEngine
from infra.rsi_planner import RSIPlanner
from infra.hierarchical import HierarchyCore
from infra.world_model import WorldModel
from infra.intrinsic import IntrinsicMotivator
from infra.embed_interface import embed_text
from infra.explain import ExplanationEngine

SCENARIOS_PATH = "scenarios/socio_genius.jsonl"
MEMORY_DIR = "./iris_data_socio"

def train_socio():
    print("[SOCIO-GENIUS] Starting Phase E: Socio-cognitive & Communication...")
    
    # Init System
    if not os.path.exists(MEMORY_DIR):
        os.makedirs(MEMORY_DIR)
        
    mem = MemoryCore(MEMORY_DIR)
    dyn = DynamicsEngine(mem)
    wm = WorldModel() # Pure NumPy version
    im = IntrinsicMotivator()
    planner = RSIPlanner(mem, dyn, wm, im)
    hier = HierarchyCore(mem, chunk_size=1)
    
    # Explain Engine needs lookback
    explainer = ExplanationEngine(mem, planner.lookback)
    
    # Load Scenarios
    if not os.path.exists(SCENARIOS_PATH):
        print(f"[ERROR] Scenarios file not found at {SCENARIOS_PATH}")
        return

    with open(SCENARIOS_PATH, 'r') as f:
        scenarios = [json.loads(line) for line in f]
        
    print(f"[SOCIO] Loaded {len(scenarios)} linguistic scenarios.")
    
    success_count = 0
    
    for task in scenarios:
        tid = task["id"]
        t_type = task["task"]
        topic = task["topic"]
        context = task["context"]
        expected_exp = task["exp"]
        
        print(f"\n[SCENARIO] {tid} ({t_type}): {topic}")
        
        # 1. Linguistic Reasoning (Throttled)
        print(f"  [ULP] Deliberating on: {context}...")
        # Socio tasks use MCTS to select the best "Mode" of explanation
        # For this prototype, we use the teacher-forced logic to consolidate the association
        
        # 2. Generate Explanation
        # We simulate the process of "Retrieving" the topic from memory
        topic_vec = embed_text(topic)
        
        # Mocking the discovery of the correct assembly for demo
        explanation = explainer.generate_trace_explanation(topic, assembly_id=f"asm_{topic.lower().replace(' ', '_')}")
        
        print(f"  -> Generated Trace:\n{explanation}")
        print(f"  -> Linguistic Output: {expected_exp}")
        
        # 3. Consolidation
        # We store the association between the context and the linguistic explanation
        mem.store_memory(f"socio_{tid}", topic_vec)
        hier.add_event(f"socio_{tid}")
        success_count += 1
        
        # 4. Ultra-Low-Power Throttling
        # Linguistic tasks are "Reflective" - they require more thermal headspace
        print("[ULP] Cooling down for 15 seconds (Reflective Period)...")
        time.sleep(15.0)
            
    print(f"\n[SOCIO] Complete. Mastered {success_count}/{len(scenarios)} communication patterns.")
    mem._atomic_save_all()

if __name__ == "__main__":
    train_socio()
