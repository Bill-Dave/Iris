import os
import json
import numpy as np
import pickle
from infra.memory_struct import MemoryCore
from infra.production_retriever import TieredRetriever
from infra.kit_engine_v3 import KITEngineV3
from infra.embed_interface import embed_text

MEMORY_DIR = "./iris_data_genius"

def debug_trace():
    print("--- IRIS DEEP TRACE: STEM PROFICIENCY ---")
    mem = MemoryCore(MEMORY_DIR)
    retriever = TieredRetriever(mem)
    kit = KITEngineV3(mem)
    
    # Load Index
    idx_path = os.path.join(MEMORY_DIR, "inverted_index.pkl")
    with open(idx_path, 'rb') as f:
        retriever.inverted_index = pickle.load(f)
    retriever.doc_lengths = np.load(os.path.join(MEMORY_DIR, "doc_lengths.npy"))

    query = "Explain Newton's second law of motion."
    print(f"[QUERY] {query}")
    
    # 1. Perception
    candidates = retriever.query_tier_a(query, k=10)
    print(f"[PERCEPTION] Found {len(candidates)} candidates.")
    for cid, score in candidates[:3]:
        print(f"  - {cid}: {score:.4f}")

    # 2. Reasoning Data Load
    candidate_ids = [c[0] for c in candidates]
    ckas = []
    X = []
    valid_ids = []
    for cid in candidate_ids:
        m = mem.get_memory(cid)
        if m and m.get('data'):
            try:
                payload = json.loads(m['data'])
                ckas.append(payload)
                X.append(m['x'])
                valid_ids.append(cid)
            except Exception as e:
                print(f"  [ERROR] Payload load fail for {cid}: {e}")
        else:
            print(f"  [WARN] No data for {cid}")

    if not ckas:
        print("[CRITICAL] No CKAs loaded for reasoning.")
        return

    X = np.array(X)
    query_vec = embed_text(query)
    
    # 3. Potentials
    P = np.maximum(0, np.dot(X, query_vec))
    print(f"[REASONING] Potentials P: {P}")
    
    # 4. Relaxation
    assembly = kit.solve_evolution(query, query_vec, candidate_ids)
    print(f"[REASONING] Assembly size: {len(assembly)}")
    for aid, s in assembly[:5]:
        print(f"  - {aid}: s={s:.4f}")

if __name__ == "__main__":
    debug_trace()
