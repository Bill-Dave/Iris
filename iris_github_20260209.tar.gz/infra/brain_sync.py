"""
Brain Synchronization Core
==================================================
Unified orchestrator that connects ALL Iris cognitive modules.
Implements a brain-like architecture with neural bus, hemispheric
specialization, thalamic routing, and hippocampal memory bridging.

Architecture:
    ┌─────────────────────────────────────────────────────────────┐
    │                    BRAIN SYNC CORE                          │
    │  ┌─────────────┐    ┌──────────────┐    ┌─────────────┐    │
    │  │   LEFT      │    │   THALAMIC   │    │   RIGHT     │    │
    │  │ HEMISPHERE  │◄──►│    ROUTER    │◄──►│ HEMISPHERE  │    │
    │  │ STEM/Logic  │    │              │    │ Socio/Voice │    │
    │  └─────────────┘    └──────────────┘    └─────────────┘    │
    │         │                  │                  │             │
    │         └────────────┬─────┴─────┬───────────┘             │
    │                      │   NEURAL  │                          │
    │                      │    BUS    │                          │
    │                      └─────┬─────┘                          │
    │  ┌─────────────┐    ┌──────▼─────┐    ┌─────────────┐      │
    │  │ HIPPOCAMPAL │◄──►│  MEMORY    │◄──►│   CORPUS    │      │
    │  │   BRIDGE    │    │   CORE     │    │  CALLOSUM   │      │
    │  └─────────────┘    └────────────┘    └─────────────┘      │
    └─────────────────────────────────────────────────────────────┘
"""
import os
import sys
import time
import json
import threading
from typing import Dict, List, Any, Optional, Callable
from dataclasses import dataclass, field
from enum import Enum

# Add project root to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


class BrainRegion(Enum):
    """Brain regions for routing."""
    LEFT_HEMISPHERE = "left"      # STEM, Logic, Mathematics
    RIGHT_HEMISPHERE = "right"    # Language, Creativity, Social
    PREFRONTAL = "prefrontal"     # Planning, Goals, Strategy
    HIPPOCAMPUS = "hippocampus"   # Memory Formation, Retrieval
    CEREBELLUM = "cerebellum"     # Execution, Motor, Habits
    THALAMUS = "thalamus"         # Routing, Attention Gating


@dataclass
class NeuralMessage:
    """Message passed on the neural bus."""
    source: str
    target: str
    content: Any
    priority: float = 1.0
    timestamp: float = field(default_factory=time.time)
    metadata: Dict = field(default_factory=dict)


class NeuralBus:
    """Central message passing system between brain modules."""
    
    def __init__(self):
        self.subscribers: Dict[str, List[Callable]] = {}
        self.message_log: List[NeuralMessage] = []
        self.lock = threading.Lock()
    
    def subscribe(self, channel: str, callback: Callable):
        """Subscribe to messages on a channel."""
        with self.lock:
            if channel not in self.subscribers:
                self.subscribers[channel] = []
            self.subscribers[channel].append(callback)
    
    def publish(self, message: NeuralMessage):
        """Publish a message to the bus."""
        with self.lock:
            self.message_log.append(message)
            
            # Broadcast to target channel subscribers
            if message.target in self.subscribers:
                for callback in self.subscribers[message.target]:
                    try:
                        callback(message)
                    except Exception as e:
                        print(f"[NEURAL-BUS] Error in subscriber: {e}")
            
            # Broadcast to "all" channel
            if "all" in self.subscribers:
                for callback in self.subscribers["all"]:
                    try:
                        callback(message)
                    except Exception as e:
                        pass


class ThalamicRouter:
    """
    Routes queries to appropriate brain regions.
    Acts as the attentional gatekeeper.
    """
    
    def __init__(self):
        self.routing_rules = {
            # STEM/Logic keywords -> Left Hemisphere
            "math": BrainRegion.LEFT_HEMISPHERE,
            "calculate": BrainRegion.LEFT_HEMISPHERE,
            "derivative": BrainRegion.LEFT_HEMISPHERE,
            "integral": BrainRegion.LEFT_HEMISPHERE,
            "equation": BrainRegion.LEFT_HEMISPHERE,
            "logic": BrainRegion.LEFT_HEMISPHERE,
            "proof": BrainRegion.LEFT_HEMISPHERE,
            "algorithm": BrainRegion.LEFT_HEMISPHERE,
            
            # Language/Creative keywords -> Right Hemisphere
            "explain": BrainRegion.RIGHT_HEMISPHERE,
            "describe": BrainRegion.RIGHT_HEMISPHERE,
            "feel": BrainRegion.RIGHT_HEMISPHERE,
            "story": BrainRegion.RIGHT_HEMISPHERE,
            "creative": BrainRegion.RIGHT_HEMISPHERE,
            "social": BrainRegion.RIGHT_HEMISPHERE,
            
            # Planning keywords -> Prefrontal
            "plan": BrainRegion.PREFRONTAL,
            "goal": BrainRegion.PREFRONTAL,
            "strategy": BrainRegion.PREFRONTAL,
            "decide": BrainRegion.PREFRONTAL,
            
            # Memory keywords -> Hippocampus
            "remember": BrainRegion.HIPPOCAMPUS,
            "recall": BrainRegion.HIPPOCAMPUS,
            "learn": BrainRegion.HIPPOCAMPUS,
            "store": BrainRegion.HIPPOCAMPUS,
        }
    
    def route(self, query: str) -> BrainRegion:
        """Determine which brain region should handle the query."""
        query_lower = query.lower()
        
        # Check routing rules
        for keyword, region in self.routing_rules.items():
            if keyword in query_lower:
                return region
        
        # Default to right hemisphere (language understanding)
        return BrainRegion.RIGHT_HEMISPHERE


class HippocampalBridge:
    """
    Bridges short-term and long-term memory.
    Handles memory consolidation and retrieval.
    """
    
    def __init__(self, memory_core=None):
        self.mem = memory_core
        self.working_memory: List[Dict] = []
        self.consolidation_threshold = 0.6
    
    def store_working(self, item: Dict):
        """Store item in working memory."""
        item['timestamp'] = time.time()
        self.working_memory.append(item)
        
        # Limit working memory size
        if len(self.working_memory) > 50:
            self.working_memory = self.working_memory[-50:]
    
    def consolidate(self):
        """Move important items from working to long-term memory."""
        if self.mem is None:
            return 0
        
        consolidated = 0
        for item in self.working_memory:
            if item.get('importance', 0) >= self.consolidation_threshold:
                try:
                    from infra.embed_interface import embed_text
                    vec = embed_text(item.get('content', ''))
                    self.mem.store_cka(
                        cka_id=f"consolidated_{int(time.time())}_{consolidated}",
                        content=item.get('content', ''),
                        x_vec=vec,
                        domain=["consolidated"],
                        activation_profile={"triggers": item.get('triggers', [])}
                    )
                    consolidated += 1
                except Exception as e:
                    pass
        
        return consolidated
    
    def retrieve(self, query_vec, n: int = 10):
        """Retrieve from long-term memory."""
        if self.mem is None:
            return []
        return self.mem.find_nearest(query_vec, n=n)


class BrainSyncCore:
    """
    Master brain synchronization orchestrator.
    Connects all cognitive modules into a unified system.
    """
    
    def __init__(self, memory_dir: str = None):
        print("[BRAIN-SYNC] Initializing Unified Brain Architecture...")
        
        # Core infrastructure
        self.neural_bus = NeuralBus()
        self.thalamus = ThalamicRouter()
        self.hippocampus = None
        
        # Module registry
        self.modules: Dict[str, Any] = {}
        self.module_status: Dict[str, bool] = {}
        
        # Memory directory
        self.memory_dir = memory_dir or os.path.join(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
            "iris_data_genius"
        )
        
        # Initialize all modules
        self._init_modules()
    
    def _init_modules(self):
        """Initialize all cognitive modules."""
        print("[BRAIN-SYNC] Loading cognitive modules...")
        
        # 1. Memory Core (Foundation)
        self._load_module("memory", self._init_memory)
        
        # 2. Hippocampal Bridge
        if self.modules.get("memory"):
            self.hippocampus = HippocampalBridge(self.modules["memory"])
        
        # 3. KIT Engine (Left Hemisphere - Reasoning)
        self._load_module("kit", self._init_kit)
        
        # 4. Voice Engine (Right Hemisphere - Language)
        self._load_module("voice", self._init_voice)
        
        # 5. GORE Planner (Prefrontal - Planning)
        self._load_module("gore", self._init_gore)
        
        # 6. Sparse Attention (Efficiency)
        self._load_module("sparse", self._init_sparse)
        
        # 7. World Model (Prediction)
        self._load_module("world", self._init_world)
        
        # 8. MCTS Reasoning (Search)
        self._load_module("mcts", self._init_mcts)
        
        # 9. Mutation Engine (RSI)
        self._load_module("mutation", self._init_mutation)
        
        # 10. Hardest Tests (Self-Evaluation)
        self._load_module("crucible", self._init_crucible)
        
        # 11. Hebbian Learning
        self._load_module("hebbian", self._init_hebbian)
        
        # 12. World-Class Reasoning (NEW)
        self._load_module("reasoning", self._init_reasoning)
        
        # 13. Knowledge Researcher (2GB Knowledge Base)
        self._load_module("researcher", self._init_researcher)
        
        # Print status
        self._print_status()
    
    def _load_module(self, name: str, init_func: Callable):
        """Load a module with error handling."""
        try:
            module = init_func()
            self.modules[name] = module
            self.module_status[name] = True
            print(f"       ✓ {name.upper()}")
        except Exception as e:
            self.modules[name] = None
            self.module_status[name] = False
            print(f"       ✗ {name.upper()} ({str(e)[:30]})")
    
    def _init_memory(self):
        from infra.memory_struct import MemoryCore
        return MemoryCore(self.memory_dir)
    
    def _init_kit(self):
        from infra.kit_engine_v3 import KITEngineV3
        return KITEngineV3(self.modules.get("memory"))
    
    def _init_voice(self):
        from infra.voice import VoiceEngine
        return VoiceEngine(self.modules.get("memory"))
    
    def _init_gore(self):
        from infra.gore_planner import GOREPlanner
        return GOREPlanner(self.modules.get("kit"))
    
    def _init_sparse(self):
        from infra.sparse_kit import SparseKITEngine
        return SparseKITEngine(default_k=15)
    
    def _init_world(self):
        from infra.world_model import WorldModel
        return WorldModel()
    
    def _init_mcts(self):
        from infra.mcts import MCTSNode
        return MCTSNode
    
    def _init_mutation(self):
        from infra.mutation_engine import MutationEngine
        return MutationEngine(self.modules.get("kit"), self.modules.get("memory"))
    
    def _init_crucible(self):
        from infra.hardest_tests import CognitiveCrucible
        return CognitiveCrucible(self.modules.get("memory"), self.modules.get("kit"))
    
    def _init_hebbian(self):
        from infra.hebbian import update_hebbian_batch
        return update_hebbian_batch
    
    def _init_reasoning(self):
        from infra.world_class_reasoning import WorldClassReasoner
        return WorldClassReasoner(self.memory_dir)
    
    def _init_researcher(self):
        from infra.world_class_reasoning import KnowledgeResearcher
        return KnowledgeResearcher()
    
    def _print_status(self):
        """Print module loading status."""
        loaded = sum(1 for v in self.module_status.values() if v)
        total = len(self.module_status)
        print(f"\n[BRAIN-SYNC] Modules Loaded: {loaded}/{total}")
    
    def process_query(self, query: str) -> str:
        """
        Process a query through the unified brain.
        Routes to appropriate hemisphere and synthesizes response.
        """
        # 1. Route query via thalamus
        region = self.thalamus.route(query)
        
        # 2. Store in working memory
        if self.hippocampus:
            self.hippocampus.store_working({
                "content": query,
                "type": "query",
                "importance": 0.5
            })
        
        # 3. Get candidates from memory
        candidates = []
        if self.modules.get("memory"):
            try:
                from infra.embed_interface import embed_text
                query_vec = embed_text(query)
                nearest = self.modules["memory"].find_nearest(query_vec, n=15)
                candidates = [c[0] for c in nearest]
            except Exception as e:
                pass
        
        # 4. Route to appropriate processing
        if region == BrainRegion.LEFT_HEMISPHERE:
            response = self._process_stem(query, candidates)
        elif region == BrainRegion.PREFRONTAL:
            response = self._process_planning(query)
        else:
            response = self._process_language(query, candidates)
        
        # 5. Store response in working memory
        if self.hippocampus:
            self.hippocampus.store_working({
                "content": response,
                "type": "response",
                "importance": 0.7
            })
        
        return response
    
    def _process_stem(self, query: str, candidates: List[str]) -> str:
        """Process STEM/Logic queries via left hemisphere."""
        if not self.modules.get("kit") or not self.modules.get("voice"):
            return self._fallback_response(query)
        
        try:
            from infra.embed_interface import embed_text
            query_vec = embed_text(query)
            assembly = self.modules["kit"].solve_evolution(query, query_vec, candidates)
            return self.modules["voice"].synthesize_assembly(query, assembly)
        except Exception as e:
            return self._fallback_response(query)
    
    def _process_language(self, query: str, candidates: List[str]) -> str:
        """Process language queries via right hemisphere."""
        if not self.modules.get("kit") or not self.modules.get("voice"):
            return self._fallback_response(query)
        
        try:
            from infra.embed_interface import embed_text
            query_vec = embed_text(query)
            assembly = self.modules["kit"].solve_evolution(query, query_vec, candidates)
            return self.modules["voice"].synthesize_assembly(query, assembly)
        except Exception as e:
            return self._fallback_response(query)
    
    def _process_planning(self, query: str) -> str:
        """Process planning queries via prefrontal cortex (GORE)."""
        if not self.modules.get("gore"):
            return self._fallback_response(query)
        
        try:
            gore = self.modules["gore"]
            gore.add_goal("user_goal", query, priority=1.0)
            plan = gore.plan_hierarchy("user_goal")
            return gore.explain_plan(plan)
        except Exception as e:
            return self._fallback_response(query)
    
    def _fallback_response(self, query: str) -> str:
        """Fallback when modules aren't available."""
        return f"I have received your query. The full cognitive stack is initializing."
    
    def get_brain_status(self) -> Dict:
        """Get comprehensive brain status."""
        return {
            "modules": self.module_status,
            "modules_loaded": sum(1 for v in self.module_status.values() if v),
            "total_modules": len(self.module_status),
            "memory_dir": self.memory_dir,
            "working_memory_size": len(self.hippocampus.working_memory) if self.hippocampus else 0
        }
    
    def run_self_eval(self, rounds: int = 5) -> Dict:
        """Run self-evaluation via the cognitive crucible."""
        if not self.modules.get("crucible"):
            return {"error": "Crucible not loaded"}
        
        results = self.modules["crucible"].run_crucible(num_rounds=rounds)
        stats = self.modules["crucible"].get_stats()
        return stats


# Demonstration
if __name__ == "__main__":
    print("=" * 60)
    print("IRIS UNIFIED BRAIN ARCHITECTURE")
    print("=" * 60)
    
    brain = BrainSyncCore()
    
    print("\n" + "=" * 60)
    print("BRAIN STATUS")
    print("=" * 60)
    status = brain.get_brain_status()
    print(f"Modules Loaded: {status['modules_loaded']}/{status['total_modules']}")
    for mod, loaded in status['modules'].items():
        print(f"  {mod.upper()}: {'✓' if loaded else '✗'}")
    
    print("\n" + "=" * 60)
    print("QUERY PROCESSING TEST")
    print("=" * 60)
    
    test_queries = [
        "What is the derivative of x squared?",
        "Explain how memory works in the brain",
        "Plan a strategy to acquire more knowledge"
    ]
    
    for q in test_queries:
        print(f"\nQ: {q[:50]}...")
        region = brain.thalamus.route(q)
        print(f"   [ROUTED TO: {region.value}]")
        response = brain.process_query(q)
        print(f"   A: {response[:100]}...")
    
    print("\n" + "=" * 60)
    print("BRAIN SYNCHRONIZATION COMPLETE")
    print("=" * 60)
