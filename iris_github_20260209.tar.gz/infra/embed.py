import os
import numpy as np
import hashlib

# HFSS: High-Fidelity Semantic Simulation
# Provides 384-dim deterministic vectors with semantic grouping.
DIM = 384

# Pre-defined Domain Axes for semantic grouping
DOMAIN_SEEDS = {
    "physics": 101,
    "ethics": 202,
    "business": 303,
    "fruit": 404,
    "tech": 505,
    "nutrition": 606
}

def get_domain_axis(domain_name: str) -> np.ndarray:
    seed = DOMAIN_SEEDS.get(domain_name.lower(), 999)
    np.random.seed(seed)
    v = np.random.normal(0, 1, DIM)
    return v / np.linalg.norm(v)

def init_embedder(seed=0):
    print(f"[KIT] Initializing HFSS Embedder (seed={seed}, Dimension={DIM})...")
    os.environ['PYTHONHASHSEED'] = str(seed)
    # HFSS is library-free

def embed_text(text: str) -> np.ndarray:
    """
    Returns float32, L2-normalized, dim=384.
    Semantic grouping is achieved by detecting [Domain] tags or keywords.
    """
    text_clean = text.lower().strip()
    
    # 1. Determine Domain bias
    domain = "generic"
    if "[physics]" in text_clean or "physics" in text_clean: domain = "physics"
    elif "[ethics]" in text_clean or "ethics" in text_clean: domain = "ethics"
    elif "[business]" in text_clean or "business" in text_clean: domain = "business"
    elif "apple" in text_clean or "pear" in text_clean or "fruit" in text_clean: domain = "fruit"
    elif "microsoft" in text_clean or "tech" in text_clean: domain = "tech"
    elif "nutrition" in text_clean or "healthy" in text_clean: domain = "nutrition"
    
    axis = get_domain_axis(domain)
    
    # 2. Text-specific variation (Deterministic Hash)
    hasher = hashlib.md5(text_clean.encode())
    seed = int(hasher.hexdigest(), 16) % (2**32)
    np.random.seed(seed)
    variation = np.random.normal(0, 1, DIM)
    variation /= np.linalg.norm(variation)
    
    # 3. Semantic Blend
    # 0.7 Signal (Domain) + 0.3 Noise (Unique identity)
    # This ensures intra-domain similarity ~0.7
    vec = 0.7 * axis + 0.3 * variation
    vec = vec.astype(np.float32)
    
    # Final L2 Normalization
    return vec / (np.linalg.norm(vec) + 1e-9)

def embed_and_store(memory_core, item_id: str, text: str, tier=2):
    """
    Encodes text and adds it to the provided MemoryCore instance.
    """
    vec = embed_text(text)
    memory_core.add_item(vec, item_id)
