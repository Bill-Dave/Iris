import numpy as np

ETA_H = 1e-4
BETA = 1e-3
TAU_S = 0.5

def hebbian_update(memory_core, assembly_ids):
    """
    Delta U_i propto eta_H * sum_{j in A} s_i s_j (x_j - x_bar)
    lambda_i += beta * I[s_i > tau]
    """
    if not assembly_ids: return
    
    indices = [memory_core.id_to_idx[uid] for uid in assembly_ids]
    X = memory_core.x_store[indices] # (N, D)
    S = memory_core.s_store[indices] # (N,)
    U = memory_core.U_store[indices] # (N, D, R)
    Lam = memory_core.lambda_store[indices] # (N,)
    
    # x_bar (mean of assembly)
    # Weighted by s? "x_j - x_bar".
    # Let's use simple mean for x_bar.
    x_bar = np.mean(X, axis=0)
    
    N = len(indices)
    
    # For each i, compute Delta U_i
    # We want to add rank-1 components to U_i approx?
    # U is (D, R). We are learning a subspace.
    # The update (x_j - x_bar) indicates the direction of variation in the assembly.
    # We want U_i to capture this variation.
    
    # Logic: U_new = U_old + eta * (Difference * Projection...?)
    # Formula given: Delta U? "Delta U_i propto ..."
    # This implies we add to U.
    # But U is a basis. Adding vectors destroys orthogonality/rank unless done carefully.
    # Or maybe U stores the covariance directly? 
    # "S_i approx U_i U_i^T".
    # If we update U directly with gradients, we might drift.
    # Let's project the update vector v = (x_j - x_bar) onto orthogonal component of U?
    # For "Micro-updates", simple addition followed by re-orthonormalization is standard.
    
    # Vectorized update?
    # Delta_i = sum_j s_i s_j (x_j - x_bar)
    # This result is a Vector in R^D.
    # U_i is D x R.
    # To add a vector to a subspace, we usually add it to the first column or do SVD update.
    # Or we treat U as "weights" predicting the assembly?
    
    # Let's interpret "Delta U_i" as adding to the U matrix weights directly.
    # But U has shape (D, R). The delta is shape (D,).
    # We need to map (D,) -> (D, R).
    # Maybe broadcast to all columns? Or just the first principal component?
    # Let's assume we update the columns with decaying factor, or just add to the whole matrix if it was DxD (it's not).
    # Given R=8, let's update U[:, 0] (primary component) or distribute.
    # Let's update U[:, 0] specifically to align with dominant variation.
    
    # 1. Compute Direction D_i = sum_j s_j (x_j - x_bar)
    # Weighted average of peers relative to mean.
    # D_i is independent of i? No, sum over j in A.
    # Actually sum_{j in A} is constant for all i inside A!
    # Let D_A = sum_{j in A} s_j (x_j - x_bar).
    # Then Delta U_i = eta * s_i * D_A.
    
    Diff = X - x_bar # (N, D)
    D_A = np.sum(S[:, np.newaxis] * Diff, axis=0) # (D,)
    
    # Update
    # Update column 0 of U?
    # U shape: (N, D, R)
    # We add to U[:, :, 0]
    
    # Delta: (N, D)
    Delta = ETA_H * S[:, np.newaxis] * D_A[np.newaxis, :]
    
    memory_core.U_store[indices, :, 0] += Delta
    
    # Renormalize / Re-QR U_i?
    # For stability, occasionally re-orthonormalize.
    # Let's do rough normalization of col 0.
    norms = np.linalg.norm(memory_core.U_store[indices, :, 0], axis=1, keepdims=True)
    memory_core.U_store[indices, :, 0] /= (norms + 1e-9)
    
    # Lambda Update
    # lambda_i += beta * I[s_i > tau]
    mask = (S > TAU_S).astype(np.float32)
    memory_core.lambda_store[indices] += BETA * mask

    # Save logic (user responsibility to call save_all or atomic update?)
    # We modify in-place. infra modules usually share memory object.
    pass
