import sys
import io
import contextlib
import traceback
import signal

class CodeEnv:
    def __init__(self, timeout=2):
        self.timeout = timeout
        self.namespace = {} # Persistent state

    def execute(self, code_str):
        """
        Executes python code string.
        Returns: (stdout, stderr, success_bool)
        """
        out_io = io.StringIO()
        err_io = io.StringIO()
        
        success = False
        
        try:
            with contextlib.redirect_stdout(out_io):
                with contextlib.redirect_stderr(err_io):
                    # Timeout handling?
                    # Signal based timeout is simple for main thread
                    # For stability in this environment we skip tough timeout logic
                    # and assume trusted input/short snippets.
                    exec(code_str, self.namespace)
            success = True
        except Exception:
            # Capture traceback
            traceback.print_exc(file=err_io)
            success = False
            
        return out_io.getvalue(), err_io.getvalue(), success

if __name__ == "__main__":
    env = CodeEnv()
    o, e, s = env.execute("print('Hello World'); x=5")
    print(f"Out: {o.strip()}, Err: {e}, Success: {s}")
    o, e, s = env.execute("print(x*2)")
    print(f"Out: {o.strip()}, Err: {e}, Success: {s}")
