import numpy as np
from .intrinsic import IntrinsicMotivator

H_HORIZON = 8
NUM_SAMPLES = 64 # How many action traces to imagine?
ACTION_DIM = 16 # Must match WorldModel

class Planner:
    def __init__(self, world_model, intrinsic_motivator, dynamics_engine):
        self.wm = world_model
        self.im = intrinsic_motivator
        self.dyn = dynamics_engine
        
    def _get_context(self, x):
        # 1. Retrieve Assembly
        # We use the dynamics engine to find the "active assembly" for this input.
        # This is the "Working Memory".
        # We assume X represents the current perception.
        # Dynamics usually runs on internal state 's', but here we rely on 'x' triggering recall.
        # We can seed with the input vector.
        
        # Use greedy assembly calculation (Fast approximation of dynamics settling)
        # 1. Get Seeds from Vector
        seeds = self.dyn.form_candidate_pool(x, k=10)
        if not seeds:
             return np.zeros(384, dtype=np.float32), []
             
        # 2. Form Assembly
        assembly_ids = self.dyn.greedy_assembly_seed(seeds)
        
        if not assembly_ids:
            return np.zeros(384, dtype=np.float32), []
            
        # 2. Aggregate Vectors
        indices = [self.dyn.mem.id_to_idx[uid] for uid in assembly_ids if uid in self.dyn.mem.id_to_idx]
        if not indices:
             return np.zeros(384, dtype=np.float32), []
             
        vectors = self.dyn.mem.x_store[indices]
        
        # Mean Context
        context = np.mean(vectors, axis=0)
        return context, assembly_ids
        
    def plan(self, x_start):
        """
        Returns best action a_0.
        Simple Random Shooting MPC.
        """
        # 0. Get Context (Working Memory)
        context, assembly_ids = self._get_context(x_start)
        
        # 1. Generate candidate action sequences (B, H, A)
        # Random actions for now.
        action_seqs = np.random.uniform(-1, 1, size=(NUM_SAMPLES, H_HORIZON, ACTION_DIM)).astype(np.float32)
        
        # 2. Rollout
        scores = np.zeros(NUM_SAMPLES)
        # x_curr: (B, D)
        x_curr = np.tile(x_start.reshape(1, -1), (NUM_SAMPLES, 1))
        # Context is constant across batch and time (Short-term working memory)
        context_batch = np.tile(context.reshape(1, -1), (NUM_SAMPLES, 1))
        
        for t in range(H_HORIZON):
            a_t = action_seqs[:, t, :] # (B, A)
            
            # Predict Next
            # Pass context!
            x_next = self.wm.forward_model(x_curr, a_t, context_batch)
            
            # Calculate Intrinsic Reward
            for i in range(NUM_SAMPLES):
                h = self.im.hash_state(x_next[i])
                r = self.im.compute_reward(0.0, h, action_entropy=0.1)
                scores[i] += r
                
            x_curr = x_next
                
        # 3. Select Best
        best_idx = np.argmax(scores)
        
        return action_seqs[best_idx, 0, :], assembly_ids, context
