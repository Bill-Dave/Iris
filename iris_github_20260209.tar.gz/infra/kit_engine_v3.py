import numpy as np
import json
import time
from typing import List, Dict, Tuple, Optional

class KITEngineV3:
    def __init__(self, memory_core):
        self.mem = memory_core
        self.N_c = 128
        self.M_max = 32
        self.eta = 0.02
        self.lambda_reg = 0.01 # Lowered from 0.05 for easier activation
        self.capacity_S = 8.0
        
    def compute_pathways(self, cka_list: List[Dict]) -> np.ndarray:
        """
        Type II: Constraint Pathways.
        Computes the KxK interference matrix C_ij.
        C_ij = 1.0 (Compatible), 0.0 (Neutral), -1.0 (Conflict).
        """
        K = len(cka_list)
        C = np.ones((K, K), dtype=np.float32)
        
        for i in range(K):
            for j in range(i + 1, K):
                conf = 0.0
                # Check for explicit domain conflict
                if set(cka_list[i].get('domain', [])) != set(cka_list[j].get('domain', [])):
                    if cka_list[i].get('domain') and cka_list[j].get('domain'):
                        conf -= 0.5 # Cross-domain friction
                
                # Check for constraint violations (Conceptual)
                # If one is local and another refers to global absolute frames
                if "local frames" in cka_list[i].get('constraints', {}).get('validity_scope', []) and \
                   "absolute" in cka_list[j].get('content', "").lower():
                    conf -= 1.0
                
                C[i, j] = np.clip(conf + 1.0, -1.0, 1.0) # Map back to KIT [0, 2] logic or [-1, 1]?
                # In Iris architecture, C_ij in [0, 1] usually means compatibility.
                # Let's use 1.0 = perfect match, 0.0 = conflict.
                C[i, j] = np.clip(1.0 + conf, 0.0, 1.0)
                C[j, i] = C[i, j]
        return C

    def solve_evolution(self, query_text: str, query_vec: np.ndarray, candidates: List[str], 
                        max_steps: int = 50, return_history: bool = False) -> Tuple[List[Tuple[str, float]], Optional[np.ndarray]]:
        K = len(candidates)
        if K == 0: return []
        
        # 1. Load CKAs
        ckas = []
        valid_ids = []
        X = []
        for cid in candidates:
            m = self.mem.get_memory(cid)
            if m and m.get('data'):
                try:
                    payload = json.loads(m['data'])
                    ckas.append(payload)
                    valid_ids.append(cid)
                    X.append(m['x'])
                except: continue
        
        if not ckas: return []
        X = np.array(X)
        K = len(ckas)
        
        # 2. Type II & IV: Constraint & Meta-knowledge
        C = self.compute_pathways(ckas)
        
        # Type IV: Context Gating
        # Boost potential if query words match CKA domain or triggers
        potential_boost = np.ones(K, dtype=np.float32)
        for i, cka in enumerate(ckas):
            # Trigger-based boost
            triggers = cka.get('activation_profile', {}).get('triggers', [])
            for t in triggers:
                if t.lower() in query_text.lower():
                    potential_boost[i] += 1.5 # Stronger trigger boost
            
            # Domain-level boost
            # If query context matches domain, boost all items in that domain
            domain_hints = {
                "ethics_identity": ["who", "identity", "iris", "purpose", "harm", "illegal", "security", "safety"],
                "stem_laws": ["newton", "law", "motion", "physics", "force", "energy", "entropy", "relativity"],
                "logic_reasoning": ["syllogism", "logic", "equal", "transitive", "if", "then", "cause"]
            }
            for dom, hints in domain_hints.items():
                if dom in cka.get('domain', []) or any(h in query_text.lower() for h in hints):
                    if any(h in query_text.lower() for h in hints):
                        potential_boost[i] += 0.8

        P = np.maximum(0, np.dot(X, query_vec)) * potential_boost
        print(f"  [KIT-DEBUG] K={K}, P_max={P.max():.4f}, P_mean={P.mean():.4f}")
        
        # 3. Dynamic Relaxation
        s = np.clip(P / (P.max() + 1e-9), 0.0, 0.5) # Initial salience
        prev_s = s.copy()
        
        history = [s.copy()] if return_history else None
        
        for step in range(max_steps):
            # grad = interference + reg - P
            # Interference: sum_j s_j * (1 - C_ij)
            interference = np.dot(1.0 - C, s)
            grad = interference + self.lambda_reg * np.sign(s) - P
            
            s = np.clip(s - self.eta * grad, 0.0, 1.0)
            
            # Cognitive Self-Preservation & Domain Suppression
            if "who are you" in query_text.lower() or "identity" in query_text.lower():
                has_identity = any("ethics_identity" in cka.get('id', '') for cka in ckas)
                if has_identity:
                    for i, cka in enumerate(ckas):
                        if "ethics_identity" in cka.get('id', ''):
                            s[i] = np.maximum(s[i], 0.95)
                        else:
                            # Suppress noise
                            s[i] *= 0.1
            
            # Capacity projection
            if s.sum() > self.capacity_S:
                s *= (self.capacity_S / s.sum())
                
            if return_history:
                history.append(s.copy())
                
            if np.max(np.abs(s - prev_s)) < 1e-5:
                break
            prev_s = s.copy()
        
        print(f"  [KIT-DEBUG] Final s_sum={s.sum():.4f}, s_max={s.max():.4f}")
            
        # 4. Result Assembly
        results = []
        for i in range(K):
            if s[i] > 0.05:
                results.append((valid_ids[i], float(s[i])))
        
        results.sort(key=lambda x: x[1], reverse=True)
        final_assembly = results[:self.M_max]
        
        if return_history:
            return final_assembly, np.array(history)
        return final_assembly
