import numpy as np
import time
from typing import List, Dict, Tuple, Optional

class KITEngineV2:
    def __init__(self, memory_core):
        self.mem = memory_core
        self.N_c = 128        # CWS size
        self.M_max = 32       # assembly size
        self.eta = 0.02
        self.lambda_reg = 0.01
        self.capacity_S = 8.0
        self.gamma = 1.0

    def compute_compatibility_matrix(self, vecs: np.ndarray) -> np.ndarray:
        """
        vecs: (K, D) matrix of L2-normalized vectors.
        Returns KxK compatibility matrix C_ij in [0, 1].
        """
        # Linear kernel: s_ij = dot(v_i, v_j)
        # Shift to [0, 1]: c_ij = (s_ij + 1) / 2
        sm = np.dot(vecs, vecs.T)
        return (sm + 1.0) / 2.0

    def solve_assembly(self, query_vec: np.ndarray, candidates: List[str], max_steps: int = 30) -> List[Tuple[str, float]]:
        """
        Discrete gradient descent with capacity projection.
        """
        K = len(candidates)
        if K == 0: return []
        
        # 1. Load data
        vecs = []
        valid_ids = []
        for cid in candidates:
            m = self.mem.get_memory(cid)
            if m:
                vecs.append(m['x'])
                valid_ids.append(cid)
        
        if not vecs: return []
        
        X = np.array(vecs) # (K, D)
        K = len(valid_ids)
        
        # 2. Compatibility & External Potential
        C = self.compute_compatibility_matrix(X)
        P = self.gamma * np.maximum(0, np.dot(X, query_vec))
        
        # 3. Initialize salience s
        s = np.zeros(K, dtype=np.float32)
        # Seed with potentials
        s[P.argsort()[-5:]] = 0.5 
        
        prev_s = s.copy()
        
        for step in range(max_steps):
            # grad = sum_j s_j * (1 - c_ij) + reg - P
            # Interference term
            interference = np.dot(1.0 - C, s)
            
            # Total gradient
            grad = interference + self.lambda_reg * np.sign(s) - P
            
            # SGD step
            s = np.clip(s - self.eta * grad, 0.0, 1.0)
            
            # Capacity projection
            total = s.sum()
            if total > self.capacity_S:
                s = s * (self.capacity_S / total)
                
            # Convergence check
            if np.max(np.abs(s - prev_s)) < 1e-4:
                break
            prev_s = s.copy()
            
        # 4. Form assembly
        results = []
        for i in range(K):
            if s[i] > 0.05:
                results.append((valid_ids[i], float(s[i])))
        
        results.sort(key=lambda x: x[1], reverse=True)
        return results[:self.M_max]
