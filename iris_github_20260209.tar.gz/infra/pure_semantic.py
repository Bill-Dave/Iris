import numpy as np
import re
import os
from collections import Counter

class PureSemanticEngine:
    def __init__(self, vocab=None, idf=None):
        self.vocab = vocab or {}
        self.idf = idf or {}
        self.dim = 10000 # Large vocab to ensure niche keywords survival

    def _tokenize(self, text):
        return re.findall(r'\w+', text.lower())

    def fit(self, corpus, priority_words=None):
        """
        Learns the vocab and IDF from a list of text strings.
        """
        all_tokens = []
        doc_counts = Counter()
        num_docs = len(corpus)
        
        for doc in corpus:
            tokens = set(self._tokenize(doc))
            for t in tokens:
                doc_counts[t] += 1
        
        # Select top N words for vocab
        most_common = doc_counts.most_common(self.dim)
        self.vocab = {word: i for i, (word, count) in enumerate(most_common)}
        
        # Manual Injection of Priority Words
        if priority_words:
            for word in priority_words:
                if word.lower() not in self.vocab:
                    # Replace the least common word or just append if there's room
                    new_idx = len(self.vocab)
                    self.vocab[word.lower()] = new_idx
                    # Also ensure it has an IDF entry (log of total docs)
                    # We'll calculate IDF after.
        
        # Calculate IDF (By Index for speed)
        self.idf = {}
        for word, count in doc_counts.items():
            if word in self.vocab:
                idx = self.vocab[word]
                self.idf[idx] = float(np.log(num_docs / (1 + count)))
        
        print(f"[PURE-SEMANTIC] Fitted vocab of size {len(self.vocab)}")

    def embed(self, text):
        """
        Returns a normalized TF-IDF vector.
        """
        vec = np.zeros(self.dim, dtype=np.float32)
        tokens = self._tokenize(text)
        counts = Counter(tokens)
        
        for word, count in counts.items():
            if word in self.vocab:
                idx = self.vocab[word]
                # TF-IDF
                tf = count / len(tokens) if tokens else 0
                # Handle string keys from JSON
                idf_val = self.idf.get(str(idx), self.idf.get(idx, 0.0))
                vec[idx] = tf * idf_val
        
        # L2 Normalize
        norm = np.linalg.norm(vec)
        if norm > 1e-9:
            vec /= norm
        return vec

    def save(self, path):
        data = {"vocab": self.vocab, "idf": self.idf}
        import json
        with open(path, 'w') as f:
            json.dump(data, f)

    def load(self, path):
        import json
        if os.path.exists(path):
            with open(path, 'r') as f:
                data = json.load(f)
                self.vocab = data["vocab"]
                self.idf = data["idf"]
