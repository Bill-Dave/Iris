"""
Knowledge Stream - Unlimited Knowledge Sourcing
==================================================
Autonomous knowledge ingestion from multiple sources.
Creates an "unlimited" knowledge environment for Iris.

Channels:
    - Wikipedia API (Real-time article fetching)
    - WebContent Ingestor (Fetch & embed any URL)
    - Local Document Loader (PDF/TXT/JSONL)
    - Dictionary Integration (Webster's loaded)
    - Continuous Learning (Background pipeline)
"""
import os
import sys
import json
import time
import threading
import hashlib
from typing import List, Dict, Any, Optional
from dataclasses import dataclass
from urllib.request import urlopen, Request
from urllib.error import URLError
import re

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


@dataclass
class KnowledgeItem:
    """Represents a piece of knowledge to be ingested."""
    id: str
    content: str
    source: str
    domain: List[str]
    timestamp: float
    metadata: Dict = None


class WikipediaChannel:
    """Fetches knowledge from Wikipedia API."""
    
    BASE_URL = "https://en.wikipedia.org/api/rest_v1/page/summary/"
    
    def fetch(self, topic: str) -> Optional[KnowledgeItem]:
        """Fetch a Wikipedia article summary."""
        try:
            url = self.BASE_URL + topic.replace(" ", "_")
            req = Request(url, headers={'User-Agent': 'IrisAGI/1.0'})
            
            with urlopen(req, timeout=10) as response:
                data = json.loads(response.read().decode())
                
                if 'extract' in data:
                    return KnowledgeItem(
                        id=f"wiki_{hashlib.md5(topic.encode()).hexdigest()[:12]}",
                        content=data['extract'],
                        source=f"wikipedia:{topic}",
                        domain=["encyclopedia", "general"],
                        timestamp=time.time(),
                        metadata={"title": data.get("title", topic)}
                    )
        except Exception as e:
            print(f"[WIKI] Failed to fetch '{topic}': {e}")
        
        return None


class WebContentChannel:
    """Fetches and processes web content."""
    
    def fetch(self, url: str) -> Optional[KnowledgeItem]:
        """Fetch content from a URL."""
        try:
            req = Request(url, headers={'User-Agent': 'IrisAGI/1.0'})
            
            with urlopen(req, timeout=15) as response:
                content = response.read().decode('utf-8', errors='ignore')
                
                # Basic HTML stripping
                content = re.sub(r'<script[^>]*>.*?</script>', '', content, flags=re.DOTALL)
                content = re.sub(r'<style[^>]*>.*?</style>', '', content, flags=re.DOTALL)
                content = re.sub(r'<[^>]+>', ' ', content)
                content = re.sub(r'\s+', ' ', content).strip()
                
                # Limit content size
                content = content[:10000]
                
                return KnowledgeItem(
                    id=f"web_{hashlib.md5(url.encode()).hexdigest()[:12]}",
                    content=content,
                    source=f"url:{url}",
                    domain=["web"],
                    timestamp=time.time(),
                    metadata={"url": url}
                )
        except Exception as e:
            print(f"[WEB] Failed to fetch '{url}': {e}")
        
        return None


class LocalDocumentChannel:
    """Loads knowledge from local documents."""
    
    def __init__(self, base_dir: str):
        self.base_dir = base_dir
    
    def load_txt(self, filepath: str) -> List[KnowledgeItem]:
        """Load a text file as knowledge items."""
        items = []
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # Split into chunks (paragraphs)
            chunks = [c.strip() for c in content.split('\n\n') if c.strip()]
            
            for i, chunk in enumerate(chunks[:100]):  # Limit to 100 chunks
                items.append(KnowledgeItem(
                    id=f"doc_{hashlib.md5((filepath + str(i)).encode()).hexdigest()[:12]}",
                    content=chunk,
                    source=f"file:{os.path.basename(filepath)}",
                    domain=["document"],
                    timestamp=time.time(),
                    metadata={"filepath": filepath, "chunk": i}
                ))
        except Exception as e:
            print(f"[DOC] Failed to load '{filepath}': {e}")
        
        return items
    
    def load_jsonl(self, filepath: str) -> List[KnowledgeItem]:
        """Load a JSONL file as knowledge items."""
        items = []
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                for i, line in enumerate(f):
                    if i >= 1000:  # Limit
                        break
                    try:
                        data = json.loads(line)
                        content = data.get('q', '') + ' ' + data.get('a', '')
                        if not content.strip():
                            content = json.dumps(data)
                        
                        items.append(KnowledgeItem(
                            id=f"jsonl_{hashlib.md5((filepath + str(i)).encode()).hexdigest()[:12]}",
                            content=content,
                            source=f"jsonl:{os.path.basename(filepath)}",
                            domain=data.get('domain', ['training']),
                            timestamp=time.time(),
                            metadata=data
                        ))
                    except:
                        pass
        except Exception as e:
            print(f"[JSONL] Failed to load '{filepath}': {e}")
        
        return items


class KnowledgeStream:
    """
    Master knowledge ingestion system.
    Provides unlimited knowledge access to Iris.
    """
    
    def __init__(self, memory_core=None, base_dir: str = None):
        print("[KNOWLEDGE-STREAM] Initializing Unlimited Knowledge Channels...")
        
        self.mem = memory_core
        self.base_dir = base_dir or os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        
        # Channels
        self.wiki = WikipediaChannel()
        self.web = WebContentChannel()
        self.docs = LocalDocumentChannel(self.base_dir)
        
        # Queue for background processing
        self.queue: List[KnowledgeItem] = []
        self.processed_count = 0
        self.failed_count = 0
        
        # Background thread (disabled by default)
        self._running = False
        self._thread = None
        
        print("[KNOWLEDGE-STREAM] Channels Ready: Wikipedia, Web, Documents")
    
    def ingest(self, item: KnowledgeItem) -> bool:
        """Ingest a single knowledge item into memory."""
        if self.mem is None:
            self.queue.append(item)
            return False
        
        try:
            from infra.embed_interface import embed_text
            vec = embed_text(item.content)
            
            self.mem.store_cka(
                cka_id=item.id,
                content=item.content,
                x_vec=vec,
                domain=item.domain,
                activation_profile={
                    "triggers": item.domain,
                    "source": item.source
                }
            )
            self.processed_count += 1
            return True
        except Exception as e:
            self.failed_count += 1
            return False
    
    def fetch_wikipedia(self, topics: List[str]) -> int:
        """Fetch and ingest multiple Wikipedia articles."""
        count = 0
        for topic in topics:
            item = self.wiki.fetch(topic)
            if item and self.ingest(item):
                count += 1
                print(f"[WIKI] ✓ {topic}")
        return count
    
    def fetch_url(self, url: str) -> bool:
        """Fetch and ingest a web URL."""
        item = self.web.fetch(url)
        if item:
            return self.ingest(item)
        return False
    
    def load_local(self, pattern: str = None) -> int:
        """Load all local JSONL/TXT files from scenarios/data directories."""
        count = 0
        
        # Scan scenarios directory
        scenarios_dir = os.path.join(self.base_dir, "scenarios")
        if os.path.isdir(scenarios_dir):
            for fname in os.listdir(scenarios_dir):
                if fname.endswith('.jsonl'):
                    items = self.docs.load_jsonl(os.path.join(scenarios_dir, fname))
                    for item in items:
                        if self.ingest(item):
                            count += 1
                    print(f"[LOCAL] ✓ {fname} ({len(items)} items)")
        
        # Scan data/raw directory
        data_raw = os.path.join(self.base_dir, "data", "raw")
        if os.path.isdir(data_raw):
            for root, dirs, files in os.walk(data_raw):
                for fname in files:
                    if fname.endswith('.txt'):
                        items = self.docs.load_txt(os.path.join(root, fname))
                        for item in items:
                            if self.ingest(item):
                                count += 1
                        print(f"[LOCAL] ✓ {fname} ({len(items)} items)")
        
        return count
    
    def bootstrap_knowledge(self) -> Dict:
        """
        Bootstrap initial knowledge from multiple sources.
        Creates a substantial knowledge base for Iris.
        """
        print("\n[KNOWLEDGE-STREAM] === BOOTSTRAPPING KNOWLEDGE BASE ===")
        
        stats = {"wikipedia": 0, "local": 0, "total": 0}
        
        # 1. Load local documents first
        print("\n[1/2] Loading local knowledge...")
        stats["local"] = self.load_local()
        
        # 2. Fetch key Wikipedia articles
        print("\n[2/2] Fetching Wikipedia articles...")
        core_topics = [
            "Artificial_intelligence",
            "Machine_learning",
            "Neuroscience",
            "Cognitive_science",
            "Knowledge_representation",
            "Mathematical_logic",
            "Calculus",
            "Linear_algebra",
            "Physics",
            "Computer_science"
        ]
        stats["wikipedia"] = self.fetch_wikipedia(core_topics)
        
        stats["total"] = stats["local"] + stats["wikipedia"]
        stats["processed"] = self.processed_count
        stats["failed"] = self.failed_count
        
        print(f"\n[KNOWLEDGE-STREAM] Bootstrap Complete: {stats['total']} items ingested")
        
        return stats
    
    def get_stats(self) -> Dict:
        """Get stream statistics."""
        return {
            "processed": self.processed_count,
            "failed": self.failed_count,
            "queued": len(self.queue),
            "memory_connected": self.mem is not None
        }


# Demonstration
if __name__ == "__main__":
    print("=" * 60)
    print("IRIS KNOWLEDGE STREAM - UNLIMITED KNOWLEDGE")
    print("=" * 60)
    
    # Initialize with memory if available
    try:
        from infra.memory_struct import MemoryCore
        mem_dir = os.path.join(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
            "iris_data_genius"
        )
        mem = MemoryCore(mem_dir)
        print("[STREAM] Memory Core connected.")
    except Exception as e:
        print(f"[STREAM] Memory Core not available: {e}")
        mem = None
    
    stream = KnowledgeStream(mem)
    
    # Bootstrap
    stats = stream.bootstrap_knowledge()
    
    print("\n" + "=" * 60)
    print("FINAL STATISTICS")
    print("=" * 60)
    for key, val in stats.items():
        print(f"  {key}: {val}")
    print("=" * 60)
