import os
import json
import time
import hashlib
import hmac
from typing import Dict, Any, Optional

JOURNAL_PATH = "server_logs/provenance.jsonl"
os.makedirs(os.path.dirname(JOURNAL_PATH), exist_ok=True)

# Secret for HMAC signing (simulating actor signature)
# In real production, this would be the actor's private key
SYSTEM_SECRET = b"iris-system-secret-key-change-me" 

class ChainedJournal:
    def __init__(self, filepath=JOURNAL_PATH):
        self.filepath = filepath
        self._ensure_file()
        
    def _ensure_file(self):
        if not os.path.exists(self.filepath):
            with open(self.filepath, 'w') as f:
                # Genesis block
                genesis = {
                    "timestamp": time.time(),
                    "actor": "SYSTEM",
                    "action": "GENESIS",
                    "params": {},
                    "prev_hash": "0" * 64,
                    "signature": "genesis"
                }
                f.write(json.dumps(genesis) + "\n")
                
    def _get_last_entry(self) -> Dict[str, Any]:
        with open(self.filepath, 'r') as f:
            # Read last line efficiently? For now, simple readlines
            lines = f.readlines()
            if not lines:
                return {}
            try:
                return json.loads(lines[-1].strip())
            except:
                return {}

    def _calculate_hash(self, entry: Dict[str, Any]) -> str:
        # Canonical JSON representation for hashing
        # Sort keys to ensure determinism
        # Exclude 'hash' if we were storing it, but we store it implicitly or in next prev_hash
        # Actually, we rely on the line content.
        # But to link, we need the hash of the PREVIOUS entry.
        # Let's say the 'signature' covers the content.
        encoded = json.dumps(entry, sort_keys=True).encode()
        return hashlib.sha256(encoded).hexdigest()

    def log_action(self, actor: str, action: str, params: Dict[str, Any]):
        last_entry = self._get_last_entry()
        
        # Calculate hash of the last entry to use as prev_hash
        # This creates the chain.
        prev_hash = self._calculate_hash(last_entry)
        
        entry = {
            "timestamp": time.time(),
            "actor": actor,
            "action": action,
            "params": params,
            "prev_hash": prev_hash
        }
        
        # Sign the entry (HMAC)
        # In a real system, actor provides this. Here we simulate it.
        # Signature covers actor + action + params + prev_hash + timestamp
        msg = f"{entry['timestamp']}{actor}{action}{json.dumps(params, sort_keys=True)}{prev_hash}".encode()
        signature = hmac.new(SYSTEM_SECRET, msg, hashlib.sha256).hexdigest()
        
        entry["signature"] = signature
        
        with open(self.filepath, 'a') as f:
            f.write(json.dumps(entry) + "\n")
            
        return entry

    def verify_integrity(self) -> bool:
        """
        Walks the chain and verifies all hashes and signatures.
        Returns True if valid, False/Raises if corrupted.
        """
        with open(self.filepath, 'r') as f:
            lines = [l.strip() for l in f.readlines() if l.strip()]
            
        if not lines: return True # Empty is valid-ish
        
        # Check Genesis
        genesis = json.loads(lines[0])
        if genesis["action"] != "GENESIS":
            print("[JOURNAL] Corrupt Genesis Block")
            return False
            
        prev_entry = genesis
        
        for i, line in enumerate(lines[1:], 1):
            curr_entry = json.loads(line)
            
            # 1. Check Link
            expected_prev_hash = self._calculate_hash(prev_entry)
            if curr_entry["prev_hash"] != expected_prev_hash:
                print(f"[JOURNAL] BROKEN CHAIN at line {i+1}")
                print(f"  Expected Prev: {expected_prev_hash}")
                print(f"  Found Prev:    {curr_entry['prev_hash']}")
                return False
                
            # 2. Check Signature
            msg = f"{curr_entry['timestamp']}{curr_entry['actor']}{curr_entry['action']}{json.dumps(curr_entry['params'], sort_keys=True)}{curr_entry['prev_hash']}".encode()
            expected_sig = hmac.new(SYSTEM_SECRET, msg, hashlib.sha256).hexdigest()
            
            if curr_entry["signature"] != expected_sig:
                print(f"[JOURNAL] INVALID SIGNATURE at line {i+1}")
                return False
            
            prev_entry = curr_entry
            
        print(f"[JOURNAL] Integrity Verified. {len(lines)} entries.")
        return True

# Singleton
journal = ChainedJournal()
