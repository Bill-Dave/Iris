import numpy as np
import pytest

def check_numeric(predicted, expected, tol=0.01):
    return abs(predicted - expected) < tol

class STEMEvaluator:
    def __init__(self):
        self.tasks = [
            {"id": "physics_001", "q": "Ball drop from 10m, find v at impact", "ans": 14.0},
            {"id": "math_001", "q": "Integral of 2x from 0 to 5", "ans": 25.0},
        ]

    def run_tests(self, predictor_fn):
        success = 0
        for task in self.tasks:
            pred = predictor_fn(task["q"])
            if check_numeric(pred, task["ans"]):
                success += 1
        return success, len(self.tasks)

def test_stem_homework():
    # Mock predictor for testing the harness
    def mock_predictor(q):
        if "Ball" in q: return 14.0
        if "Integral" in q: return 25.0
        return 0.0
        
    evaluator = STEMEvaluator()
    s, t = evaluator.run_tests(mock_predictor)
    assert s == t
    print(f"\n[EVAL] STEM Success: {s}/{t}")
