import sympy as sp

class SymbolicCheck:
    def verify(self, predicted_str: str, expected_str: str):
        """
        Parses strings into SymPy expressions and checks for symbolic equality.
        Supports standard math notation.
        """
        try:
            p_expr = sp.parse_expr(predicted_str)
            e_expr = sp.parse_expr(expected_str)
            # Simplification check
            diff = sp.simplify(p_expr - e_expr)
            return diff == 0, str(diff)
        except Exception as e:
            return False, str(e)

if __name__ == "__main__":
    checker = SymbolicCheck()
    # Test cases
    print(f"2*x + 1 == x + x + 1: {checker.verify('2*x + 1', 'x + x + 1')[0]}")
    print(f"diff(x**2, x) == 2*x: {checker.verify('diff(x**2, x)', '2*x')[0]}")
    print(f"integrate(x, x) == x**2/2: {checker.verify('integrate(x, x)', 'x**2/2')[0]}")
