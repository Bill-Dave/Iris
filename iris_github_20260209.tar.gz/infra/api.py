import os
import sys
import psutil
import numpy as np
import json
import subprocess
from fastapi import FastAPI, HTTPException, Depends, Body
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Optional, Dict

# Add project root
sys.path.append(os.getcwd())

from infra.auth import verify_token, get_admin_key
from kit_core import MemoryCore, InterferenceEngine
from infra.embed import embed_text # Ensure this is available
from infra.journal import journal # Linked to provenance log

app = FastAPI(title="Iris Neural Observatory API")

# Allow CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# --- State Management ---
class SystemState:
    def __init__(self):
        self.core = None
        self.engine = InterferenceEngine()
        self.external_potentials = None # Map[idx] -> float
        self.last_load_time = 0
        self.npz_path = "kit_memory.npz"

    def load_if_needed(self):
        # We only load ONCE or on explicit reset for the Observatory
        # because the Observatory implies WE are the ones driving the state in memory.
        # But if we want to sync with disk updates? 
        # For this phase, let's load on startup and then maintain state in memory
        # until snapshot is saved.
        if self.core is None and os.path.exists(self.npz_path):
            try:
                data = np.load(self.npz_path)
                # CWS Expansion: Capacity 128 for 10k Scale
                self.core = MemoryCore(dim=384, capacity_max=128.0) 
                self.core.vectors = data['vectors']
                self.core.ids = list(data['ids'])
                self.core.salience = data['salience']
                self.external_potentials = np.zeros(len(self.core.salience))
                
                # Precompute W for speed
                # Lower regularization to support higher active count
                self.engine.lambda_reg = 0.02 
                self.engine.precompute_kernel(self.core.vectors)
                print(f"[API] Loaded memory state (N={self.core.get_count()})")
            except Exception as e:
                print(f"[API] Failed to load memory: {e}")

state = SystemState()

# --- Models ---

class StatusResponse(BaseModel):
    energy: float
    delta_e: float # Change since last step
    t: int # Step counter
    active_count: int
    mode: str # RELAXING / UNSTABLE / CONSOLIDATED
    
class Node(BaseModel):
    id: str
    s: float # Salience
    x: Optional[float] = None
    y: Optional[float] = None
    
class Link(BaseModel):
    source: str
    target: str
    value: float # Similarity

class FieldResponse(BaseModel):
    nodes: List[Node]
    links: List[Link]
    
class InjectRequest(BaseModel):
    text: str
    strength: float = 1.0

class StepRequest(BaseModel):
    dt: float = 0.1
    relax: bool = False

# --- Endpoints ---

@app.get("/status", response_model=StatusResponse, dependencies=[Depends(verify_token)])
async def get_status():
    state.load_if_needed()
    if not state.core:
        return StatusResponse(energy=0.0, delta_e=0.0, t=0, active_count=0, mode="OFFLINE")
    
    # Compute Energy
    E = state.engine.compute_energy(state.core, state.external_potentials)
    active = len(state.core.get_active_indices(0.01))
    
    # Mode heuristic
    mode = "RELAXING"
    if active > 20 and E > -10: mode = "UNSTABLE"
    if active < 5 and active > 0: mode = "CONSOLIDATED"
    
    return StatusResponse(
        energy=float(E),
        delta_e=0.0, # TODO: Track history
        t=0, # TODO: Track global steps
        active_count=active,
        mode=mode
    )

@app.get("/field", response_model=FieldResponse, dependencies=[Depends(verify_token)])
async def get_field():
    state.load_if_needed()
    if not state.core:
        return FieldResponse(nodes=[], links=[])

    # Return only active nodes for the visualizer
    # Threshold 0.01
    active_indices = state.core.get_active_indices(0.01)
    
    nodes = []
    links = []
    
    # Map active indices to local 0..k
    idx_map = {global_idx: local_idx for local_idx, global_idx in enumerate(active_indices)}
    
    for idx in active_indices:
        nodes.append(Node(
            id=state.core.ids[idx],
            s=float(state.core.salience[idx])
        ))
    
    # Compute links (Cosine Sim > 0.3?)
    # Only between active nodes
    active_vecs = state.core.vectors[active_indices]
    if len(active_vecs) > 1:
        sims = np.dot(active_vecs, active_vecs.T)
        rows, cols = np.where(np.triu(sims, 1) > 0.3)
        
        for r, c in zip(rows, cols):
            links.append(Link(
                source=state.core.ids[active_indices[r]],
                target=state.core.ids[active_indices[c]],
                value=float(sims[r, c])
            ))
            
    return FieldResponse(nodes=nodes, links=links)

@app.post("/step", response_model=StatusResponse, dependencies=[Depends(verify_token)])
async def step_physics(req: StepRequest = Body(...)):
    state.load_if_needed()
    if not state.core:
        raise HTTPException(503, "System not loaded")
        
    s_prev = state.core.salience.copy()
    
    # 1. Compute Gradients
    grads = state.engine.compute_gradients(state.core, state.external_potentials)
    
    # 2. Update Core
    state.core.update_dynamics(grads, dt=req.dt)
    
    # 3. Compute new Energy
    E = state.engine.compute_energy(state.core, state.external_potentials)
    
    # Log Step
    journal.log_action("API", "STEP", {"dt": req.dt, "energy": float(E)})
    
    # Delta E heuristic (Current - Previous E approx)
    # Actually explicit calculation is better:
    # but we didn't store prev E. 
    # Let's just return current E.
    
    return StatusResponse(
        energy=float(E),
        delta_e=0.0, 
        t=0,
        active_count=len(state.core.get_active_indices(0.01)),
        mode="STEPPING"
    )

@app.post("/inject", dependencies=[Depends(verify_token)])
async def inject_potential(req: InjectRequest = Body(...)):
    state.load_if_needed()
    if not state.core:
        raise HTTPException(503, "System not loaded")

    # Resolve text to ID
    # If using exact match from vocabulary:
    if req.text in state.core.ids:
        idx = state.core.ids.index(req.text)
        state.external_potentials[idx] = req.strength
        journal.log_action("API", "INJECT", {"id": req.text, "val": req.strength})
        return {"status": "injected", "id": req.text, "val": req.strength}
    
    # If not found, maybe embed? 
    # But disjoint memory... "Only existing concepts can be stimulated"?
    # For now, simplistic: Exact match or nothing.
    # Or, find nearest neighbor?
    
    # Nearest Neighbor injection:
    vec = embed_text(req.text)
    sims = np.dot(state.core.vectors, vec)
    best_idx = np.argmax(sims)
    best_id = state.core.ids[best_idx]
    
    if sims[best_idx] > 0.6:
        # Inject into the nearest concept
        state.external_potentials[best_idx] += req.strength
        journal.log_action("API", "INJECT_NEAREST", {"target": best_id, "sim": float(sims[best_idx])})
        return {"status": "injected_nearest", "target": best_id, "sim": float(sims[best_idx])}
        
    return {"status": "ignored", "reason": "No matching concept"}

@app.post("/reset", dependencies=[Depends(verify_token)])
async def reset_state():
    state.load_if_needed()
    if state.core:
        state.core.salience.fill(0.0)
        state.external_potentials.fill(0.0)
        journal.log_action("API", "RESET", {"status": "cleared"})
    return {"status": "reset"}

if __name__ == "__main__":
    import uvicorn
    print(f"Neural Observatory API. Key: {get_admin_key()}")
    uvicorn.run(app, host="0.0.0.0", port=8000)
