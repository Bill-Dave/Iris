import os
import sys
import json
import tarfile
import time
import shutil
import numpy as np
from typing import Dict, List, Optional, Tuple

# Constants
DATA_DIR = "./iris_data/"
DIM = 1024
RANK = 8

class MemoryCore:
    def __init__(self, data_dir=DATA_DIR):
        self.data_dir = data_dir
        os.makedirs(self.data_dir, exist_ok=True)
        
        # In-memory storage
        # We use dicts for sparse/id access, but arrays for dense ops in dynamics
        # This implementation aligns with the "list of items" or "dense arrays" approach?
        # The prompt implies "Atomic update salience storage".
        # Let's keep data in memory as Arrays for speed, and Maps for ID lookup.
        
        self.ids: List[str] = []
        self.id_to_idx: Dict[str, int] = {}
        self.data_store: Dict[str, str] = {} # Raw text shards
        
        # Dense Arrays
        self.x_store = np.zeros((0, DIM), dtype=np.float32)
        self.U_store = np.zeros((0, DIM, RANK), dtype=np.float32)
        self.lambda_store = np.zeros(0, dtype=np.float32)
        self.s_store = np.zeros(0, dtype=np.float32)
        
        self.load()

    def list_ids(self) -> List[str]:
        return list(self.ids)

    def get_memory(self, item_id: str) -> Dict:
        if item_id not in self.id_to_idx:
            return None
        idx = self.id_to_idx[item_id]
        return {
            "x": self.x_store[idx],
            "U": self.U_store[idx],
            "lambda": self.lambda_store[idx],
            "s": self.s_store[idx],
            "data": self.data_store.get(item_id)
        }

    def store_memory(self, item_id: str, x_vec: np.ndarray, U_mat: Optional[np.ndarray] = None, lambda_scalar: float = 0.01, data: Optional[str] = None):
        """
        Add or Update memory item.
        """
        if x_vec.shape != (DIM,):
            raise ValueError(f"x_vec shape mismatch: {x_vec.shape}")
        
        # Normalize x
        norm = np.linalg.norm(x_vec)
        if norm > 1e-9: x_vec = x_vec / norm
        
        # Default U
        if U_mat is None:
            U_mat = np.zeros((DIM, RANK), dtype=np.float32)
        else:
            if U_mat.shape != (DIM, RANK):
                raise ValueError(f"U_mat shape mismatch: {U_mat.shape}")

        if item_id in self.id_to_idx:
            # Update existing
            idx = self.id_to_idx[item_id]
            self.x_store[idx] = x_vec
            self.U_store[idx] = U_mat
            self.lambda_store[idx] = lambda_scalar
            # Keep existing s
        else:
            # Append new
            idx = len(self.ids)
            self.ids.append(item_id)
            self.id_to_idx[item_id] = idx
            
            # Expand arrays
            # (Inefficient for single adds, but acceptable for prototype)
            # In production, use pre-allocation or chunking.
            self.x_store = np.vstack([self.x_store, x_vec.reshape(1, DIM)])
            
            self.U_store = np.concatenate([self.U_store, U_mat.reshape(1, DIM, RANK)], axis=0)
            
            new_lambda = np.array([lambda_scalar], dtype=np.float32)
            self.lambda_store = np.concatenate([self.lambda_store, new_lambda])
            
            new_s = np.array([0.0], dtype=np.float32)
            self.s_store = np.concatenate([self.s_store, new_s])
            
        if data is not None:
            self.data_store[item_id] = data
            
        self._append_meta_log(item_id, "STORE")
        self._atomic_save_all() # Ensure atomic persistence on write

    def store_cka(self, cka_id: str, content: str, x_vec: np.ndarray, claims: List[str] = None, 
                  constraints: Dict = None, domain: List[str] = None, 
                  activation_profile: Dict = None, interference_profile: Dict = None):
        """
        Stores a Canonical Knowledge Atom (CKA) with rich metadata and potential pathways.
        """
        cka_payload = {
            "id": cka_id,
            "content": content,
            "claims": claims or [],
            "constraints": constraints or {},
            "domain": domain or [],
            "activation_profile": activation_profile or {},
            "interference_profile": interference_profile or {},
            "t_created": time.time()
        }
        
        # Store vector and raw payload
        self.store_memory(cka_id, x_vec, data=json.dumps(cka_payload))

    def update_activation(self, item_id: str, new_s: float):
        if item_id in self.id_to_idx:
            idx = self.id_to_idx[item_id]
            self.s_store[idx] = np.clip(new_s, 0.0, 1.0)
            # We assume batch updates call _save_salience separately
            # But prompt says "atomic_update_salience".
            # If this is called in a loop, we shouldn't save every time.
            # We'll expose explicit save_salience method.

    def save_salience(self):
        """Atomic write of salience.bin"""
        path = os.path.join(self.data_dir, "salience.bin")
        tmp = path + ".tmp"
        with open(tmp, 'wb') as f:
            np.save(f, self.s_store)
        os.replace(tmp, path)

    def find_nearest(self, query_vec: np.ndarray, n: int = 1) -> List[Tuple[str, float]]:
        """
        Nearest neighbor search via cosine similarity.
        """
        if self.x_store.shape[0] == 0:
            return []
            
        # Normalize query
        qn = np.linalg.norm(query_vec)
        if qn > 1e-9: query_vec = query_vec / qn
        
        # Dot products (since both are normalized, this is cosine similarity)
        scores = np.dot(self.x_store, query_vec)
        top_indices = np.argsort(scores)[::-1][:n]
        
        results = []
        for idx in top_indices:
            results.append((self.ids[idx], float(scores[idx])))
        return results

    def _atomic_save_all(self):
        """Saves all state buckets atomically."""
        # 1. Vectors
        p_vec = os.path.join(self.data_dir, "vectors_tier2.bin")
        with open(p_vec + ".tmp", 'wb') as f:
            np.save(f, self.x_store)
        os.replace(p_vec + ".tmp", p_vec)
        
        # 2. U Matrices
        p_u = os.path.join(self.data_dir, "U_store.npy")
        with open(p_u + ".tmp", 'wb') as f:
            np.save(f, self.U_store)
        os.replace(p_u + ".tmp", p_u)
        
        # 3. Lambdas
        p_lam = os.path.join(self.data_dir, "lambda.bin")
        with open(p_lam + ".tmp", 'wb') as f:
            np.save(f, self.lambda_store)
        os.replace(p_lam + ".tmp", p_lam)
        
        # 4. Salience
        self.save_salience()
        
        p_ids = os.path.join(self.data_dir, "ids.json")
        with open(p_ids + ".tmp", 'w') as f:
            json.dump(self.ids, f)
        os.replace(p_ids + ".tmp", p_ids)
        
        # 6. Raw Data Store
        p_data = os.path.join(self.data_dir, "data_store.json")
        with open(p_data + ".tmp", 'w') as f:
            json.dump(self.data_store, f)
        os.replace(p_data + ".tmp", p_data)

    def load(self):
        """Loads state from data_dir."""
        try:
            p_ids = os.path.join(self.data_dir, "ids.json")
            if os.path.exists(p_ids):
                with open(p_ids, 'r') as f:
                    self.ids = json.load(f)
                self.id_to_idx = {uid: i for i, uid in enumerate(self.ids)}
            
            p_vec = os.path.join(self.data_dir, "vectors_tier2.bin")
            if os.path.exists(p_vec):
                self.x_store = np.load(p_vec)
                
            p_u = os.path.join(self.data_dir, "U_store.npy")
            if os.path.exists(p_u):
                self.U_store = np.load(p_u)
                
            p_lam = os.path.join(self.data_dir, "lambda.bin")
            if os.path.exists(p_lam):
                self.lambda_store = np.load(p_lam)
                
            p_s = os.path.join(self.data_dir, "salience.bin")
            if os.path.exists(p_s):
                self.s_store = np.load(p_s)
            
            p_data = os.path.join(self.data_dir, "data_store.json")
            if os.path.exists(p_data):
                with open(p_data, 'r') as f:
                    self.data_store = json.load(f)
                
        except Exception as e:
            print(f"[MEMORY] Load warning: {e}. Starting fresh.")
            # Fallback to empty
            pass

    def _append_meta_log(self, item_id, action):
        p_meta = os.path.join(self.data_dir, "meta.jsonl")
        entry = {
            "t": time.time(),
            "id": item_id,
            "act": action
        }
        with open(p_meta, 'a') as f:
            f.write(json.dumps(entry) + "\n")

    def snapshot(self, tag: str) -> str:
        """Creates tar.gz of iris_data"""
        self._atomic_save_all() # Ensure on-disk is fresh
        
        snap_name = f"snapshot_{tag}.tar.gz"
        # We store snapshots one level up to avoid recursion if they are inside data_dir?
        # User said "creates tar gz of iris_data".
        # Let's put snapshots in ./snapshots/
        out_dir = "./snapshots"
        os.makedirs(out_dir, exist_ok=True)
        out_path = os.path.join(out_dir, snap_name)
        
        with tarfile.open(out_path, "w:gz") as tar:
            tar.add(self.data_dir, arcname=os.path.basename(self.data_dir))
            
        print(f"[MEMORY] Snapshot led: {out_path}")
        return tag

    def load_snapshot(self, tag: str):
        snap_path = os.path.join("./snapshots", f"snapshot_{tag}.tar.gz")
        if not os.path.exists(snap_path):
            raise FileNotFoundError(f"Snapshot {tag} not found.")
            
        # WIPE current
        if os.path.exists(self.data_dir):
            shutil.rmtree(self.data_dir)
            
        # Extract
        with tarfile.open(snap_path, "r:gz") as tar:
            tar.extractall(path=".") # Checks arcname to restore into ./iris_data
            
        self.load() # Reload into memory
        print(f"[MEMORY] Restored snapshot: {tag}")

if __name__ == "__main__":
    # CLI for snapshot/restore as requested
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--snapshot", action="store_true")
    parser.add_argument("--restore", action="store_true")
    parser.add_argument("--tag", type=str, required=True)
    args = parser.parse_args()
    
    mem = MemoryCore()
    if args.snapshot:
        mem.snapshot(args.tag)
    elif args.restore:
        mem.load_snapshot(args.tag)
