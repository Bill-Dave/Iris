import psutil
import time
import os

class ThermalGovernor:
    def __init__(self, cpu_threshold: float = 0.85):
        self.cpu_threshold = cpu_threshold
        self.history = []
        self.window = 5

    def check_system_state(self) -> dict:
        """
        Returns a scaling config based on system load.
        """
        load = psutil.cpu_percent(interval=0.1) / 100.0
        self.history.append(load)
        if len(self.history) > self.window:
            self.history.pop(0)
            
        avg_load = sum(self.history) / len(self.history)
        
        config = {
            "load": avg_load,
            "N_c": 128,
            "use_tier_b": True,
            "mcts_iters": 5
        }
        
        if avg_load > self.cpu_threshold:
            # Overloaded: scale back to preserve bandwidth for browser/google
            config["N_c"] = 64
            config["use_tier_b"] = False
            config["mcts_iters"] = 1
            print(f"[GOVERNOR] High load detected ({avg_load:.2f}). Scaling back to ULP-Safe mode.")
            
        return config

    def sleep_reflective(self, duration: float):
        """Mandatory reflective cooling."""
        time.sleep(duration)
