import os
import json
import time
import copy
import numpy as np
from typing import Dict, List, Tuple
from infra.memory_struct import MemoryCore
from infra.kit_engine_v3 import KITEngineV3

class ShadowKITEngine(KITEngineV3):
    """
    A mutable variant of the KIT Engine for testing optimizations.
    """
    def mutate(self, perturbation: float = 0.05):
        # Apply random mutation to mathematical hyperparameters
        self.eta *= (1.0 + np.random.uniform(-perturbation, perturbation))
        self.lambda_reg *= (1.0 + np.random.uniform(-perturbation, perturbation))
        self.capacity_S *= (1.0 + np.random.uniform(-perturbation, perturbation))

class MutationEngine:
    def __init__(self, memory_core: MemoryCore):
        self.mem = memory_core
        self.active_engine = KITEngineV3(self.mem)
        self.mutation_log = "logs/mutation_history.jsonl"
        os.makedirs("logs", exist_ok=True)

    def benchmark_engine(self, engine: KITEngineV3, test_queries: List[str]) -> Dict[str, float]:
        """
        Runs a 'Cognitive Sprint' to evaluate engine performance.
        """
        results = {"precision": 0.0, "efficiency": 0.0}
        total_steps = 0
        
        for query in test_queries:
            query_vec = np.random.rand(1024).astype(np.float32) # Mock vector for design phase
            # In a real run, we would use embed_text(query)
            
            candidates = [c[0] for c in self.mem.find_nearest(query_vec, n=10)]
            if not candidates: continue
            
            start_time = time.time()
            assembly = engine.solve_evolution(query, query_vec, candidates)
            duration = time.time() - start_time
            
            # Efficiency Factor: higher is better (based on duration and assembly strength)
            results["efficiency"] += 1.0 / (duration + 1e-6)
            if assembly:
                results["precision"] += sum([a[1] for a in assembly]) / len(assembly)
        
        n = len(test_queries)
        if n > 0:
            results["precision"] /= n
            results["efficiency"] /= n
            
        return results

    def run_mutation_loop(self):
        print("[RSI] Initiating Shadow Mutation Loop...")
        test_queries = [
            "What are the three axioms of Iris?",
            "Explain Knowledge Interference Theory.",
            "Synthesize alignment for a strategic deep-tech fund.",
            "How does APRA resolve logic conflicts?"
        ]
        
        # 1. Baseline Performance
        baseline = self.benchmark_engine(self.active_engine, test_queries)
        print(f"[RSI] Baseline: Precision={baseline['precision']:.4f}, Efficiency={baseline['efficiency']:.4f}")
        
        # 2. Create Shadow Mutant
        shadow = ShadowKITEngine(self.mem)
        shadow.mutate()
        
        # 3. Benchmark Mutant
        mutant_perf = self.benchmark_engine(shadow, test_queries)
        print(f"[RSI] Mutant: Precision={mutant_perf['precision']:.4f}, Efficiency={mutant_perf['efficiency']:.4f}")
        
        # 4. Survival of the Fittest
        if mutant_perf["precision"] >= baseline["precision"] and mutant_perf["efficiency"] > baseline["efficiency"]:
            print("[RSI] MUTATION PROMOTED: Shadow state is technically superior.")
            self.active_engine = shadow
            self._log_mutation(baseline, mutant_perf, status="PROMOTED")
            return shadow
        else:
            print("[RSI] MUTATION REJECTED: Shadow state failed to achieve gain.")
            self._log_mutation(baseline, mutant_perf, status="REJECTED")
            return None

    def _log_mutation(self, baseline, mutant, status):
        entry = {
            "timestamp": time.time(),
            "status": status,
            "baseline": baseline,
            "mutant": mutant
        }
        with open(self.mutation_log, "a") as f:
            f.write(json.dumps(entry) + "\n")

if __name__ == "__main__":
    m = MemoryCore("./iris_data_genius")
    rsi = MutationEngine(m)
    rsi.run_mutation_loop()
