import numpy as np
import math

class MCTSNode:
    def __init__(self, state, parent=None, action=None):
        self.state = state # x vector
        self.parent = parent
        self.action = action # a vector
        self.action_idx = None
        self.children = []
        self.n = 0 # visits
        self.w = 0.0 # total value
        self.q = 0.0 # avg value

    def is_fully_expanded(self, num_actions):
        return len(self.children) >= num_actions

class MCTS:
    def __init__(self, world_model, intrinsic_motivator, c_param=1.414):
        self.wm = world_model
        self.im = intrinsic_motivator
        self.c = c_param
        
    def search(self, root_state, iterations=100, actions=None):
        root = MCTSNode(root_state)
        num_actions = len(actions) if actions is not None else 0
        if num_actions == 0: return None
        
        for _ in range(iterations):
            node = self._select(root)
            if not node.is_fully_expanded(num_actions):
                # Pick a random action not yet expanded
                expanded_actions = [c.action_idx for c in node.children]
                available = [i for i in range(num_actions) if i not in expanded_actions]
                if available:
                    act_idx = np.random.choice(available)
                    node = self._expand(node, actions[act_idx], act_idx)
            reward = self._simulate(node)
            self._backpropagate(node, reward)
            
        # Select best action from root
        if not root.children: return None
        best_child = max(root.children, key=lambda c: c.n)
        return best_child.action_idx

    def _select(self, node):
        while node.children:
            if not all(c.n > 0 for c in node.children):
                return node
            # UCT Selection
            node = max(node.children, key=lambda c: c.q + self.c * math.sqrt(math.log(max(1, node.n)) / max(1, c.n)))
        return node

    def _expand(self, node, action, action_idx):
        # Predict next state (Simplified: dummy context for now)
        ctx = np.zeros((1, 384), dtype=np.float32)
        x_in = node.state.reshape(1, -1)
        a_in = action.reshape(1, -1)
        
        next_state = self.wm.forward_model(x_in, a_in, ctx)[0]
        
        child = MCTSNode(next_state, parent=node, action=action)
        child.action_idx = action_idx
        node.children.append(child)
        return child

    def _simulate(self, node):
        # Lightweight rollout or direct reward
        h = self.im.hash_state(node.state)
        return self.im.compute_reward(0.0, h)

    def _backpropagate(self, node, reward):
        curr = node
        while curr:
            curr.n += 1
            curr.w += reward
            curr.q = curr.w / curr.n
            curr = curr.parent
