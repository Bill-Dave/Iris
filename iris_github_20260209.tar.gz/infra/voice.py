import numpy as np
import random
import json
from infra.embed_interface import embed_text

class VoiceEngine:
    def __init__(self, memory_core):
        self.mem = memory_core
        # Common Genius-level stylistic fillers
        self.fillers = [
            "Based on Iris's conceptual alignment,",
            "Analyzing the underlying mechanics of the KIT substrate,",
            "The synthesized data suggests that",
            "From the perspective of the Iris AGI kernel,",
            "Regarding the strategic alignment,",
            "The cognitive assembly for this inquiry indicates that"
        ]
        self.personality_voice = "Iris"

    def synthesize(self, task_desc, raw_logic):
        """
        Legacy single-shard synthesis. Forwards to assembly synthesis.
        """
        return self.synthesize_assembly(task_desc, [(task_desc, 1.0)], narrative_mode=False)

    def synthesize_assembly(self, query_text: str, assembly: List[Tuple[str, float]], narrative_mode: bool = False) -> str:
        """
        Transforms a whole cognitive assembly into a unique first-person response.
        If narrative_mode is True, it bypasses fillers for direct technical exposition.
        """
        if not assembly:
            return "I have processed your input, but no significant cognitive potential was reached."

        # 1. Collect best claims
        import re
        active_claims = []
        for uid, salience in assembly:
            if salience < 0.15: continue
            
            m = self.mem.get_memory(uid)
            if not m or not m.get('data'): continue
            
            try:
                data = json.loads(m['data'])
                content = data.get('content', '')
                if content:
                    # Clean up content
                    content = re.sub(r'#.*?\n', '', content).strip()
                    if content and content not in active_claims:
                        active_claims.append(content)
            except: continue
        
        if not active_claims:
            return "My internal weights did not reach a definitive conclusion."

        # 2. Synthesis Construction
        if narrative_mode:
            # Direct technical exposition with light connective tissue
            if not active_claims:
                return "My internal weights did not reach a definitive conclusion."
            
            # Start with the most foundational claim
            lead_claim = active_claims[0]
            other_claims = active_claims[1:10] # Bring in more depth
            
            narrative_blocks = [lead_claim]
            for i, claim in enumerate(other_claims):
                # Add light connective markers
                if "Axiom" in claim:
                    narrative_blocks.append(f"\n{claim}")
                elif "Focus:" in claim or "Specific Requirement:" in claim:
                    # These come from fund profiles
                    narrative_blocks.append(f"\n[Alignment Analysis] {claim}")
                else:
                    narrative_blocks.append(claim)
                    
            final_narrative = "\n\n".join(narrative_blocks)
            
            # Mission Conclusion (Authentic Synthesis)
            conclusion = "\n\nThis synthesis represents a stable cognitive trajectory derived from the axial foundations of Sapient Intelligence. We are ready to execute on these strategic alignments."
            return final_narrative + conclusion

        # 3. Standard First-Person Construction
        main_points = active_claims[:3]
        narrative = ". ".join(main_points)
        if not narrative.endswith("."):
            narrative += "."
            
        meta_reflection = ""
        if len(assembly) > 1:
            meta_reflection = f" I have synthesized this from {len(assembly)} cross-referenced knowledge atoms."
        
        ownership_starts = [
            "Iris has derived this conclusion from the established technical trajectory: ",
            "The cognitive pathways for this project align on the following: ",
            "The Iris kernel can state with high-fidelity that: ",
            "Processing this inquiry through the Sapient Intelligence neural assembly, the system finds: "
        ]
        
        return f"{random.choice(ownership_starts)}{narrative}{meta_reflection}"

    def greet(self):
        return "Greetings. This is Iris. I have synthesized my recent cognitive experiences. How can I assist your engineering goals today?"
