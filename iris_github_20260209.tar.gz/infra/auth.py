import os
import hmac
import hashlib
import secrets
from fastapi import HTTPException, Header, Depends

KEY_FILE = os.path.expanduser("~/.iris_admin_key")

def get_admin_key():
    """Load or create the admin key."""
    if not os.path.exists(KEY_FILE):
        # Create a new key
        key = secrets.token_hex(32)
        with open(KEY_FILE, "w") as f:
            f.write(key)
        # Set permissions to read/write for user only
        os.chmod(KEY_FILE, 0o600)
    
    with open(KEY_FILE, "r") as f:
        return f.read().strip()

ADMIN_KEY = get_admin_key()

def verify_token(x_iris_token: str = Header(...)):
    """Validate the auth token."""
    # In a real HMAC setup, we might sign a message. 
    # For this phase, we'll use a simple strict equality or a derived hash check.
    # The prompt says: "HMAC key stored offline... any destructive op requires..."
    # Phase 9 requirements just say "required auth token".
    # Let's simple check if the token matches the stored key for now 
    # OR implement a proper HMAC signature check if the token is "timestamp:signature".
    # To keep things simple for the UI (which needs to just send a token),
    # we'll assume the client sends the RAW key or a hash of it.
    # Let's expect the raw key for this "local-file" security model.
    # Using secrets.compare_digest to prevent timing attacks.
    if not secrets.compare_digest(x_iris_token, ADMIN_KEY):
        raise HTTPException(status_code=401, detail="Invalid X-Iris-Token")
    return True
