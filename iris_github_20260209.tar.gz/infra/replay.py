import numpy as np
import random
from .hebbian import hebbian_update
from .consolidation import ConsolidationEngine

class ReplayBuffer:
    def __init__(self, capacity=10000):
        self.capacity = capacity
        self.buffer = [] # (priority, data)
        self.pos = 0
        
    def add(self, x, a, x_next, context, error, meta):
        priority = (error + 1e-5) ** 0.6
        data = (x, a, x_next, context, meta)
        
        if len(self.buffer) < self.capacity:
            self.buffer.append((priority, data))
        else:
            self.buffer[self.pos] = (priority, data)
            self.pos = (self.pos + 1) % self.capacity
            
    def sample(self, batch_size):
        if not self.buffer: return []
        
        priorities = np.array([p for p, _ in self.buffer])
        probs = priorities / np.sum(priorities)
        
        indices = np.random.choice(len(self.buffer), batch_size, p=probs)
        batch = [self.buffer[i][1] for i in indices]
        return batch

class SleepEngine:
    def __init__(self, world_model, memory_core):
        self.wm = world_model
        self.mem = memory_core
        self.buffer = ReplayBuffer()
        self.cons = ConsolidationEngine(memory_core)
        
    def sleep_pass(self, num_batches=10):
        if not self.buffer.buffer: return
        
        # print(f"[SLEEP] Starting pass with {len(self.buffer.buffer)} memories.")
        
        # 1. Gradient Steps
        for _ in range(num_batches):
            batch = self.buffer.sample(32) # Small batch for sleep
            if not batch: break
            
            # Prepare Arrays
            bx, ba, bxn, bctx, _ = zip(*batch)
            x_in = np.array(bx, dtype=np.float32)
            a_in = np.array(ba, dtype=np.float32)
            xn_in = np.array(bxn, dtype=np.float32)
            ctx_in = np.array(bctx, dtype=np.float32)
            
            # Negatives? 
            negs = np.zeros((32, 10, 384)) # Dummy for now
            
            loss, _ = self.wm.train_step((x_in, a_in, xn_in, ctx_in, negs))
            
        # 2. Consolidation & Hebbian
        # Iterate over high-priority items and strengthen their assemblies
        top_indices = np.argsort([p for p, _ in self.buffer.buffer])[-num_batches:]
        for idx in top_indices:
            _, data = self.buffer.buffer[idx]
            meta = data[4] # Meta is idx 4 now
            assembly = meta.get("assembly_ids", [])
            
            if assembly:
                # Hebbian Micro-Updates (Unsupervised)
                hebbian_update(self.mem, assembly)
                
                # Structural Consolidation (Compatibility-based)
                self.cons.consolidate_assembly(assembly, reward=1.0)
                
        pass
