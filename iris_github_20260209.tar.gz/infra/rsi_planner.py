import numpy as np
from .code_env import CodeEnv
from .embed_interface import embed_text
from .mcts import MCTS
from .lookback import LookBackEngine

class RSIPlanner:
    def __init__(self, memory_core, dynamics_engine, world_model, intrinsic_motivator):
        self.mem = memory_core
        self.dyn = dynamics_engine
        self.env = CodeEnv()
        self.mcts = MCTS(world_model, intrinsic_motivator)
        self.lookback = LookBackEngine(memory_core)
        
        # Seed Skills (The "DNA")
        self.skills = [
            {
                "desc": "Calculate sum",
                "code": "result = sum(args)",
                "vec": embed_text("Calculate sum"),
                "act": np.random.randn(16).astype(np.float32)
            },
            {
                "desc": "Find max",
                "code": "result = max(args)",
                "vec": embed_text("Find max"),
                "act": np.random.randn(16).astype(np.float32)
            },
            {
                 "desc": "Loop print",
                 "code": "result = [i*2 for i in range(args)]",
                 "vec": embed_text("Loop print double"),
                 "act": np.random.randn(16).astype(np.float32)
            }
        ]

    def mcts_reason(self, state_vec, iterations=5):
        """
        Runs MCTS to find the best Skill Index. 
        Iterations capped for thermal safety on Intel Mac.
        """
        actions = [s["act"] for s in self.skills]
        best_idx = self.mcts.search(state_vec, iterations=iterations, actions=actions)
        return best_idx
        
    def solve(self, task_desc, args, iterations=5):
        print(f"[RSI-REASON] Solving: '{task_desc}' with MCTS refinement (ULP: {iterations} iters)...")
        task_vec = embed_text(task_desc)
        
        # 1. Reason via MCTS
        best_skill_idx = self.mcts_reason(task_vec, iterations=iterations)
        
        # 2. Select Skill
        if best_skill_idx is None:
            print("[RSI] MCTS search failed. Falling back to KNN.")
            best_skill = None
            best_score = -1.0
            for s in self.skills:
                score = np.dot(task_vec, s["vec"])
                if score > best_score:
                    best_score = score
                    best_skill = s
        else:
            best_skill = self.skills[best_skill_idx]
            print(f"[RSI-MCTS] MCTS selected skill index: {best_skill_idx} ({best_skill['desc']})")
            
        # 3. Add Context/Args
        full_code = f"args = {repr(args)}\n" + best_skill["code"]
        
        # 4. Execute
        out, err, success = self.env.execute(full_code)
        
        # 5. Self-Correction (Simple)
        if not success:
            print(f"[RSI] Error: {err.strip()}. failing.")
            return None, False
            
        # 6. Look Back (Intelligence Check)
        if success:
             self.lookback.review_episode([f"skill_{best_skill['desc']}"], True)

        # Extract result from namespace
        res = self.env.namespace.get("result", None)
        return res, True
