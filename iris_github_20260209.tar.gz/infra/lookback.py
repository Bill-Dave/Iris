import numpy as np

class LookBackEngine:
    def __init__(self, memory_core, gamma=0.05):
        self.mem = memory_core
        self.gamma = gamma # Learning rate for persistence
        
    def review_episode(self, episode_ids, success_bool):
        """
        success_bool: if the episode ended in a 'win'.
        We strengthen the memories that were active during the episode.
        """
        if not success_bool:
            return # Maybe weaken them in a real brain?
            
        print(f"[LOOKBACK] Reviewing successful episode of {len(episode_ids)} items.")
        
        # 1. Identify active memories
        # We assume the list contains IDs of memories that were part of the assemblies
        for uid in episode_ids:
            if uid in self.mem.id_to_idx:
                idx = self.mem.id_to_idx[uid]
                
                # 2. Update Persistence (lambda)
                # Success leads to higher 'staying power'
                old_lambda = self.mem.lambda_store[idx]
                delta = self.gamma * (1.0 - old_lambda) # Asymptotic growth
                self.mem.lambda_store[idx] += delta
                
        # Persist changes
        self.mem._atomic_save_all()
        print(f"[LOOKBACK] Strengthened {len(episode_ids)} memories.")
