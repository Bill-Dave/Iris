import numpy as np
import time
import os
from infra.world_model import WorldModel
from infra.planner_mcts import MCTSPlanner

class ReplayBuffer:
    def __init__(self, capacity=500000, d=384):
        self.capacity = capacity
        self.states = np.zeros((capacity, d), dtype=np.float32)
        self.actions = np.zeros((capacity, 16), dtype=np.float32)
        self.next_states = np.zeros((capacity, d), dtype=np.float32)
        self.contexts = np.zeros((capacity, d), dtype=np.float32)
        self.pos = 0
        self.size = 0

    def add(self, s, a, sn, c):
        self.states[self.pos] = s
        self.actions[self.pos] = a
        self.next_states[self.pos] = sn
        self.contexts[self.pos] = c
        self.pos = (self.pos + 1) % self.capacity
        self.size = min(self.size + 1, self.capacity)

    def sample(self, batch_size):
        idx = np.random.choice(self.size, batch_size)
        return self.states[idx], self.actions[idx], self.next_states[idx], self.contexts[idx]

def train_loop(steps=1000, batch_size=32):
    print(f"[GENIUS-CPU] Starting Hardware-Tailored Training ({steps} steps)...")
    d, k = 384, 64
    wm = WorldModel(d=d, k=k)
    buffer = ReplayBuffer(capacity=100000, d=d)
    mem_store = {} # Simplified
    
    planner = MCTSPlanner(wm, mem_store)
    
    start_t = time.time()
    for i in range(steps):
        # 1. Update from Buffer
        if buffer.size > batch_size:
            s, a, sn, c = buffer.sample(batch_size)
            loss, lf, li, _ = wm.train_step(s, a, sn, c)
            if i % 100 == 0:
                elapsed = time.time() - start_t
                print(f"[{i:05d}] Loss: {loss:.4f} (Fwd: {lf:.4f}, Inv: {li:.4f}) | {elapsed:.1f}s")

        # 2. Rollout (Simulation interaction)
        s = np.random.randn(d).astype(np.float32)
        c = np.random.randn(d).astype(np.float32)
        actions = [np.random.randn(16).astype(np.float32) for _ in range(4)]
        best_a = planner.search(s, c, iterations=5, actions=actions)
        
        if best_a is not None:
            sn = s + 0.1 * best_a.sum() + np.random.randn(d) * 0.01 
            buffer.add(s, best_a, sn, c)
        
        # CPU Throttling
        time.sleep(0.1)
            
    print("[GENIUS-CPU] Training complete. Saving NumPy model...")
    wm.save("infra/snapshots/wm_phaseB_cpu.npz")
    print(f"[METRICS] Total Duration: {time.time() - start_t:.1f}s")

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--steps", type=int, default=1000)
    args = parser.parse_args()
    train_loop(steps=args.steps)
