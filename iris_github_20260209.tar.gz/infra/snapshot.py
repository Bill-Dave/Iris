import os
import tarfile
import argparse
from datetime import datetime

def create_snapshot(tag=None):
    if tag is None:
        tag = f"snapshot_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
    
    cwd = os.getcwd()
    filename = f"{tag}.tar.gz"
    
    print(f"[KIT] Creating snapshot: {filename}")
    
    # Files/Dirs to include
    targets = [
        'kit_core',
        'iris_unified.py',
        'infra',
        'tools',
        'tests',
        'teacher',
        'task.md',
        'implementation_plan_refined_kit_cycle.md'
    ]
    
    with tarfile.open(filename, "w:gz") as tar:
        for target in targets:
            path = os.path.join(cwd, target)
            if os.path.exists(path):
                tar.add(target)
                
    print(f"[KIT] Snapshot complete: {filename}")
    return tag

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--tag", type=str, default=None)
    args = parser.parse_args()
    create_snapshot(args.tag)
