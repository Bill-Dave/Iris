import sys
import os
import time
import numpy as np
import psutil

# Add project root
sys.path.append(os.getcwd())

from kit_core import MemoryCore, InterferenceEngine

def run_load_test(N=10000, steps=100):
    print(f"[LOAD TEST] Initializing MemoryCore with N={N}...")
    
    core = MemoryCore(dim=384, capacity_max=50.0)
    engine = InterferenceEngine()
    
    # Generate synthetic data
    # Random normalized vectors
    vectors = np.random.normal(0, 1, (N, 384)).astype(np.float32)
    vectors /= np.linalg.norm(vectors, axis=1, keepdims=True)
    
    core.vectors = vectors
    core.ids = [f"item_{i}" for i in range(N)]
    core.salience = np.zeros(N, dtype=np.float32)
    
    # Activate random 10%
    active_mask = np.random.rand(N) < 0.1
    core.salience[active_mask] = np.random.rand(np.sum(active_mask))
    
    print("[LOAD TEST] Precomputing Kernel...")
    t0 = time.time()
    engine.precompute_kernel(core.vectors)
    print(f"[LOAD TEST] Kernel computed in {time.time()-t0:.4f}s")
    
    print(f"[LOAD TEST] Running {steps} steps...")
    
    times_grad = []
    times_update = []
    
    ext_pot = np.zeros(N)
    
    # Warmup
    engine.compute_gradients(core, ext_pot)
    
    for i in range(steps):
        t_start = time.time()
        grads = engine.compute_gradients(core, ext_pot)
        t_grad = time.time()
        
        core.update_dynamics(grads, dt=0.1)
        t_update = time.time()
        
        times_grad.append(t_grad - t_start)
        times_update.append(t_update - t_grad)
        
    print(f"\n[RESULTS N={N}]")
    print(f"Gradient Mean: {np.mean(times_grad)*1000:.2f} ms")
    print(f"Update Mean:   {np.mean(times_update)*1000:.2f} ms")
    print(f"Total Tick:    {(np.mean(times_grad) + np.mean(times_update))*1000:.2f} ms")
    
    mem_mb = psutil.Process(os.getpid()).memory_info().rss / 1024 / 1024
    print(f"Memory Usage:  {mem_mb:.2f} MB")
    
    # Test Hebbian
    print("\n[LOAD TEST] Benchmark Hebbian (Vectorized)...")
    t0 = time.time()
    core.hebbian_learning()
    print(f"Hebbian Step:  {(time.time()-t0)*1000:.2f} ms")

if __name__ == "__main__":
    N = int(sys.argv[1]) if len(sys.argv) > 1 else 10000
    run_load_test(N)
