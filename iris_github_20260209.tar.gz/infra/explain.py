import numpy as np

class ExplanationEngine:
    def __init__(self, memory_core, lookback_engine):
        self.mem = memory_core
        self.lookback = lookback_engine

    def generate_trace_explanation(self, task_desc, assembly_id=None):
        """
        Synthesizes an explanation based on the active memory state.
        """
        explanation = f"Reasoning for '{task_desc}':\n"
        
        # 1. Inspect Assemblies
        if assembly_id:
            explanation += f"- Active Assembly: {assembly_id}\n"
        
        # 2. Inspect Causal Chain from Lookback
        recent_memories = self.lookback.causal_chain[-3:] if hasattr(self.lookback, 'causal_chain') else []
        if recent_memories:
            explanation += f"- Anchored to memories: {', '.join(recent_memories)}\n"
        
        # 3. Mechanistic state (mocked for demo logic)
        explanation += "- State: Energy minima reached via Pointer-Address relaxation."
        
        return explanation

    def explain_interaction(self, input_text, result_text):
        # Placeholder for more complex NLP synthesis
        return f"Interaction complete. Result '{result_text}' derived from '{input_text}' patterns."
