import numpy as np
import time

class HierarchyCore:
    def __init__(self, memory_core, chunk_size=5):
        self.mem = memory_core
        self.chunk_size = chunk_size
        self.buffer = [] # Pending atomic IDs
        
    def add_event(self, atomic_id):
        self.buffer.append(atomic_id)
        
        if len(self.buffer) >= self.chunk_size:
            self._chunk_and_store()
            
    def _chunk_and_store(self):
        # Create a Concept Memory
        concept_ids = list(self.buffer)
        
        # 1. Aggregate Vector (Mean of atomics is simple)
        # Better: RNN state or Sequence embedding.
        # Simple: Mean
        indices = [self.mem.id_to_idx[uid] for uid in concept_ids if uid in self.mem.id_to_idx]
        if not indices: return
        
        vectors = self.mem.x_store[indices]
        concept_vec = np.mean(vectors, axis=0)
        norm = np.linalg.norm(concept_vec)
        if norm > 0: concept_vec /= norm
        
        # 2. Store Concept
        concept_id = f"concept_{int(time.time()*1000)}"
        
        # We need a way to link Concept -> Atomics.
        # We can use the U_matrix!
        # Concept U aligns with Atomic (x) ??
        # Or Just store meta link.
        self.mem.store_memory(concept_id, concept_vec)
        
        # Clear buffer
        self.buffer = []
        
        print(f"[HIERARCHY] Formed concept {concept_id} from {len(concept_ids)} events.")
        return concept_id
