import os
import json
import re
import time
from typing import List, Dict
from infra.memory_struct import MemoryCore
from infra.voice import VoiceEngine
from infra.kit_engine_v3 import KITEngineV3
from infra.embed_interface import embed_text
from infra.physical_bridge import PhysicalBridge

class OutreachAgent:
    def __init__(self, memory_core: MemoryCore):
        self.mem = memory_core
        self.kit = KITEngineV3(self.mem)
        self.voice = VoiceEngine(self.mem)
        self.bridge = PhysicalBridge()
        self.journal_path = "logs/outreach_journal.jsonl"
        os.makedirs("logs", exist_ok=True)

    def generate_proposal(self, target_name: str, target_profile: str) -> str:
        """
        Synthesizes an authentic proposal using the Iris Cognitive Architecture.
        No templates. Uses KIT/APRA to derive writing from the foundational narrative.
        """
        # 1. Retrieve Foundational Technical Axioms
        mission_query = "Foundational Narrative Sapient Intelligence KIT Axioms APRA"
        mission_vec = embed_text(mission_query)
        
        # Pull high-fidelity fragments from the 300-word foundation
        mission_matches = self.mem.find_nearest(mission_vec, n=15) 
        mission_ids = [m[0] for m in mission_matches]
        
        # 2. Authentic Cognitive Assembly (Founder Perspective)
        story_assembly = self.kit.solve_evolution(mission_query, mission_vec, mission_ids)
        
        # 3. Authentic Cognitive Assembly (Target Specific)
        target_query = f"Synthesize strategic alignment for {target_name}: {target_profile}"
        target_vec = embed_text(target_query)
        target_candidates = [c[0] for c in self.mem.find_nearest(target_vec, n=15)]
        target_assembly = self.kit.solve_evolution(target_query, target_vec, target_candidates)
        
        # 4. Voice Synthesis: Let Iris write the actual text
        # Combined assembly for final synthesis
        combined_assembly = story_assembly + target_assembly
        
        # Synthesize using narrative_mode to avoid chat-like fillers and templates
        final_writing = self.voice.synthesize_assembly("Authentic Technical Outreach", combined_assembly, narrative_mode=True)
        
        return final_writing.strip()

    def dispatch(self, target_name: str, proposal: str, target_url: str = None, physical: bool = False):
        """
        Simulates or performs the dispatch of the proposal.
        """
        if physical and target_url:
            # Physical Layer: Hand over to the bridge
            field_data = {
                "Founder_Name": "Davies Bilayi Kalori",
                "Company": "Sapient Intelligence",
                "Product": "Iris (Cognitive Architecture based on KIT)",
                "Proposal": proposal,
                "Contact": "0110837355",
                "Email": "davieskalori1@gmail.com"
            }
            self.bridge.prepare_submission(target_url, field_data)
        
        entry = {
            "timestamp": time.time(),
            "target": target_name,
            "url": target_url,
            "content": proposal,
            "status": "DISPATCHED" if not physical else "PHYSICAL_READY"
        }
        
        with open(self.journal_path, "a") as f:
            f.write(json.dumps(entry) + "\n")
            
        print(f"[OUTREACH] Dispatch protocol initiated for {target_name}.")

if __name__ == "__main__":
    # Test Run
    m = MemoryCore("./iris_data_genius")
    agent = OutreachAgent(m)
    p = agent.generate_proposal("SEED Group", "Focused on scaling high-tech into the MENA region.")
    agent.dispatch("SEED Group", p)
