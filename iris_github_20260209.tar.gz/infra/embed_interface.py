import numpy as np
import os
import re
from collections import Counter

# Deterministic seeding
os.environ['PYTHONHASHSEED'] = '0'

try:
    from sentence_transformers import SentenceTransformer
    _HAS_ST = True
except ImportError:
    _HAS_ST = False
    
_MODEL = None

from .pure_semantic import PureSemanticEngine

# Global Semantic engine
_PSE = None
PSE_PATH = "./iris_data_genius/semantic_model.json"

def get_pse():
    global _PSE
    if _PSE is None:
        _PSE = PureSemanticEngine()
        if os.path.exists(PSE_PATH):
            _PSE.load(PSE_PATH)
    return _PSE

def embed_text(text: str) -> np.ndarray:
    """
    Returns L2-normalized numpy float32 vector (d=384).
    """
    if not text:
        return np.zeros(1024, dtype=np.float32)
        
    pse = get_pse()
    # Ensure PSE uses 1024
    pse.dim = 1024
    
    vec = pse.embed(text)
    
    # Enforce Float32
    vec = vec.astype(np.float32)
    
    # Enforce L2 Normalization
    norm = np.linalg.norm(vec)
    if norm > 1e-9:
        vec /= norm
        
    return vec
