import numpy as np
import math
from iris_core.dynamics.kit_engine import relax_with_pointer

class MCTSNode:
    def __init__(self, state, parent=None, action=None):
        self.state = state
        self.parent = parent
        self.action = action
        self.children = []
        self.n = 0
        self.w = 0.0
        self.q = 0.0

    def is_fully_expanded(self, num_actions):
        return len(self.children) >= num_actions

class MCTSPlanner:
    def __init__(self, world_model, mem_store, c_param=1.414, beta=0.8):
        self.wm = world_model
        self.mem_store = mem_store
        self.c = c_param
        self.beta = beta
        
    def search(self, root_state, context, iterations=50, actions=None):
        root = MCTSNode(root_state)
        num_actions = len(actions) if actions is not None else 0
        
        for _ in range(iterations):
            node = self._select(root)
            if actions and not node.is_fully_expanded(num_actions):
                expanded_actions = [c.action for c in node.children]
                # Pick an action not yet expanded
                # Simplified: just pick one from list for demo
                act = actions[np.random.choice(len(actions))]
                node = self._expand(node, act, context)
            reward = self._simulate(node)
            self._backpropagate(node, reward)
            
        if not root.children: return None
        best_child = max(root.children, key=lambda c: c.n)
        return best_child.action

    def _select(self, node):
        while node.children:
            if not all(c.n > 0 for c in node.children):
                return node
            node = max(node.children, key=lambda c: c.q + self.c * math.sqrt(math.log(max(1, node.n)) / max(1, c.n)))
        return node

    def _expand(self, node, action, context):
        # Pure NumPy simulation
        s_in = node.state.reshape(1, -1)
        a_in = action.reshape(1, -1)
        c_in = context.reshape(1, -1)
        next_s = self.wm.forward_model(s_in, a_in, c_in)[0]
            
        child = MCTSNode(next_s, parent=node, action=action)
        node.children.append(child)
        return child

    def _simulate(self, node):
        # Use KIT Energy after relaxation (Pointer query q is first 64 dims)
        q = node.state[:64]
        active = relax_with_pointer(q, self.mem_store, steps=5, beta=self.beta)
        return len(active) * 0.1

    def _backpropagate(self, node, reward):
        curr = node
        while curr:
            curr.n += 1
            curr.w += reward
            curr.q = curr.w / curr.n
            curr = curr.parent
