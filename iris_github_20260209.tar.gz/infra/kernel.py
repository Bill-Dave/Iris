import numpy as np
import os
import csv

def sigmoid(x):
    return 1 / (1 + np.exp(-x))

def softplus_scale(x):
    """Sigmoid-weighted linear unit (SiLU) approximation of softplus."""
    return sigmoid(x) * x

def compatibility(cosine_sim, alpha=0.2, beta=0.15):
    """
    Transforms raw cosine similarity into the KIT compatibility term c'.
    c' = softplus((cos - alpha) / beta)
    """
    x = (cosine_sim - alpha) / beta
    return softplus_scale(x)

def run_probes(memory_core, embed_fn, probes):
    """
    Runs a batch of probes and calculates coherence metrics (Phase 5).
    """
    results = []
    for probe_text in probes:
        query_vec = embed_fn(probe_text)
        
        # Calculate similarities
        sims = np.dot(memory_core.vectors, query_vec)
        
        # Top 64
        top_64_idx = np.argsort(sims)[-64:][::-1]
        mean_c_64 = np.mean(sims[top_64_idx])
        
        # Top 16 for coherence
        top_16_idx = top_64_idx[:16]
        top_16_vecs = memory_core.vectors[top_16_idx]
        
        # Intra-coherence (mean pairwise cosine among top 16)
        intra_sims = np.dot(top_16_vecs, top_16_vecs.T)
        triu_idx = np.triu_indices(16, k=1)
        intra_coherence = np.mean(intra_sims[triu_idx])
        
        results.append({
            "probe": probe_text,
            "mean_c_64": mean_c_64,
            "intra_coherence": intra_coherence
        })
        
    return results

def save_metrics(results, filename="metrics/kernel_tuning.csv"):
    os.makedirs(os.path.dirname(filename), exist_ok=True)
    keys = results[0].keys()
    with open(filename, 'w', newline='') as f:
        dict_writer = csv.DictWriter(f, fieldnames=keys)
        dict_writer.writeheader()
        dict_writer.writerows(results)
    print(f"[KIT] Metrics saved to {filename}")

if __name__ == "__main__":
    # Unit test for compatibility
    test_cos = np.array([0.0, 0.2, 0.5, 0.8, 1.0])
    c_prime = compatibility(test_cos)
    print(f"Test Cosines: {test_cos}")
    print(f"Transformed c': {c_prime}")
