import numpy as np

class Layer:
    def __init__(self, in_dim, out_dim):
        self.w = np.random.randn(in_dim, out_dim).astype(np.float32) * np.sqrt(2.0 / in_dim)
        self.b = np.zeros(out_dim).astype(np.float32)
        self.dw, self.db = None, None

    def forward(self, x):
        self.x = x
        self.out = np.dot(x, self.w) + self.b
        return self.out

    def backward(self, d_out):
        self.dw = np.dot(self.x.T, d_out)
        self.db = np.sum(d_out, axis=0)
        return np.dot(d_out, self.w.T)

class WorldModel:
    def __init__(self, d=384, k=64, r=8):
        self.d = d
        # f_theta: (384 + 16 + 384) -> 512 -> 384
        self.f1 = Layer(d + 16 + d, 512)
        self.f2 = Layer(512, d)
        
        # g_phi: (384 + 384) -> 256 -> 16
        self.g1 = Layer(d + d, 256)
        self.g2 = Layer(256, 16)
        
        self.lr = 1e-4

    def _relu(self, x): return np.maximum(0, x)
    def _d_relu(self, x): return (x > 0).astype(np.float32)

    def forward_model(self, state, action, context):
        x = np.concatenate([state, action, context], axis=-1)
        # Layer 1
        h1 = self._relu(self.f1.forward(x))
        # Layer 2
        out = self.f2.forward(h1)
        return out

    def inverse_model(self, state, next_state):
        x = np.concatenate([state, next_state], axis=-1)
        h1 = self._relu(self.g1.forward(x))
        out = self.g2.forward(h1)
        return out

    def train_step(self, states, actions, next_states, contexts):
        # 1. Forward Train
        x_f = np.concatenate([states, actions, contexts], axis=-1)
        h1_f = self._relu(self.f1.forward(x_f))
        pred_next = self.f2.forward(h1_f)
        
        loss_fwd = np.mean((pred_next - next_states)**2)
        d_pred = 2.0 * (pred_next - next_states) / states.shape[0]
        
        dh1_f = self.f2.backward(d_pred)
        dh1_f *= self._d_relu(h1_f)
        self.f1.backward(dh1_f)
        
        # 2. Inverse Train
        x_i = np.concatenate([states, next_states], axis=-1)
        h1_i = self._relu(self.g1.forward(x_i))
        pred_act = self.g2.forward(h1_i)
        
        loss_inv = np.mean((pred_act - actions)**2)
        d_act = 2.0 * (pred_act - actions) / states.shape[0]
        
        dh1_i = self.g2.backward(d_act)
        dh1_i *= self._d_relu(h1_i)
        self.g1.backward(dh1_i)
        
        # 3. Step Optimizer (AdamW-Lite)
        for layer in [self.f1, self.f2, self.g1, self.g2]:
            layer.w -= self.lr * (layer.dw + 1e-2 * layer.w)
            layer.b -= self.lr * layer.db
            
        return loss_fwd + loss_inv, loss_fwd, loss_inv, 0.0

    def save(self, path):
        data = {
            "f1_w": self.f1.w, "f1_b": self.f1.b,
            "f2_w": self.f2.w, "f2_b": self.f2.b,
            "g1_w": self.g1.w, "g1_b": self.g1.b,
            "g2_w": self.g2.w, "g2_b": self.g2.b
        }
        np.savez(path, **data)

    def load(self, path):
        data = np.load(path)
        self.f1.w, self.f1.b = data["f1_w"], data["f1_b"]
        self.f2.w, self.f2.b = data["f2_w"], data["f2_b"]
        self.g1.w, self.g1.b = data["g1_w"], data["g1_b"]
        self.g2.w, self.g2.b = data["g2_w"], data["g2_b"]
