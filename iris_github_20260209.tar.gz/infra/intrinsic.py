import numpy as np

# Helpers
def get_prediction_error(model, x, a, x_next):
    # x: (D,)
    x_in = x.reshape(1, -1)
    a_in = a.reshape(1, -1)
    x_next_in = x_next.reshape(1, -1)
    
    pred = model.forward_model(x_in, a_in)
    err = np.mean((pred - x_next_in)**2)
    return err

class IntrinsicMotivator:
    def __init__(self):
        self.visit_counts = {} # Hash -> Count
        # Hyperparams
        self.w1 = 0.7 # Curiosity
        self.w2 = 0.2 # Novelty
        self.w3 = 0.1 # Empowerment (Empowerment ~ Diversity?)

    def compute_reward(self, pred_error, state_hash, action_entropy=0.0):
        # 1. Curiosity (Pred Error)
        # Soft clip sigma? User: "sigma(|x - f(x)|)"
        # Let's use tanh to clip
        r_intr = np.tanh(pred_error)
        
        # 2. Novelty (1/sqrt(n))
        count = self.visit_counts.get(state_hash, 1)
        r_novel = 1.0 / np.sqrt(count)
        self.visit_counts[state_hash] = count + 1
        
        # 3. Empowerment
        r_empower = action_entropy
        
        R = self.w1 * r_intr + self.w2 * r_novel + self.w3 * r_empower
        return R

    def hash_state(self, x):
        # Simple quantization hash for visit counts
        # (Very rough approx for continuous space)
        # x is (D,)
        # Round to 1 decimal?
        q = np.round(x, 1)
        return hash(q.tobytes())
