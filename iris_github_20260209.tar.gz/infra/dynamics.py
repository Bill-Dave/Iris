import numpy as np
import time
import json
import os
try:
    import faiss
except ImportError:
    faiss = None

from typing import List, Tuple, Dict

# Constants
DT = 0.1
ETA = 1.0
S_MIN = 0.0
S_MAX = 1.0
CANDIDATE_K = 512
THRESHOLD_E = 1e-3
M_MAX = 32

# Logging Path
LOG_PATH = "infra/logs/dynamics_trace.jsonl"
os.makedirs(os.path.dirname(LOG_PATH), exist_ok=True)

def compute_Eij_batch(x_i: np.ndarray, U_i: np.ndarray, x_j: np.ndarray) -> np.ndarray:
    """
    Computes E_ij = (xi - xj)^T (Ui Ui^T) (xi - xj)
    Input shapes:
      x_i: (N, D)
      U_i: (N, D, R)
      x_j: (N, D)  -- corresponding pairs
    Returns:
      E_ij: (N,)
    """
    # diff = xi - xj  -> (N, D)
    diff = x_i - x_j
    
    # Project diff onto subspace U
    # batch_dot(diff, U) -> (N, R)
    # einsum: 'nd,ndr->nr'
    proj = np.einsum('nd,ndr->nr', diff, U_i)
    
    # Square magnitude of projection: sum(proj^2, axis=1)
    # This equals v^T U U^T v because (U^T v)^T (U^T v) = v^T U U^T v
    E_vals = np.sum(proj**2, axis=1)
    
    return E_vals

class DynamicsEngine:
    def __init__(self, memory_core):
        self.mem = memory_core
        self.noise_level = 0.0 # Default 0.0 per spec
        self.tick_counter = 0

    def dynamics_step(self, active_ids: List[str], P_map: Dict[str, float], dt=DT) -> Dict[str, float]:
        """
        Discrete Euler tick.
        g_i = alpha_i * s_i + sum_{j!=i} s_j * E_ij - P_i
        s_i_new = s_i - eta * dt * g_i + noise
        Returns new s_values map.
        """
        self.tick_counter += 1
        N = len(active_ids)
        if N == 0: 
            self._log_trace(0.0, 0, [])
            return {}
        
        # 1. Gather Data
        indices = [self.mem.id_to_idx[uid] for uid in active_ids]
        
        # Shapes: (N, D), (N, D, R), (N,), (N,)
        X = self.mem.x_store[indices]
        U = self.mem.U_store[indices]
        Lam = self.mem.lambda_store[indices]
        S = self.mem.s_store[indices]
        
        # Alpha: max(1e-3, 0.01 * lambda)
        Alpha = np.maximum(1e-3, 0.01 * Lam)
        
        # Potentials P_i
        P_vec = np.array([P_map.get(uid, 0.0) for uid in active_ids])
        
        # 2. Compute Interactions (Pairwise)
        # We need E_ij for all i,j in active set.
        
        # Broadcast for all pairs
        # X_i: (N, 1, D)
        # X_j: (1, N, D)
        # Diff: (N, N, D)
        Diff = X[:, np.newaxis, :] - X[np.newaxis, :, :]
        
        # U_i: (N, 1, D, R)
        # Proj: (N, N, R) -> einsum 'ijd, idr -> ijr' (Use U_i for row i)
        # Warning: U is (N, D, R). We want, for each i, to project diff_{ij} onto U_i.
        
        # Let's vectorize properly:
        # P_ij = Diff_{ij} @ U_i
        Proj = np.einsum('nmd,ndr->nmr', Diff, U)
        
        # E_ij = sum(Proj^2, axis=2) -> (N, N)
        E_matrix = np.sum(Proj**2, axis=-1)
        
        # Zero out diagonals (i != j)
        np.fill_diagonal(E_matrix, 0.0)
        
        # 3. Compute Gradients
        # sum_{j!=i} s_j * E_ij -> (E_matrix @ S)
        Interaction = E_matrix @ S
        
        G = Alpha * S + Interaction - P_vec
        
        # 4. Update
        # noise = sqrt(dt) * xi
        Noise = np.random.normal(0, 1, N) * self.noise_level * np.sqrt(dt)
        
        S_new = S - ETA * dt * G + Noise
        S_new = np.clip(S_new, S_MIN, S_MAX)
        
        # Update Memory
        self.mem.s_store[indices] = S_new
        
        # Calculate Energy for Logging
        # E = sum(alpha s^2 / 2) + sum(s_i s_j E_ij) - sum(P s)
        # Note: Interaction contains s_j * E_ij
        # So sum(s_i * Interaction_i) = sum_i s_i sum_j s_j E_ij
        E_self = 0.5 * np.sum(Alpha * S_new**2)
        E_inter = np.sum(S_new * (E_matrix @ S_new)) # We double count ij vs ji?
        # Formula: sum_{i!=j} s_i s_j E_ij.
        # Matrix multiply sums over all i,j.
        # So yes, direct sum is correct.
        E_pot = -np.sum(P_vec * S_new)
        E_total = E_self + E_inter + E_pot
        
        # Log
        # "top_assembly_ids": active_ids with s > 0.5
        top_ids = [active_ids[i] for i in range(N) if S_new[i] > 0.5]
        self._log_trace(E_total, len(top_ids), top_ids)
        
        return {uid: val for uid, val in zip(active_ids, S_new)}

    def _log_trace(self, e_total, active_count, top_ids):
        # JSON Trace
        entry = {
            "tick": self.tick_counter,
            "E_total": float(e_total),
            "active_count": active_count,
            "top_assembly_ids": top_ids
        }
        with open(LOG_PATH, 'a') as f:
            f.write(json.dumps(entry) + "\n")

        # CSV Report: tick, assembly_id, size, mean_c, avg_s
        # Need to compute stats for top_ids if present
        mean_c = 0.0
        avg_s = 0.0
        assembly_hash = "none"
        size = len(top_ids)
        
        if size > 0:
            indices = [self.mem.id_to_idx[uid] for uid in top_ids]
            S = self.mem.s_store[indices]
            avg_s = np.mean(S)
            assembly_hash = f"asm_{hash(tuple(sorted(top_ids))) % 10000}"
            
            if size > 1:
                # Compute C (compatibility)
                # Re-compute E_matrix subset? Expensive for logging?
                # User specs say "Logs produced...". Let's approximate or compute.
                # E_ij was computed in step. But we discarded it.
                # Recomputing for small assembly (size ~10) is cheap.
                X = self.mem.x_store[indices]
                U = self.mem.U_store[indices]
                Diff = X[:, np.newaxis, :] - X[np.newaxis, :, :]
                Proj = np.einsum('nmd,ndr->nmr', Diff, U)
                E_sub = np.sum(Proj**2, axis=-1)
                # C = sigmoid(-E/0.2)
                C_sub = 1.0 / (1.0 + np.exp(E_sub / 0.2)) # Note: E is positive, so -E/tau
                np.fill_diagonal(C_sub, 0.0) # Exclude self?
                # Mean off-diagonal C
                mean_c = np.sum(C_sub) / (size * (size - 1))
            else:
                mean_c = 1.0 # Self-compatible
        
        csv_path = "infra/metrics/assembly_report.csv"
        os.makedirs(os.path.dirname(csv_path), exist_ok=True)
        # Header if new
        if not os.path.exists(csv_path):
            with open(csv_path, 'w') as f:
                f.write("tick,assembly_id,size,mean_c,avg_s\n")
        
        with open(csv_path, 'a') as f:
            f.write(f"{self.tick_counter},{assembly_hash},{size},{mean_c:.4f},{avg_s:.4f}\n")

    def _knn_search(self, query_vec, k):
        if faiss:
            d = self.mem.x_store.shape[1]
            index = faiss.IndexFlatL2(d)
            index.add(self.mem.x_store)
            D_dist, I_idx = index.search(query_vec.reshape(1, -1), k)
            return I_idx[0]
        else:
            # Numpy Fallback
            # L2 dist = |x - q|^2 = x.x + q.q - 2 x.q
            # We assume Vectors are normalized? Spec says "embedded; L2-normalized".
            # If normalized, L2 min == Cosine Max.
            # But let's compute L2 explicitly to be safe.
            X = self.mem.x_store
            diff = X - query_vec
            dists = np.sum(diff**2, axis=1)
            # Argsort
            idx_sorted = np.argsort(dists)[:k]
            return idx_sorted

    def form_candidate_pool(self, context_vec: np.ndarray, k=CANDIDATE_K) -> List[str]:
        ntotal = self.mem.x_store.shape[0]
        if ntotal == 0: return []
        
        I = self._knn_search(context_vec, k)
        
        # Map indices back to IDs
        pool = []
        for idx in I:
            if idx != -1 and idx < len(self.mem.ids):
                pool.append(self.mem.ids[idx])
        return pool

    def greedy_assembly_seed(self, seed_ids: List[str]) -> List[str]:
        # ... (Rest of Greedy Logic same as before, simplified for this snippet)
        # Prefilter? Spec says "prefilter using candidate_pool".
        # Assume context_vec is mean of seed_ids? Or seed_ids IS the start.
        # Let's start with seed_ids as assembly A.
        # We want to add items that minimize marginal Delta E.
        
        A = list(seed_ids)
        if not A: return []
        
        indices = [self.mem.id_to_idx[uid] for uid in A]
        mean_vec = np.mean(self.mem.x_store[indices], axis=0)
        norm = np.linalg.norm(mean_vec)
        if norm > 0: mean_vec /= norm
        
        pool = self.form_candidate_pool(mean_vec, k=CANDIDATE_K)
        # Remove already in A
        candidates = [c for c in pool if c not in A]
        
        for _ in range(M_MAX - len(A)):
            if not candidates: break
            
            # Find Best Candidate
            # Vectorize this search over candidates
            # Extract A vectors/U
            idx_A = [self.mem.id_to_idx[uid] for uid in A]
            X_A = self.mem.x_store[idx_A] # (Na, D)
            U_A = self.mem.U_store[idx_A] # (Na, D, R)
            
            # Extract C vectors/U
            idx_C = [self.mem.id_to_idx[uid] for uid in candidates]
            X_C = self.mem.x_store[idx_C] # (Nc, D)
            U_C = self.mem.U_store[idx_C] # (Nc, D, R)
            
            # Compute E_ac (A -> C)
            Diff_AC = X_A[:, np.newaxis, :] - X_C[np.newaxis, :, :]
            Proj_AC = np.einsum('nmd,ndr->nmr', Diff_AC, U_A)
            E_AC = np.sum(Proj_AC**2, axis=-1) # (Na, Nc)
            
            # Compute E_ca (C -> A)
            Diff_CA = X_C[:, np.newaxis, :] - X_A[np.newaxis, :, :] 
            Proj_CA = np.einsum('nmd,ndr->nmr', Diff_CA, U_C)
            E_CA = np.sum(Proj_CA**2, axis=-1) # (Nc, Na)
            
            # Marginal E
            Marginal = np.sum(E_AC, axis=0) + np.sum(E_CA, axis=1) # (Nc,)
            
            # Find Best
            best_idx = np.argmin(Marginal)
            val = Marginal[best_idx]
            
            # Pragmatic Cost/Gain rule
            cost = val
            gain = 1.0 
            delta_E = cost - gain
            
            if delta_E < -THRESHOLD_E:
                added = candidates[best_idx]
                A.append(added)
                del candidates[best_idx]
            else:
                break
                
        return A

    def local_swap_optimization(self, assembly_ids):
        # Placeholder for exact spec details if needed
        # "up to 5 rounds of best swap to reduce E"
        return assembly_ids
