import os
import json
import hashlib
import secrets
from typing import List

KEYS_FILE = "admin_keys.json"
NUM_KEYS = 3
THRESHOLD = 2

def hash_key(key: str, salt: str) -> str:
    return hashlib.sha256((key + salt).encode()).hexdigest()

class ApprovalGate:
    def __init__(self):
        self._load_or_generate_keys()
        
    def _load_or_generate_keys(self):
        if not os.path.exists(KEYS_FILE):
            print("[SECURITY] Initializing Admin Keys (2-of-3 Scheme)...")
            keys_data = []
            plain_keys = []
            
            for i in range(NUM_KEYS):
                # Generate a strong random key
                key = secrets.token_hex(16)
                plain_keys.append(key)
                salt = secrets.token_hex(8)
                keys_data.append({
                    "id": f"Admin-{chr(65+i)}", # A, B, C
                    "salt": salt,
                    "hash": hash_key(key, salt)
                })
                
            with open(KEYS_FILE, 'w') as f:
                json.dump(keys_data, f, indent=2)
            os.chmod(KEYS_FILE, 0o600)
            
            print("\n" + "="*50)
            print("CRITICAL: SAVE THESE KEYS SECURELY. THEY WILL NOT BE SHOWN AGAIN.")
            for i, k in enumerate(plain_keys):
                print(f"Key {chr(65+i)}: {k}")
            print("="*50 + "\n")
            
        else:
            with open(KEYS_FILE, 'r') as f:
                self.key_store = json.load(f)
                
    def verify_approval(self, provided_keys: List[str], operation: str) -> bool:
        """
        Validates that at least THRESHOLD unique valid keys are provided.
        """
        # Reload just in case
        with open(KEYS_FILE, 'r') as f:
            self.key_store = json.load(f)
            
        valid_ids = set()
        
        for k_input in provided_keys:
            # Check against all stored keys
            for key_record in self.key_store:
                if hash_key(k_input, key_record['salt']) == key_record['hash']:
                    valid_ids.add(key_record['id'])
                    
        print(f"[SECURITY] Operation '{operation}' requested.")
        print(f"[SECURITY] Valid signatures provided: {valid_ids}")
        
        if len(valid_ids) >= THRESHOLD:
            print("[SECURITY] ACCESS GRANTED.")
            return True
        else:
            print(f"[SECURITY] ACCESS DENIED. Required: {THRESHOLD}, Provided: {len(valid_ids)}")
            return False

# Utility mainly for CLI use
if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--op", required=True, help="Operation name")
    parser.add_argument("--keys", nargs="+", required=True, help="List of admin keys")
    args = parser.parse_args()
    
    gate = ApprovalGate()
    if gate.verify_approval(args.keys, args.op):
        exit(0)
    else:
        exit(1)
