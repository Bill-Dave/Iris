import numpy as np
from typing import List
from .dynamics import compute_Eij_batch

# Constants
ETA_C = 0.02
LAMBDA_C = 0.01
TAU = 0.2
BETA = 1e-3

def sigmoid(x):
    return 1.0 / (1.0 + np.exp(-x))

class ConsolidationEngine:
    def __init__(self, memory_core):
        self.mem = memory_core

    def consolidate_assembly(self, assembly_ids: List[str], reward=1.0):
        """
        Updates s_i based on compatibility with peers.
        Delta s_i = eta_c * sum( r * c_ij - lambda_c * (1 - c_ij) )
        """
        N = len(assembly_ids)
        if N < 2: return

        indices = [self.mem.id_to_idx[uid] for uid in assembly_ids]
        X = self.mem.x_store[indices]
        U = self.mem.U_store[indices]
        S = self.mem.s_store[indices]
        
        # Compute E_ij matrix (NxN)
        # Using the same batch logic as dynamics
        Diff = X[:, np.newaxis, :] - X[np.newaxis, :, :]
        Proj = np.einsum('nmd,ndr->nmr', Diff, U)
        E_matrix = np.sum(Proj**2, axis=-1) # (N, N)
        np.fill_diagonal(E_matrix, float('inf')) # Disable self? or 0?
        # c_ii should be ignored usually. formula says j in A\{i}
        
        # Compatibility c_ij = sigmoid(-E_ij / tau)
        # If E is 0 (perfect), c=0.5 (sigmoid 0). Wait, sigmoid(0) = 0.5.
        # If E is large, c -> 0.
        # The spec says: c_ij = sigmoid(-E_ij / tau)
        C_matrix = sigmoid(-E_matrix / TAU)
        np.fill_diagonal(C_matrix, 0.0) # Mask diagonal
        
        # Delta s calculation
        # Term inside sum: r * c_ij - lambda_c * (1 - c_ij)
        Term = reward * C_matrix - LAMBDA_C * (1.0 - C_matrix)
        
        # Sum over j
        Sum_Terms = np.sum(Term, axis=1) # (N,)
        
        Delta_s = ETA_C * Sum_Terms
        
        # Update S
        # s_i <- clip(s_i + Delta_s, 0, 1)
        S_new = np.clip(S + Delta_s, 0.0, 1.0)
        self.mem.s_store[indices] = S_new

        # Update Persistence
        self.update_persistence(indices, S_new)

    def update_persistence(self, indices, s_values):
        """
        lambda_i <- lambda_i + beta * s_i
        """
        # Load
        Lam = self.mem.lambda_store[indices]
        
        # Update
        Lam_new = Lam + BETA * s_values
        
        # Store
        self.mem.lambda_store[indices] = Lam_new
        
        # We need to save this persistence eventually.
        # The MemoryCore handles atomic saves, but maybe we trigger it?
        # Or periodic. User spec: "periodic_consolidation".

    def periodic_consolidation(self, run_every=100):
        # Implementation depends on the loop runner
        pass
