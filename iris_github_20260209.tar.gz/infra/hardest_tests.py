"""
Hardest-Test Self-Benchmarking Module
==================================================
A "cognitive crucible" that pushes Iris to solve progressively 
harder problems until achieving 100% accuracy.

Features:
    - Dynamic difficulty generation
    - Retry-until-correct loop
    - Anti-pattern memory for failed attempts
"""
import os
import json
import time
import random
import numpy as np
from typing import List, Dict, Tuple, Optional


class HardestTestGenerator:
    """Generates progressively harder STEM/Logic tests."""
    
    def __init__(self):
        self.difficulty_levels = ["BASIC", "INTERMEDIATE", "ADVANCED", "EXPERT", "EXTREME"]
        self.current_level = 0
        self.test_bank = self._init_test_bank()
    
    def _init_test_bank(self) -> Dict[str, List[Dict]]:
        """Initialize test bank with problems at each difficulty level."""
        return {
            "BASIC": [
                {"q": "What is 7 * 8?", "a": "56", "domain": "arithmetic"},
                {"q": "Solve: x + 5 = 12", "a": "7", "domain": "algebra"},
            ],
            "INTERMEDIATE": [
                {"q": "What is the derivative of x^3?", "a": "3x^2", "domain": "calculus"},
                {"q": "If all A are B, and all B are C, what can we conclude about A and C?", "a": "All A are C", "domain": "logic"},
            ],
            "ADVANCED": [
                {"q": "Integrate: ∫ e^x dx", "a": "e^x + C", "domain": "calculus"},
                {"q": "What is the eigenvalue of a 2x2 identity matrix?", "a": "1", "domain": "linear_algebra"},
            ],
            "EXPERT": [
                {"q": "Solve the Schrödinger equation for a particle in an infinite square well (ground state energy formula)", 
                 "a": "E = (π²ħ²)/(2mL²)", "domain": "quantum_mechanics"},
                {"q": "What is the time complexity of Dijkstra's algorithm with a binary heap?", 
                 "a": "O((V+E) log V)", "domain": "algorithms"},
            ],
            "EXTREME": [
                {"q": "Prove that the set of real numbers is uncountable (method name)", 
                 "a": "Cantor's diagonal argument", "domain": "set_theory"},
                {"q": "State Gödel's First Incompleteness Theorem (core implication)", 
                 "a": "Any consistent formal system capable of expressing arithmetic is incomplete", "domain": "metamathematics"},
            ]
        }
    
    def get_test(self, level: str = None) -> Dict:
        """Get a random test at the specified difficulty level."""
        level = level or self.difficulty_levels[self.current_level]
        if level not in self.test_bank:
            level = "BASIC"
        
        tests = self.test_bank[level]
        return random.choice(tests), level
    
    def increase_difficulty(self):
        """Move to the next difficulty level."""
        if self.current_level < len(self.difficulty_levels) - 1:
            self.current_level += 1
    
    def reset_difficulty(self):
        """Reset to base difficulty."""
        self.current_level = 0


class CognitiveCrucible:
    """
    Self-benchmarking loop that pushes Iris to solve hardest problems.
    Implements retry-until-correct with anti-pattern memory.
    """
    
    def __init__(self, memory_core=None, kit_engine=None):
        self.generator = HardestTestGenerator()
        self.mem = memory_core
        self.kit = kit_engine
        
        self.anti_patterns = []  # Failed attempts stored here
        self.success_log = []
        self.max_retries = 10
        
        # Stats
        self.total_tests = 0
        self.total_correct = 0
        self.total_retries = 0
    
    def evaluate_answer(self, predicted: str, expected: str) -> bool:
        """Compare predicted answer to expected (case-insensitive, stripped)."""
        pred = predicted.strip().lower()
        exp = expected.strip().lower()
        
        # Exact match
        if pred == exp:
            return True
        
        # Partial match (expected answer contained in prediction)
        if exp in pred:
            return True
        
        return False
    
    def generate_answer(self, question: str) -> str:
        """
        Generate an answer using the Iris architecture.
        Falls back to mock if KIT engine not available.
        """
        if self.kit is not None:
            try:
                # Use KIT to solve
                from infra.embed_interface import embed_text
                query_vec = embed_text(question)
                candidates = [c[0] for c in self.mem.find_nearest(query_vec, n=15)]
                assembly = self.kit.solve_evolution(question, query_vec, candidates)
                
                # Extract answer from assembly
                if assembly:
                    return str(assembly[0][0])
            except Exception as e:
                pass
        
        # Mock fallback (for testing the loop structure)
        return "MOCK_ANSWER"
    
    def run_test_cycle(self, question: str, expected: str, level: str) -> Dict:
        """
        Run a single test with retry-until-correct logic.
        """
        self.total_tests += 1
        retries = 0
        correct = False
        attempts = []
        
        while retries < self.max_retries and not correct:
            predicted = self.generate_answer(question)
            correct = self.evaluate_answer(predicted, expected)
            
            attempt = {
                "retry": retries,
                "predicted": predicted,
                "correct": correct,
                "timestamp": time.time()
            }
            attempts.append(attempt)
            
            if not correct:
                # Log anti-pattern
                self.anti_patterns.append({
                    "question": question,
                    "wrong_answer": predicted,
                    "level": level
                })
                retries += 1
                self.total_retries += 1
                
                # Trigger knowledge reinforcement (if memory available)
                if self.mem is not None:
                    self._reinforce_knowledge(question, expected)
        
        if correct:
            self.total_correct += 1
            self.success_log.append({
                "question": question,
                "level": level,
                "retries": retries,
                "timestamp": time.time()
            })
        
        return {
            "question": question,
            "expected": expected,
            "level": level,
            "correct": correct,
            "retries": retries,
            "attempts": attempts
        }
    
    def _reinforce_knowledge(self, question: str, answer: str):
        """Reinforce knowledge after a failed attempt."""
        # This would use hebbian learning or direct CKA insertion
        pass
    
    def run_crucible(self, num_rounds: int = 5) -> List[Dict]:
        """
        Run the complete cognitive crucible.
        Progressively increases difficulty as Iris succeeds.
        """
        results = []
        consecutive_successes = 0
        
        print("[CRUCIBLE] Initiating Cognitive Crucible...")
        
        for round_num in range(num_rounds):
            test, level = self.generator.get_test()
            
            print(f"\n[CRUCIBLE] Round {round_num + 1} | Level: {level}")
            print(f"           Q: {test['q'][:60]}...")
            
            result = self.run_test_cycle(test['q'], test['a'], level)
            results.append(result)
            
            if result['correct']:
                print(f"           ✓ CORRECT (retries: {result['retries']})")
                consecutive_successes += 1
                
                # Increase difficulty after 3 consecutive successes
                if consecutive_successes >= 3:
                    self.generator.increase_difficulty()
                    consecutive_successes = 0
                    print(f"           [LEVEL UP] Now at: {self.generator.difficulty_levels[self.generator.current_level]}")
            else:
                print(f"           ✗ FAILED after {result['retries']} retries")
                consecutive_successes = 0
        
        return results
    
    def get_stats(self) -> Dict:
        """Get benchmarking statistics."""
        accuracy = self.total_correct / max(1, self.total_tests) * 100
        return {
            "total_tests": self.total_tests,
            "total_correct": self.total_correct,
            "accuracy": accuracy,
            "total_retries": self.total_retries,
            "anti_patterns_logged": len(self.anti_patterns),
            "current_level": self.generator.difficulty_levels[self.generator.current_level]
        }


# Demonstration
if __name__ == "__main__":
    print("[CRUCIBLE] Initializing Hardest-Test Self-Benchmarking...")
    
    crucible = CognitiveCrucible()
    
    # Run 10 rounds
    results = crucible.run_crucible(num_rounds=10)
    
    # Print stats
    stats = crucible.get_stats()
    print("\n" + "=" * 50)
    print("[CRUCIBLE] Final Statistics:")
    print(f"           Tests: {stats['total_tests']}")
    print(f"           Correct: {stats['total_correct']}")
    print(f"           Accuracy: {stats['accuracy']:.1f}%")
    print(f"           Retries: {stats['total_retries']}")
    print(f"           Anti-Patterns: {stats['anti_patterns_logged']}")
    print(f"           Final Level: {stats['current_level']}")
    print("=" * 50)
