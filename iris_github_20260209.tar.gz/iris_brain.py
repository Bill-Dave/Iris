#!/usr/bin/env python3
"""
IRIS UNIFIED BRAIN
==================================================
Single entry point that initializes the complete cognitive stack.
This is the world's most advanced unified AI brain architecture.

Components:
    - Brain Synchronization Core (Neural Bus, Thalamic Router)
    - Knowledge Stream (Unlimited Knowledge Channels)
    - All 70+ cognitive modules unified
    - STEM + Socio + Planning capabilities
    - Self-improving via Mutation Engine

Architect: Davies Bilayi Kalori
Framework: Sapient Intelligence / KIT / APRA
"""
import os
import sys
import time
import argparse

# Ensure project root is in path
PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, PROJECT_ROOT)


class IrisUnifiedBrain:
    """
    The complete Iris cognitive architecture.
    Closest to human brain intelligence ever built.
    """
    
    def __init__(self, memory_dir: str = None, bootstrap_knowledge: bool = False):
        print("=" * 70)
        print("  ██╗██████╗ ██╗███████╗    ██╗   ██╗███╗   ██╗██╗███████╗██╗███████╗██████╗ ")
        print("  ██║██╔══██╗██║██╔════╝    ██║   ██║████╗  ██║██║██╔════╝██║██╔════╝██╔══██╗")
        print("  ██║██████╔╝██║███████╗    ██║   ██║██╔██╗ ██║██║█████╗  ██║█████╗  ██║  ██║")
        print("  ██║██╔══██╗██║╚════██║    ██║   ██║██║╚██╗██║██║██╔══╝  ██║██╔══╝  ██║  ██║")
        print("  ██║██║  ██║██║███████║    ╚██████╔╝██║ ╚████║██║██║     ██║███████╗██████╔╝")
        print("  ╚═╝╚═╝  ╚═╝╚═╝╚══════╝     ╚═════╝ ╚═╝  ╚═══╝╚═╝╚═╝     ╚═╝╚══════╝╚═════╝ ")
        print("=" * 70)
        print("  UNIFIED BRAIN ARCHITECTURE | Architect: Davies Bilayi Kalori")
        print("=" * 70)
        
        self.memory_dir = memory_dir or os.path.join(PROJECT_ROOT, "iris_data_genius")
        self.brain = None
        self.knowledge = None
        self.initialized = False
        self.start_time = time.time()
        
        # Initialize brain
        self._init_brain()
        
        # Bootstrap knowledge if requested
        if bootstrap_knowledge:
            self._bootstrap_knowledge()
        
        self.initialized = True
        elapsed = time.time() - self.start_time
        print(f"\n[IRIS] Brain fully initialized in {elapsed:.2f}s")
    
    def _init_brain(self):
        """Initialize the synchronized brain core."""
        print("\n[PHASE 1] Initializing Brain Synchronization Core...")
        
        try:
            from infra.brain_sync import BrainSyncCore
            self.brain = BrainSyncCore(self.memory_dir)
        except Exception as e:
            print(f"[ERROR] Brain sync failed: {e}")
            self.brain = None
        
        print("\n[PHASE 2] Initializing Knowledge Stream...")
        
        try:
            from infra.knowledge_stream import KnowledgeStream
            mem = self.brain.modules.get("memory") if self.brain else None
            self.knowledge = KnowledgeStream(mem, PROJECT_ROOT)
        except Exception as e:
            print(f"[ERROR] Knowledge stream failed: {e}")
            self.knowledge = None
    
    def _bootstrap_knowledge(self):
        """Bootstrap unlimited knowledge from all sources."""
        print("\n[PHASE 3] Bootstrapping Unlimited Knowledge...")
        
        if self.knowledge:
            self.knowledge.bootstrap_knowledge()
        else:
            print("[WARNING] Knowledge stream not available.")
    
    def query(self, text: str) -> str:
        """
        Process a query through the unified brain.
        Uses all available cognitive channels.
        """
        if not self.brain:
            return "Brain not initialized. Please restart."
        
        return self.brain.process_query(text)
    
    def get_status(self) -> dict:
        """Get comprehensive brain status."""
        status = {
            "initialized": self.initialized,
            "uptime_seconds": time.time() - self.start_time,
            "brain_modules": {},
            "knowledge_stats": {}
        }
        
        if self.brain:
            brain_status = self.brain.get_brain_status()
            status["brain_modules"] = brain_status.get("modules", {})
            status["modules_loaded"] = brain_status.get("modules_loaded", 0)
            status["total_modules"] = brain_status.get("total_modules", 0)
        
        if self.knowledge:
            status["knowledge_stats"] = self.knowledge.get_stats()
        
        return status
    
    def run_self_improvement(self, rounds: int = 5) -> dict:
        """Run the self-improvement loop (Mutation Engine + Crucible)."""
        if not self.brain:
            return {"error": "Brain not initialized"}
        
        print("\n[RSI] Running Self-Improvement Cycle...")
        
        # Run cognitive crucible
        if self.brain.modules.get("crucible"):
            stats = self.brain.run_self_eval(rounds)
            print(f"[RSI] Crucible Stats: {stats}")
            return stats
        
        return {"error": "Crucible not loaded"}
    
    def interactive_mode(self):
        """Run interactive chat mode."""
        print("\n" + "=" * 70)
        print("IRIS INTERACTIVE MODE")
        print("Type 'exit' to quit | 'status' for brain status | 'rsi' for self-improvement")
        print("=" * 70)
        
        while True:
            try:
                user_input = input("\n[YOU] >>> ").strip()
                
                if not user_input:
                    continue
                
                if user_input.lower() == 'exit':
                    print("[IRIS] Shutting down. Goodbye.")
                    break
                
                if user_input.lower() == 'status':
                    status = self.get_status()
                    print("\n[BRAIN STATUS]")
                    print(f"  Modules: {status.get('modules_loaded', 0)}/{status.get('total_modules', 0)}")
                    print(f"  Uptime: {status['uptime_seconds']:.1f}s")
                    for mod, loaded in status.get('brain_modules', {}).items():
                        print(f"    {mod.upper()}: {'✓' if loaded else '✗'}")
                    continue
                
                if user_input.lower() == 'rsi':
                    self.run_self_improvement()
                    continue
                
                # Process query through brain
                response = self.query(user_input)
                print(f"\n[IRIS] {response}")
                
            except KeyboardInterrupt:
                print("\n[IRIS] Shutting down. Goodbye.")
                break
            except Exception as e:
                print(f"\n[ERROR] {e}")


def verify_brain():
    """Verification mode - test all modules."""
    print("\n" + "=" * 70)
    print("IRIS BRAIN VERIFICATION MODE")
    print("=" * 70)
    
    brain = IrisUnifiedBrain(bootstrap_knowledge=False)
    status = brain.get_status()
    
    print("\n[VERIFICATION RESULTS]")
    print(f"  Initialized: {status['initialized']}")
    print(f"  Modules Loaded: {status.get('modules_loaded', 0)}/{status.get('total_modules', 0)}")
    
    print("\n[MODULE STATUS]")
    for mod, loaded in status.get('brain_modules', {}).items():
        print(f"    {mod.upper()}: {'PASS ✓' if loaded else 'FAIL ✗'}")
    
    # Test query processing
    print("\n[QUERY TESTS]")
    test_queries = [
        "What is the derivative of x squared?",
        "Explain neural networks",
        "Plan a learning strategy"
    ]
    
    for q in test_queries:
        try:
            response = brain.query(q)
            status_emoji = "✓" if len(response) > 20 else "✗"
            print(f"  {status_emoji} '{q[:40]}...'")
        except Exception as e:
            print(f"  ✗ '{q[:40]}...' - ERROR: {e}")
    
    print("\n" + "=" * 70)
    print("VERIFICATION COMPLETE")
    print("=" * 70)


def main():
    """Main entry point."""
    parser = argparse.ArgumentParser(description="Iris Unified Brain")
    parser.add_argument("--verify", action="store_true", help="Run verification tests")
    parser.add_argument("--bootstrap", action="store_true", help="Bootstrap knowledge on startup")
    parser.add_argument("--query", type=str, help="Single query mode")
    args = parser.parse_args()
    
    if args.verify:
        verify_brain()
    elif args.query:
        brain = IrisUnifiedBrain(bootstrap_knowledge=False)
        response = brain.query(args.query)
        print(response)
    else:
        brain = IrisUnifiedBrain(bootstrap_knowledge=args.bootstrap)
        brain.interactive_mode()


if __name__ == "__main__":
    main()
