"""
Iris Sovereign UI - PyWebView Launcher
==================================================
Cross-platform desktop application using PyWebView.
Launches the Orange/Black Apple-like interface for Mac.
"""
import os
import sys
import webview
import json

# Ensure the Iris package is in path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


class IrisAPI:
    """
    Python API exposed to the JavaScript frontend.
    Routes through the UNIFIED BRAIN for complete cognitive integration.
    """
    
    def __init__(self):
        self.brain = None
        self._init_brain()
    
    def _init_brain(self):
        """Initialize the Unified Iris Brain."""
        try:
            # Import the unified brain
            import sys
            sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
            
            from iris_brain import IrisUnifiedBrain
            
            print("[IRIS-UI] Loading Unified Brain Architecture...")
            self.brain = IrisUnifiedBrain(bootstrap_knowledge=False)
            print("[IRIS-UI] Unified Brain loaded successfully.")
            
        except Exception as e:
            print(f"[IRIS-UI] Warning: Could not load unified brain: {e}")
            print("[IRIS-UI] Falling back to legacy mode.")
            self.brain = None
            self._init_legacy()
    
    def _init_legacy(self):
        """Legacy initialization if unified brain fails."""
        try:
            from infra.memory_struct import MemoryCore
            from infra.kit_engine_v3 import KITEngineV3
            from infra.voice import VoiceEngine
            
            memory_dir = os.path.join(
                os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                "iris_data_genius"
            )
            
            self.mem = MemoryCore(memory_dir)
            self.kit = KITEngineV3(self.mem)
            self.voice = VoiceEngine(self.mem)
        except Exception as e:
            self.mem = None
            self.kit = None
            self.voice = None
    
    def chat(self, message: str) -> str:
        """
        Process a chat message through the UNIFIED BRAIN.
        Uses all intelligence channels: STEM, Socio, Planning, etc.
        """
        if not message.strip():
            return "Please provide a query."
        
        try:
            if self.brain:
                # Use unified brain (PREFERRED)
                return self.brain.query(message)
            elif hasattr(self, 'kit') and self.kit:
                # Full KIT processing
                from infra.embed_interface import embed_text
                
                query_vec = embed_text(message)
                candidates = [c[0] for c in self.mem.find_nearest(query_vec, n=15)]
                
                if candidates:
                    assembly = self.kit.solve_evolution(message, query_vec, candidates)
                    response = self.voice.synthesize_assembly(message, assembly)
                    return response
                else:
                    return "I have processed your query, but no relevant knowledge atoms were found in my current state."
            else:
                # Demo mode fallback
                return f"[Demo Mode] I received your message: \"{message[:100]}...\". In production, this would be processed through the full KIT/APRA pipeline."
                
        except Exception as e:
            return f"I encountered an error during cognitive processing: {str(e)}"
    
    def get_status(self) -> dict:
        """Get the current status of the Iris system."""
        return {
            "status": "online",
            "memory_loaded": self.mem is not None,
            "kit_loaded": self.kit is not None,
            "voice_loaded": self.voice is not None
        }


def main():
    """Launch the Iris Sovereign UI."""
    print("=" * 50)
    print("IRIS SOVEREIGN UI")
    print("Architect: Davies Bilayi Kalori")
    print("=" * 50)
    
    # Get the UI directory
    ui_dir = os.path.dirname(os.path.abspath(__file__))
    html_path = os.path.join(ui_dir, "index.html")
    
    if not os.path.exists(html_path):
        print(f"[ERROR] UI file not found: {html_path}")
        sys.exit(1)
    
    # Create the API instance
    api = IrisAPI()
    
    # Create the window
    window = webview.create_window(
        title="Iris - Sovereign Intelligence",
        url=html_path,
        width=1000,
        height=700,
        min_size=(600, 400),
        js_api=api,
        background_color="#0D0D0D"
    )
    
    print("[IRIS-UI] Launching window...")
    
    # Start the webview
    webview.start(debug=False)


if __name__ == "__main__":
    main()
