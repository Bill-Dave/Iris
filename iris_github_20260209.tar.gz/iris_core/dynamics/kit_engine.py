"""
Integrate pointer-driven potential into simple relaxation dynamics over a small active set.
Functions:
- relax_with_pointer(q: np.ndarray, mem_store: dict, steps=20, dt=0.1, beta=0.8) -> active_ids
- compute_energy(mem_ids, mem_store, P_map=None) -> E_total
"""
import numpy as np
from ..memory.lookback import l2normalize
np.random.seed(0)

def compute_Eij(i_item, j_item):
    """
    directional interference: E_ij = (x_i - x_j)^T (U_i U_i^T) (x_i - x_j)
    For this implementation, U_i is approximated via outer product of address->payload projection:
    Use small proxy: U_i = outer(payload, address) normalized (keeps low-rank-ish)
    """
    x_i = i_item.payload
    x_j = j_item.payload
    a_i = i_item.address
    # build a small projector P = (a_i @ a_i^T) scaled into d-dim via outer
    # approximate: (x_i - x_j)^T * ( (a_i·a_i) * I_d ) * (x_i - x_j) => scalar proportional to norm^2
    diff = x_i - x_j
    # use directional weighting by dot(payload_projected, address) to create asymmetry
    # Project payload into k-dim address space using same W as in lookback.py
    d, k = x_i.shape[0], a_i.shape[0]
    rs = np.random.RandomState(0) 
    W = rs.randn(k, d).astype(np.float32)
    x_i_proj = W.dot(x_i)
    # normalize x_i_proj to keep it in scale with address
    from ..memory.lookback import l2normalize
    x_i_proj = l2normalize(x_i_proj) 
    asym = float(np.dot(x_i_proj, a_i))
    return (np.dot(diff, diff) * (1.0 + 0.01 * asym))

def compute_energy(mem_ids, mem_store, P_map=None):
    if P_map is None: P_map = {}
    E = 0.0
    ids = list(mem_ids)
    # self cost
    for i in ids:
        s = mem_store[i].s
        alpha = 0.01 + 0.001
        E += 0.5 * alpha * (s**2)
    # pairwise
    for idx_i, i in enumerate(ids):
        for j in ids[idx_i+1:]:
            E += mem_store[i].s * mem_store[j].s * compute_Eij(mem_store[i], mem_store[j])
    # pointer potentials
    for i in ids:
        P = P_map.get(i, 0.0)
        E -= mem_store[i].s * P
    return float(E)

def relax_with_pointer(q: np.ndarray, mem_store: dict, steps: int = 20, dt: float = 0.1, beta: float = 0.8):
    """
    Simple relaxation on a candidate pool (all memories or a window).
    Returns list of active ids with s_i > 0.2 after relaxation.
    """
    # candidate set: all memories (small tests only)
    ids = list(mem_store.keys())
    n = len(ids)
    # initialize s small random
    for i in ids:
        mem_store[i].s = 0.01
    # precompute q·a_i as pointer potential
    P_map = {}
    for i in ids:
        P_map[i] = float(beta * np.dot(q, mem_store[i].address))
    # relaxation loop
    for t in range(steps):
        # compute g_i for each
        g = {}
        for i in ids:
            alpha = 0.01 + 0.001
            s_i = mem_store[i].s
            pair_contrib = 0.0
            for j in ids:
                if j == i: continue
                pair_contrib += mem_store[j].s * compute_Eij(mem_store[i], mem_store[j])
            P = P_map.get(i, 0.0)
            g_i = alpha * s_i + pair_contrib - P
            # Euler update with learning rate eta=1.0
            s_new = s_i - 1.0 * dt * g_i
            # add small noise
            s_new += np.sqrt(dt) * (np.random.randn() * 1e-4)
            # clip
            s_new = max(0.0, min(1.0, s_new))
            g[i] = s_new
        # commit updates
        for i in ids:
            mem_store[i].s = g[i]
    # collect active ids
    active = [i for i in ids if mem_store[i].s > 0.2]
    return active
