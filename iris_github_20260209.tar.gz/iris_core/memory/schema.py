"""
Define MemoryItem dataclass with address/pointer/payload fields.
"""
from dataclasses import dataclass, field
import numpy as np
import uuid, time

@dataclass
class MemoryItem:
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    timestamp: float = field(default_factory=time.time)
    context_id: str = ""
    payload: np.ndarray = None   # d-dim float32
    address: np.ndarray = None   # k-dim float32
    pointer: np.ndarray = None   # k-dim float32
    s: float = 0.0               # activation / salience baseline
    meta: dict = field(default_factory=dict)
