"""
Functions:
- create_address_pointer(embedding: np.ndarray, k=64) -> (a,p)
- store_memory(payload: np.ndarray, context_id: str, mem_store: dict) -> memory_id
- retrieve_by_query(q: np.ndarray, mem_store: dict, k_return=8, tau=0.07) -> retrieved_vector, weights
"""
import numpy as np
from .schema import MemoryItem
import os
np.random.seed(0)

def l2normalize(v):
    v = v.astype(np.float32)
    n = np.linalg.norm(v)
    if n < 1e-12: return v
    return v / n

def create_address_pointer(e: np.ndarray, k: int = 64):
    """
    Deterministic projection to k-dim address/pointer.
    Use simple seeded random projection (fixed seed).
    Note: For the pointer to dereference the address via dot product, 
    they should be in the same projection space in this toy model.
    """
    d = e.shape[0]
    rs = np.random.RandomState(0)
    # create fixed random projection matrix
    W = rs.randn(k, d).astype(np.float32)
    # In a real model, W_a and W_p might be different but learned to align.
    # Here we use the same W to satisfy the paper's "matching" property by default.
    a = l2normalize(W.dot(e))
    p = l2normalize(W.dot(e))
    return a, p

def store_memory(payload: np.ndarray, context_id: str, mem_store: dict):
    """
    mem_store: dict mapping id->MemoryItem
    payload: d-dim float32
    returns memory_id
    """
    a, p = create_address_pointer(payload)
    m = MemoryItem(payload=payload.astype(np.float32),
                   address=a, pointer=p, context_id=context_id, s=0.0)
    mem_store[m.id] = m
    return m.id

def retrieve_by_query(q: np.ndarray, mem_store: dict, candidate_window=None, k_return=8, tau=0.07):
    """
    q: k-dim query pointer
    mem_store: dict of MemoryItem
    candidate_window: list of ids to consider (None -> all)
    returns: retrieved_vector (d-dim), weights list of (id, w)
    """
    if not mem_store:
        return np.zeros((1,), dtype=np.float32), []
    
    ids = list(mem_store.keys()) if candidate_window is None else list(candidate_window)
    if not ids:
        return np.zeros((1,), dtype=np.float32), []
        
    # compute dot scores q·a_i
    scores = []
    for i in ids:
        a = mem_store[i].address
        scores.append(float(np.dot(q, a)))
    scores = np.array(scores, dtype=np.float32)
    # softmax with temperature tau
    maxs = np.max(scores)
    exps = np.exp((scores - maxs) / tau)
    ws = exps / (np.sum(exps) + 1e-12)
    # pick top k_return by weight
    idx = np.argsort(-ws)[:k_return]
    picked_ids = [ids[ii] for ii in idx]
    picked_ws = ws[idx]
    # build weighted sum of payloads
    payload_dim = mem_store[picked_ids[0]].payload.shape[0]
    retrieved = np.zeros((payload_dim,), dtype=np.float32)
    for pid, w in zip(picked_ids, picked_ws):
        retrieved += w * mem_store[pid].payload
    return retrieved, list(zip(picked_ids, picked_ws))
